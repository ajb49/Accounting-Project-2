prompt --application/shared_components/files/login_color_css
begin
--   Manifest
--     APP STATIC FILES: 1264481
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E627574746F6E5F67726164317B0D0A20206261636B67726F756E642D636F6C6F723A20233034334135363B2F2A626C75652A2F0D0A2020636F6C6F723A2023423539323238203B202F2A676F6C642A2F0D0A7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(26688185328446217590)
,p_file_name=>'login_color.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
