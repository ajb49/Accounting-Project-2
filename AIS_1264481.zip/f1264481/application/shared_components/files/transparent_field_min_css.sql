prompt --application/shared_components/files/transparent_field_min_css
begin
--   Manifest
--     APP STATIC FILES: 1264481
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E74726E737B6261636B67726F756E642D636F6C6F723A7472616E73706172656E743B626F726465722D636F6C6F723A236562626433347D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(26693274081235507655)
,p_file_name=>'transparent_field.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
