prompt --application/shared_components/reports/report_layouts/trial_balance
begin
--   Manifest
--     REPORT LAYOUT: Trial_balance
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
    wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
    wwv_flow_imp.g_varchar2_table(1) := '{\rtf1\adeflang1025\ansi\ansicpg1252\uc1\adeff31507\deff0\stshfdbch31506\stshfloch31506\stshfhich315';
    wwv_flow_imp.g_varchar2_table(2) := '06\stshfbi31507\deflang1033\deflangfe1033\themelang1033\themelangfe0\themelangcs0{\fonttbl{\f0\fbidi';
    wwv_flow_imp.g_varchar2_table(3) := ' \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\f0\fbidi \froman\fcharset';
    wwv_flow_imp.g_varchar2_table(4) := '0\fprq2{\*\panose 02020603050405020304}Times New Roman;}'||wwv_flow.LF||
'{\f39\fbidi \fswiss\fcharset0\fprq2{\*\pan';
    wwv_flow_imp.g_varchar2_table(5) := 'ose 020f0502020204030204}Calibri;}{\flomajor\f31500\fbidi \froman\fcharset0\fprq2{\*\panose 02020603';
    wwv_flow_imp.g_varchar2_table(6) := '050405020304}Times New Roman;}'||wwv_flow.LF||
'{\fdbmajor\f31501\fbidi \froman\fcharset0\fprq2{\*\panose 0202060305';
    wwv_flow_imp.g_varchar2_table(7) := '0405020304}Times New Roman;}{\fhimajor\f31502\fbidi \fswiss\fcharset0\fprq2{\*\panose 020f0302020204';
    wwv_flow_imp.g_varchar2_table(8) := '030204}Calibri Light;}'||wwv_flow.LF||
'{\fbimajor\f31503\fbidi \froman\fcharset0\fprq2{\*\panose 020206030504050203';
    wwv_flow_imp.g_varchar2_table(9) := '04}Times New Roman;}{\flominor\f31504\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}T';
    wwv_flow_imp.g_varchar2_table(10) := 'imes New Roman;}'||wwv_flow.LF||
'{\fdbminor\f31505\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Tim';
    wwv_flow_imp.g_varchar2_table(11) := 'es New Roman;}{\fhiminor\f31506\fbidi \fswiss\fcharset0\fprq2{\*\panose 020f0502020204030204}Calibri';
    wwv_flow_imp.g_varchar2_table(12) := ';}'||wwv_flow.LF||
'{\fbiminor\f31507\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}';
    wwv_flow_imp.g_varchar2_table(13) := '{\f41\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\f42\fbidi \froman\fcharset204\fprq2 Time';
    wwv_flow_imp.g_varchar2_table(14) := 's New Roman Cyr;}'||wwv_flow.LF||
'{\f44\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\f45\fbidi \froman\';
    wwv_flow_imp.g_varchar2_table(15) := 'fcharset162\fprq2 Times New Roman Tur;}{\f46\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew';
    wwv_flow_imp.g_varchar2_table(16) := ');}{\f47\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\f48\fbidi \froman\fcharset186';
    wwv_flow_imp.g_varchar2_table(17) := '\fprq2 Times New Roman Baltic;}{\f49\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{';
    wwv_flow_imp.g_varchar2_table(18) := '\f41\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\f42\fbidi \froman\fcharset204\fprq2 Times';
    wwv_flow_imp.g_varchar2_table(19) := ' New Roman Cyr;}'||wwv_flow.LF||
'{\f44\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\f45\fbidi \froman\f';
    wwv_flow_imp.g_varchar2_table(20) := 'charset162\fprq2 Times New Roman Tur;}{\f46\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew)';
    wwv_flow_imp.g_varchar2_table(21) := ';}{\f47\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\f48\fbidi \froman\fcharset186\';
    wwv_flow_imp.g_varchar2_table(22) := 'fprq2 Times New Roman Baltic;}{\f49\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\';
    wwv_flow_imp.g_varchar2_table(23) := 'f431\fbidi \fswiss\fcharset238\fprq2 Calibri CE;}{\f432\fbidi \fswiss\fcharset204\fprq2 Calibri Cyr;';
    wwv_flow_imp.g_varchar2_table(24) := '}'||wwv_flow.LF||
'{\f434\fbidi \fswiss\fcharset161\fprq2 Calibri Greek;}{\f435\fbidi \fswiss\fcharset162\fprq2 Cali';
    wwv_flow_imp.g_varchar2_table(25) := 'bri Tur;}{\f436\fbidi \fswiss\fcharset177\fprq2 Calibri (Hebrew);}{\f437\fbidi \fswiss\fcharset178\f';
    wwv_flow_imp.g_varchar2_table(26) := 'prq2 Calibri (Arabic);}'||wwv_flow.LF||
'{\f438\fbidi \fswiss\fcharset186\fprq2 Calibri Baltic;}{\f439\fbidi \fswiss';
    wwv_flow_imp.g_varchar2_table(27) := '\fcharset163\fprq2 Calibri (Vietnamese);}{\flomajor\f31508\fbidi \froman\fcharset238\fprq2 Times New';
    wwv_flow_imp.g_varchar2_table(28) := ' Roman CE;}'||wwv_flow.LF||
'{\flomajor\f31509\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\flomajor\f3151';
    wwv_flow_imp.g_varchar2_table(29) := '1\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\flomajor\f31512\fbidi \froman\fcharset162';
    wwv_flow_imp.g_varchar2_table(30) := '\fprq2 Times New Roman Tur;}'||wwv_flow.LF||
'{\flomajor\f31513\fbidi \froman\fcharset177\fprq2 Times New Roman (Heb';
    wwv_flow_imp.g_varchar2_table(31) := 'rew);}{\flomajor\f31514\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\flomajor\f31515\';
    wwv_flow_imp.g_varchar2_table(32) := 'fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}'||wwv_flow.LF||
'{\flomajor\f31516\fbidi \froman\fcharset16';
    wwv_flow_imp.g_varchar2_table(33) := '3\fprq2 Times New Roman (Vietnamese);}{\fdbmajor\f31518\fbidi \froman\fcharset238\fprq2 Times New Ro';
    wwv_flow_imp.g_varchar2_table(34) := 'man CE;}{\fdbmajor\f31519\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\fdbmajor\f31521\f';
    wwv_flow_imp.g_varchar2_table(35) := 'bidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\fdbmajor\f31522\fbidi \froman\fcharset162\fp';
    wwv_flow_imp.g_varchar2_table(36) := 'rq2 Times New Roman Tur;}{\fdbmajor\f31523\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);';
    wwv_flow_imp.g_varchar2_table(37) := '}'||wwv_flow.LF||
'{\fdbmajor\f31524\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\fdbmajor\f31525\fbi';
    wwv_flow_imp.g_varchar2_table(38) := 'di \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fdbmajor\f31526\fbidi \froman\fcharset163\fpr';
    wwv_flow_imp.g_varchar2_table(39) := 'q2 Times New Roman (Vietnamese);}'||wwv_flow.LF||
'{\fhimajor\f31528\fbidi \fswiss\fcharset238\fprq2 Calibri Light C';
    wwv_flow_imp.g_varchar2_table(40) := 'E;}{\fhimajor\f31529\fbidi \fswiss\fcharset204\fprq2 Calibri Light Cyr;}{\fhimajor\f31531\fbidi \fsw';
    wwv_flow_imp.g_varchar2_table(41) := 'iss\fcharset161\fprq2 Calibri Light Greek;}'||wwv_flow.LF||
'{\fhimajor\f31532\fbidi \fswiss\fcharset162\fprq2 Calib';
    wwv_flow_imp.g_varchar2_table(42) := 'ri Light Tur;}{\fhimajor\f31533\fbidi \fswiss\fcharset177\fprq2 Calibri Light (Hebrew);}{\fhimajor\f';
    wwv_flow_imp.g_varchar2_table(43) := '31534\fbidi \fswiss\fcharset178\fprq2 Calibri Light (Arabic);}'||wwv_flow.LF||
'{\fhimajor\f31535\fbidi \fswiss\fcha';
    wwv_flow_imp.g_varchar2_table(44) := 'rset186\fprq2 Calibri Light Baltic;}{\fhimajor\f31536\fbidi \fswiss\fcharset163\fprq2 Calibri Light ';
    wwv_flow_imp.g_varchar2_table(45) := '(Vietnamese);}{\fbimajor\f31538\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}'||wwv_flow.LF||
'{\fbimajor\f31';
    wwv_flow_imp.g_varchar2_table(46) := '539\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\fbimajor\f31541\fbidi \froman\fcharset161';
    wwv_flow_imp.g_varchar2_table(47) := '\fprq2 Times New Roman Greek;}{\fbimajor\f31542\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;';
    wwv_flow_imp.g_varchar2_table(48) := '}'||wwv_flow.LF||
'{\fbimajor\f31543\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\fbimajor\f31544\fbi';
    wwv_flow_imp.g_varchar2_table(49) := 'di \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\fbimajor\f31545\fbidi \froman\fcharset186\f';
    wwv_flow_imp.g_varchar2_table(50) := 'prq2 Times New Roman Baltic;}'||wwv_flow.LF||
'{\fbimajor\f31546\fbidi \froman\fcharset163\fprq2 Times New Roman (Vi';
    wwv_flow_imp.g_varchar2_table(51) := 'etnamese);}{\flominor\f31548\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\flominor\f31549\f';
    wwv_flow_imp.g_varchar2_table(52) := 'bidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\flominor\f31551\fbidi \froman\fcharset161\fp';
    wwv_flow_imp.g_varchar2_table(53) := 'rq2 Times New Roman Greek;}{\flominor\f31552\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\';
    wwv_flow_imp.g_varchar2_table(54) := 'flominor\f31553\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}'||wwv_flow.LF||
'{\flominor\f31554\fbidi ';
    wwv_flow_imp.g_varchar2_table(55) := '\froman\fcharset178\fprq2 Times New Roman (Arabic);}{\flominor\f31555\fbidi \froman\fcharset186\fprq';
    wwv_flow_imp.g_varchar2_table(56) := '2 Times New Roman Baltic;}{\flominor\f31556\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnam';
    wwv_flow_imp.g_varchar2_table(57) := 'ese);}'||wwv_flow.LF||
'{\fdbminor\f31558\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\fdbminor\f31559\fbid';
    wwv_flow_imp.g_varchar2_table(58) := 'i \froman\fcharset204\fprq2 Times New Roman Cyr;}{\fdbminor\f31561\fbidi \froman\fcharset161\fprq2 T';
    wwv_flow_imp.g_varchar2_table(59) := 'imes New Roman Greek;}'||wwv_flow.LF||
'{\fdbminor\f31562\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\fdb';
    wwv_flow_imp.g_varchar2_table(60) := 'minor\f31563\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\fdbminor\f31564\fbidi \from';
    wwv_flow_imp.g_varchar2_table(61) := 'an\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\fdbminor\f31565\fbidi \froman\fcharset186\fprq2 T';
    wwv_flow_imp.g_varchar2_table(62) := 'imes New Roman Baltic;}{\fdbminor\f31566\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese';
    wwv_flow_imp.g_varchar2_table(63) := ');}{\fhiminor\f31568\fbidi \fswiss\fcharset238\fprq2 Calibri CE;}'||wwv_flow.LF||
'{\fhiminor\f31569\fbidi \fswiss\f';
    wwv_flow_imp.g_varchar2_table(64) := 'charset204\fprq2 Calibri Cyr;}{\fhiminor\f31571\fbidi \fswiss\fcharset161\fprq2 Calibri Greek;}{\fhi';
    wwv_flow_imp.g_varchar2_table(65) := 'minor\f31572\fbidi \fswiss\fcharset162\fprq2 Calibri Tur;}'||wwv_flow.LF||
'{\fhiminor\f31573\fbidi \fswiss\fcharset';
    wwv_flow_imp.g_varchar2_table(66) := '177\fprq2 Calibri (Hebrew);}{\fhiminor\f31574\fbidi \fswiss\fcharset178\fprq2 Calibri (Arabic);}{\fh';
    wwv_flow_imp.g_varchar2_table(67) := 'iminor\f31575\fbidi \fswiss\fcharset186\fprq2 Calibri Baltic;}'||wwv_flow.LF||
'{\fhiminor\f31576\fbidi \fswiss\fcha';
    wwv_flow_imp.g_varchar2_table(68) := 'rset163\fprq2 Calibri (Vietnamese);}{\fbiminor\f31578\fbidi \froman\fcharset238\fprq2 Times New Roma';
    wwv_flow_imp.g_varchar2_table(69) := 'n CE;}{\fbiminor\f31579\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\fbiminor\f31581\fbi';
    wwv_flow_imp.g_varchar2_table(70) := 'di \froman\fcharset161\fprq2 Times New Roman Greek;}{\fbiminor\f31582\fbidi \froman\fcharset162\fprq';
    wwv_flow_imp.g_varchar2_table(71) := '2 Times New Roman Tur;}{\fbiminor\f31583\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}';
    wwv_flow_imp.g_varchar2_table(72) := ''||wwv_flow.LF||
'{\fbiminor\f31584\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\fbiminor\f31585\fbidi';
    wwv_flow_imp.g_varchar2_table(73) := ' \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fbiminor\f31586\fbidi \froman\fcharset163\fprq2';
    wwv_flow_imp.g_varchar2_table(74) := ' Times New Roman (Vietnamese);}}'||wwv_flow.LF||
'{\colortbl;\red0\green0\blue0;\red0\green0\blue255;\red0\green255\';
    wwv_flow_imp.g_varchar2_table(75) := 'blue255;\red0\green255\blue0;\red255\green0\blue255;\red255\green0\blue0;\red255\green255\blue0;\red';
    wwv_flow_imp.g_varchar2_table(76) := '255\green255\blue255;\red0\green0\blue128;\red0\green128\blue128;\red0\green128\blue0;'||wwv_flow.LF||
'\red128\gree';
    wwv_flow_imp.g_varchar2_table(77) := 'n0\blue128;\red128\green0\blue0;\red128\green128\blue0;\red128\green128\blue128;\red192\green192\blu';
    wwv_flow_imp.g_varchar2_table(78) := 'e192;\red231\green243\blue253;}{\*\defchp \f31506\fs22 }{\*\defpap \ql \li0\ri0\sa160\sl259\slmult1';
    wwv_flow_imp.g_varchar2_table(79) := ''||wwv_flow.LF||
'\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 }\noqfpromote {\styleshee';
    wwv_flow_imp.g_varchar2_table(80) := 't{\ql \li0\ri0\sa160\sl259\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin';
    wwv_flow_imp.g_varchar2_table(81) := '0\itap0 \rtlch\fcs1 \af31507\afs22\alang1025 '||wwv_flow.LF||
'\ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\la';
    wwv_flow_imp.g_varchar2_table(82) := 'ngnp1033\langfenp1033 \snext0 \sqformat \spriority0 Normal;}{\*\cs10 \additive \ssemihidden \sunhide';
    wwv_flow_imp.g_varchar2_table(83) := 'used \spriority1 Default Paragraph Font;}{\*'||wwv_flow.LF||
'\ts11\tsrowd\trftsWidthB3\trpaddl108\trpaddr108\trpadd';
    wwv_flow_imp.g_varchar2_table(84) := 'fl3\trpaddft3\trpaddfb3\trpaddfr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbr';
    wwv_flow_imp.g_varchar2_table(85) := 'drdgl\tsbrdrdgr\tsbrdrh\tsbrdrv \ql \li0\ri0\sa160\sl259\slmult1'||wwv_flow.LF||
'\widctlpar\wrapdefault\aspalpha\as';
    wwv_flow_imp.g_varchar2_table(86) := 'pnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs2';
    wwv_flow_imp.g_varchar2_table(87) := '2\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \snext11 \ssemihidden \sunhideused Normal Table;';
    wwv_flow_imp.g_varchar2_table(88) := '}{\*\ts15\tsrowd'||wwv_flow.LF||
'\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdr';
    wwv_flow_imp.g_varchar2_table(89) := 's\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidthB3\trpaddl108\trpaddr108\trpadd';
    wwv_flow_imp.g_varchar2_table(90) := 'fl3\trpaddft3\trpaddfb3\trpaddfr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbr';
    wwv_flow_imp.g_varchar2_table(91) := 'drdgl\tsbrdrdgr\tsbrdrh\tsbrdrv '||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustri';
    wwv_flow_imp.g_varchar2_table(92) := 'ght\rin0\lin0\itap0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe103';
    wwv_flow_imp.g_varchar2_table(93) := '3\cgrid\langnp1033\langfenp1033 \sbasedon11 \snext15 \spriority39 \styrsid11681118 '||wwv_flow.LF||
'Table Grid;}}{\';
    wwv_flow_imp.g_varchar2_table(94) := '*\rsidtbl \rsid11681118\rsid15494459}{\mmathPr\mmathFont34\mbrkBin0\mbrkBinSub0\msmallFrac0\mdispDef';
    wwv_flow_imp.g_varchar2_table(95) := '1\mlMargin0\mrMargin0\mdefJc1\mwrapIndent1440\mintLim0\mnaryLim1}{\info{\author Bappy}{\operator Bap';
    wwv_flow_imp.g_varchar2_table(96) := 'py}{\creatim\yr2022\mo5\dy26\hr9\min50}'||wwv_flow.LF||
'{\revtim\yr2022\mo5\dy26\hr9\min51}{\version1}{\edmins1}{\n';
    wwv_flow_imp.g_varchar2_table(97) := 'ofpages1}{\nofwords21}{\nofchars121}{\nofcharsws141}{\vern87}}{\*\xmlnstbl {\xmlns1 http://schemas.m';
    wwv_flow_imp.g_varchar2_table(98) := 'icrosoft.com/office/word/2003/wordml}}'||wwv_flow.LF||
'\paperw12240\paperh15840\margl1440\margr1440\margt1440\margb';
    wwv_flow_imp.g_varchar2_table(99) := '1440\gutter0\ltrsect '||wwv_flow.LF||
'\widowctrl\ftnbj\aenddoc\trackmoves0\trackformatting1\donotembedsysfont1\rely';
    wwv_flow_imp.g_varchar2_table(100) := 'onvml1\donotembedlingdata0\grfdocevents0\validatexml1\showplaceholdtext0\ignoremixedcontent0\saveinv';
    wwv_flow_imp.g_varchar2_table(101) := 'alidxml0\showxmlerrors1\noxlattoyen'||wwv_flow.LF||
'\expshrtn\noultrlspc\dntblnsbdb\nospaceforul\formshade\horzdoc\';
    wwv_flow_imp.g_varchar2_table(102) := 'dgmargin\dghspace180\dgvspace180\dghorigin1440\dgvorigin1440\dghshow1\dgvshow1'||wwv_flow.LF||
'\jexpand\viewkind1\v';
    wwv_flow_imp.g_varchar2_table(103) := 'iewscale100\pgbrdrhead\pgbrdrfoot\splytwnine\ftnlytwnine\htmautsp\nolnhtadjtbl\useltbaln\alntblind\l';
    wwv_flow_imp.g_varchar2_table(104) := 'ytcalctblwd\lyttblrtgr\lnbrkrule\nobrkwrptbl\snaptogridincell\allowfieldendsel\wrppunct'||wwv_flow.LF||
'\asianbrkru';
    wwv_flow_imp.g_varchar2_table(105) := 'le\rsidroot11681118\newtblstyruls\nogrowautofit\usenormstyforlist\noindnmbrts\felnbrelev\nocxsptable';
    wwv_flow_imp.g_varchar2_table(106) := '\indrlsweleven\noafcnsttbl\afelev\utinl\hwelev\spltpgpar\notcvasp\notbrkcnstfrctbl\notvatxbx\krnprsn';
    wwv_flow_imp.g_varchar2_table(107) := 'et\cachedcolbal \nouicompat \fet0'||wwv_flow.LF||
'{\*\wgrffmtfilter 2450}\nofeaturethrottle1\ilfomacatclnup0{\*\doc';
    wwv_flow_imp.g_varchar2_table(108) := 'var {xdo0001}{PD9mb3ItZWFjaDpST1c/Pg==}}{\*\docvar {xdo0002}{PD9QQVJUSUNVTEFSUz8+}}{\*\docvar {xdo00';
    wwv_flow_imp.g_varchar2_table(109) := '03}{PD9ERUJJVD8+}}{\*\docvar {xdo0004}{PD9DUkVESVQ/Pg==}}'||wwv_flow.LF||
'{\*\docvar {xdo0005}{PD9lbmQgZm9yLWVhY2g/';
    wwv_flow_imp.g_varchar2_table(110) := 'Pg==}}\ltrpar \sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\*\pnseclvl1\pnu';
    wwv_flow_imp.g_varchar2_table(111) := 'crm\pnstart1\pnindent720\pnhang {\pntxta .}}{\*\pnseclvl2\pnucltr\pnstart1\pnindent720\pnhang {\pntx';
    wwv_flow_imp.g_varchar2_table(112) := 'ta .}}'||wwv_flow.LF||
'{\*\pnseclvl3\pndec\pnstart1\pnindent720\pnhang {\pntxta .}}{\*\pnseclvl4\pnlcltr\pnstart1\p';
    wwv_flow_imp.g_varchar2_table(113) := 'nindent720\pnhang {\pntxta )}}{\*\pnseclvl5\pndec\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}';
    wwv_flow_imp.g_varchar2_table(114) := '}{\*\pnseclvl6\pnlcltr\pnstart1\pnindent720\pnhang {\pntxtb (}'||wwv_flow.LF||
'{\pntxta )}}{\*\pnseclvl7\pnlcrm\pns';
    wwv_flow_imp.g_varchar2_table(115) := 'tart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnseclvl8\pnlcltr\pnstart1\pnindent720\pnhang {\';
    wwv_flow_imp.g_varchar2_table(116) := 'pntxtb (}{\pntxta )}}{\*\pnseclvl9\pnlcrm\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}\pard\p';
    wwv_flow_imp.g_varchar2_table(117) := 'lain \ltrpar'||wwv_flow.LF||
'\qc \li0\ri0\sa160\sl259\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustri';
    wwv_flow_imp.g_varchar2_table(118) := 'ght\rin0\lin0\itap0\pararsid11681118 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\l';
    wwv_flow_imp.g_varchar2_table(119) := 'ang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 '||wwv_flow.LF||
'\af31507 \ltrch\fcs0 \b\fs32\insrsid';
    wwv_flow_imp.g_varchar2_table(120) := '11681118\charrsid11681118 Trial Balance'||wwv_flow.LF||
'\par \ltrrow}\trowd \irow0\irowband0\ltrrow\ts15\trgaph108\';
    wwv_flow_imp.g_varchar2_table(121) := 'trleft-108\trhdr\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\';
    wwv_flow_imp.g_varchar2_table(122) := 'brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trautofit1\trpaddl';
    wwv_flow_imp.g_varchar2_table(123) := '108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid11681118\tbllkhdrrows\tbllkhdrcols\tbl';
    wwv_flow_imp.g_varchar2_table(124) := 'lknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brd';
    wwv_flow_imp.g_varchar2_table(125) := 'rs\brdrw10 '||wwv_flow.LF||
'\clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth3116\clcbpatraw17 \cellx';
    wwv_flow_imp.g_varchar2_table(126) := '3008\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\br';
    wwv_flow_imp.g_varchar2_table(127) := 'drw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth3117\clcbpatraw17 '||wwv_flow.LF||
'\cellx6125\clvertalt\clbrdrt\brdrs';
    wwv_flow_imp.g_varchar2_table(128) := '\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\cl';
    wwv_flow_imp.g_varchar2_table(129) := 'ftsWidth3\clwWidth3117\clcbpatraw17 \cellx9242\pard\plain \ltrpar'||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\intbl\wrap';
    wwv_flow_imp.g_varchar2_table(130) := 'default\aspalpha\aspnum\faauto\adjustright\rin0\lin0\yts15 \rtlch\fcs1 \af31507\afs22\alang1025 \ltr';
    wwv_flow_imp.g_varchar2_table(131) := 'ch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \ltrch\';
    wwv_flow_imp.g_varchar2_table(132) := 'fcs0 '||wwv_flow.LF||
'\b\insrsid11681118 PARTICULARS}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid11681118\charrsid116';
    wwv_flow_imp.g_varchar2_table(133) := '81118 \cell }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \b\insrsid11681118 DEBIT}{\rtlch\fcs1 \af31507 \ltrch';
    wwv_flow_imp.g_varchar2_table(134) := '\fcs0 \insrsid11681118\charrsid11681118 \cell }{\rtlch\fcs1 '||wwv_flow.LF||
'\af31507 \ltrch\fcs0 \b\insrsid1168111';
    wwv_flow_imp.g_varchar2_table(135) := '8 CREDIT}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid11681118\charrsid11681118 \cell }\pard\plain \ltr';
    wwv_flow_imp.g_varchar2_table(136) := 'par\ql \li0\ri0\sa160\sl259\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\r';
    wwv_flow_imp.g_varchar2_table(137) := 'in0\lin0 '||wwv_flow.LF||
'\rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\l';
    wwv_flow_imp.g_varchar2_table(138) := 'angnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid11681118 \trowd \irow0\irowband0\lt';
    wwv_flow_imp.g_varchar2_table(139) := 'rrow\ts15\trgaph108\trleft-108\trhdr\trbrdrt\brdrs\brdrw10 '||wwv_flow.LF||
'\trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\b';
    wwv_flow_imp.g_varchar2_table(140) := 'rdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidt';
    wwv_flow_imp.g_varchar2_table(141) := 'hB3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid11681118\tbllkhd';
    wwv_flow_imp.g_varchar2_table(142) := 'rrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdr';
    wwv_flow_imp.g_varchar2_table(143) := 's\brdrw10 \clbrdrb\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth31';
    wwv_flow_imp.g_varchar2_table(144) := '16\clcbpatraw17 \cellx3008\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brd';
    wwv_flow_imp.g_varchar2_table(145) := 'rw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth3117\clcbpatraw17 '||wwv_flow.LF||
'\cellx6125\c';
    wwv_flow_imp.g_varchar2_table(146) := 'lvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 ';
    wwv_flow_imp.g_varchar2_table(147) := '\clcbpat17\cltxlrtb\clftsWidth3\clwWidth3117\clcbpatraw17 \cellx9242\row \ltrrow}\trowd \irow1\irowb';
    wwv_flow_imp.g_varchar2_table(148) := 'and1\lastrow \ltrrow'||wwv_flow.LF||
'\ts15\trgaph108\trleft-108\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrd';
    wwv_flow_imp.g_varchar2_table(149) := 'rb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1';
    wwv_flow_imp.g_varchar2_table(150) := '\trftsWidthB3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid116811';
    wwv_flow_imp.g_varchar2_table(151) := '18\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrs\brdrw10 \cl';
    wwv_flow_imp.g_varchar2_table(152) := 'brdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth31';
    wwv_flow_imp.g_varchar2_table(153) := '16\clshdrawnil \cellx3008\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdr';
    wwv_flow_imp.g_varchar2_table(154) := 'w10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth3117\clshdrawnil \cellx6125\clvertalt'||wwv_flow.LF||
'\clb';
    wwv_flow_imp.g_varchar2_table(155) := 'rdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\cl';
    wwv_flow_imp.g_varchar2_table(156) := 'ftsWidth3\clwWidth3117\clshdrawnil \cellx9242\pard\plain \ltrpar'||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\intbl\wrapd';
    wwv_flow_imp.g_varchar2_table(157) := 'efault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid11681118\yts15 \rtlch\fcs1 \af31507\afs2';
    wwv_flow_imp.g_varchar2_table(158) := '2\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\field\flddi';
    wwv_flow_imp.g_varchar2_table(159) := 'rty{\*\fldinst {'||wwv_flow.LF||
'\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\insrsid11681118\charrsid11681118 {\*\bkmksta';
    wwv_flow_imp.g_varchar2_table(160) := 'rt Text1} FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\insrsid11681118\charrsid11681118 {\*\data';
    wwv_flow_imp.g_varchar2_table(161) := 'field '||wwv_flow.LF||
'80010000000000000554657874310002462000000000000f3c3f7265663a78646f303030313f3e0000000000}{\*';
    wwv_flow_imp.g_varchar2_table(162) := '\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text1}{\*\ffdeftext F }{\*\ffstattext <';
    wwv_flow_imp.g_varchar2_table(163) := '?ref:xdo0001?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\cf9\lang1024\langfe1024\noproof\in';
    wwv_flow_imp.g_varchar2_table(164) := 'srsid11681118\charrsid11681118 F }}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sf';
    wwv_flow_imp.g_varchar2_table(165) := 'tnbj {\*\bkmkend Text1}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid1168111';
    wwv_flow_imp.g_varchar2_table(166) := '8\charrsid11681118 '||wwv_flow.LF||
'{\*\bkmkstart Text2} FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid116811';
    wwv_flow_imp.g_varchar2_table(167) := '18\charrsid11681118 {\*\datafield 8001000000000000055465787432000b504152544943554c41525300000000000f';
    wwv_flow_imp.g_varchar2_table(168) := '3c3f7265663a78646f303030323f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\';
    wwv_flow_imp.g_varchar2_table(169) := 'ffname Text2}{\*\ffdeftext PARTICULARS}{\*\ffstattext <?ref:xdo0002?>}}}}}{\fldrslt {\rtlch\fcs1 \af';
    wwv_flow_imp.g_varchar2_table(170) := '31507 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid11681118\charrsid11681118 PARTICULARS}}}'||wwv_flow.LF||
'\sec';
    wwv_flow_imp.g_varchar2_table(171) := 'td \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \';
    wwv_flow_imp.g_varchar2_table(172) := 'insrsid11681118 {\*\bkmkend Text2}\cell }\pard \ltrpar\ql \li0\ri0\widctlpar\intbl\wrapdefault\aspal';
    wwv_flow_imp.g_varchar2_table(173) := 'pha\aspnum\faauto\adjustright\rin0\lin0\yts15 '||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \l';
    wwv_flow_imp.g_varchar2_table(174) := 'trch\fcs0 \insrsid11681118\charrsid11681118 {\*\bkmkstart Text3} FORMTEXT }{\rtlch\fcs1 \af31507 \lt';
    wwv_flow_imp.g_varchar2_table(175) := 'rch\fcs0 \insrsid11681118\charrsid11681118 {\*\datafield '||wwv_flow.LF||
'80010000000000000554657874330005444542495';
    wwv_flow_imp.g_varchar2_table(176) := '400000000000f3c3f7265663a78646f303030333f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fft';
    wwv_flow_imp.g_varchar2_table(177) := 'ypetxt0{\*\ffname Text3}{\*\ffdeftext DEBIT}{\*\ffstattext <?ref:xdo0003?>}}}}}{\fldrslt {\rtlch\fcs';
    wwv_flow_imp.g_varchar2_table(178) := '1 \af31507 '||wwv_flow.LF||
'\ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid11681118\charrsid11681118 DEBIT}}}\sect';
    wwv_flow_imp.g_varchar2_table(179) := 'd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \i';
    wwv_flow_imp.g_varchar2_table(180) := 'nsrsid11681118 {\*\bkmkend Text3}\cell }\pard \ltrpar'||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\intbl\wrapdefault\aspa';
    wwv_flow_imp.g_varchar2_table(181) := 'lpha\aspnum\faauto\adjustright\rin0\lin0\pararsid11681118\yts15 {\field\flddirty{\*\fldinst {\rtlch\';
    wwv_flow_imp.g_varchar2_table(182) := 'fcs1 \af31507 \ltrch\fcs0 \insrsid11681118\charrsid11681118 {\*\bkmkstart Text4} FORMTEXT }{\rtlch\f';
    wwv_flow_imp.g_varchar2_table(183) := 'cs1 '||wwv_flow.LF||
'\af31507 \ltrch\fcs0 \insrsid11681118\charrsid11681118 {\*\datafield 8001000000000000055465787';
    wwv_flow_imp.g_varchar2_table(184) := '434000643524544495400000000000f3c3f7265663a78646f303030343f3e0000000000}{\*\formfield{\fftype0\ffown';
    wwv_flow_imp.g_varchar2_table(185) := 'help\ffownstat\fftypetxt0{\*\ffname Text4}{\*\ffdeftext '||wwv_flow.LF||
'CREDIT}{\*\ffstattext <?ref:xdo0004?>}}}}}';
    wwv_flow_imp.g_varchar2_table(186) := '{\fldrslt {\rtlch\fcs1 \af31507 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid11681118\charrsid116';
    wwv_flow_imp.g_varchar2_table(187) := '81118 CREDIT}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\*\bkmkend Text';
    wwv_flow_imp.g_varchar2_table(188) := '4}'||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\insrsid11681118\charrsid11681';
    wwv_flow_imp.g_varchar2_table(189) := '118 {\*\bkmkstart Text5} FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\insrsid11681118\charrsid11';
    wwv_flow_imp.g_varchar2_table(190) := '681118 {\*\datafield '||wwv_flow.LF||
'80010000000000000554657874350002204500000000000f3c3f7265663a78646f303030353f3';
    wwv_flow_imp.g_varchar2_table(191) := 'e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text5}{\*\ffdeftext  E}{';
    wwv_flow_imp.g_varchar2_table(192) := '\*\ffstattext <?ref:xdo0005?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\cf9\lang1024\langfe';
    wwv_flow_imp.g_varchar2_table(193) := '1024\noproof\insrsid11681118\charrsid11681118  E}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\s';
    wwv_flow_imp.g_varchar2_table(194) := 'ectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid11681118 {\*\bkmkend Text5}\cell }\par';
    wwv_flow_imp.g_varchar2_table(195) := 'd\plain \ltrpar'||wwv_flow.LF||
'\ql \li0\ri0\sa160\sl259\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto';
    wwv_flow_imp.g_varchar2_table(196) := '\adjustright\rin0\lin0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe';
    wwv_flow_imp.g_varchar2_table(197) := '1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid11681118 \trowd \irow';
    wwv_flow_imp.g_varchar2_table(198) := '1\irowband1\lastrow \ltrrow\ts15\trgaph108\trleft-108\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \';
    wwv_flow_imp.g_varchar2_table(199) := 'trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsW';
    wwv_flow_imp.g_varchar2_table(200) := 'idth1\trftsWidthB3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid1';
    wwv_flow_imp.g_varchar2_table(201) := '1681118\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrs\brdrw1';
    wwv_flow_imp.g_varchar2_table(202) := '0 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWi';
    wwv_flow_imp.g_varchar2_table(203) := 'dth3116\clshdrawnil \cellx3008\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs';
    wwv_flow_imp.g_varchar2_table(204) := '\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth3117\clshdrawnil \cellx6125\clvertalt';
    wwv_flow_imp.g_varchar2_table(205) := ''||wwv_flow.LF||
'\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlr';
    wwv_flow_imp.g_varchar2_table(206) := 'tb\clftsWidth3\clwWidth3117\clshdrawnil \cellx9242\row }\pard \ltrpar\ql \li0\ri0\sa160\sl259\slmult';
    wwv_flow_imp.g_varchar2_table(207) := '1'||wwv_flow.LF||
'\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 {\rtlch\fcs1 \af31507 \';
    wwv_flow_imp.g_varchar2_table(208) := 'ltrch\fcs0 \insrsid15494459 '||wwv_flow.LF||
'\par }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid11681118 '||wwv_flow.LF||
'\par }{\*\t';
    wwv_flow_imp.g_varchar2_table(209) := 'hemedata 504b030414000600080000002100e9de0fbfff0000001c020000130000005b436f6e74656e745f54797065735d2';
    wwv_flow_imp.g_varchar2_table(210) := 'e786d6cac91cb4ec3301045f748fc83e52d4a'||wwv_flow.LF||
'9cb2400825e982c78ec7a27cc0c8992416c9d8b2a755fbf74cd25442a8201';
    wwv_flow_imp.g_varchar2_table(211) := '66c2cd933f79e3be372bd1f07b5c3989ca74aaff2422b24eb1b475da5df374fd9ad'||wwv_flow.LF||
'5689811a183c61a50f98f4babebc283';
    wwv_flow_imp.g_varchar2_table(212) := '7878049899a52a57be670674cb23d8e90721f90a4d2fa3802cb35762680fd800ecd7551dc18eb899138e3c943d7e503b6'||wwv_flow.LF||
'b';
    wwv_flow_imp.g_varchar2_table(213) := '01d583deee5f99824e290b4ba3f364eac4a430883b3c092d4eca8f946c916422ecab927f52ea42b89a1cd59c254f919b0e85';
    wwv_flow_imp.g_varchar2_table(214) := 'e6535d135a8de20f20b8c12c3b0'||wwv_flow.LF||
'0c895fcf6720192de6bf3b9e89ecdbd6596cbcdd8eb28e7c365ecc4ec1ff1460f53fe81';
    wwv_flow_imp.g_varchar2_table(215) := '3d3cc7f5b7f020000ffff0300504b030414000600080000002100a5d6'||wwv_flow.LF||
'a7e7c0000000360100000b0000005f72656c732f2';
    wwv_flow_imp.g_varchar2_table(216) := 'e72656c73848fcf6ac3300c87ef85bd83d17d51d2c31825762fa590432fa37d00e1287f68221bdb1bebdb4f'||wwv_flow.LF||
'c7060abb088';
    wwv_flow_imp.g_varchar2_table(217) := '4a4eff7a93dfeae8bf9e194e720169aaa06c3e2433fcb68e1763dbf7f82c985a4a725085b787086a37bdbb55fbc50d1a33cc';
    wwv_flow_imp.g_varchar2_table(218) := 'd311ba548b6309512'||wwv_flow.LF||
'0f88d94fbc52ae4264d1c910d24a45db3462247fa791715fd71f989e19e0364cd3f51652d73760ae8';
    wwv_flow_imp.g_varchar2_table(219) := 'fa8c9ffb3c330cc9e4fc17faf2ce545046e37944c69e462'||wwv_flow.LF||
'a1a82fe353bd90a865aad41ed0b5b8f9d6fd010000ffff03005';
    wwv_flow_imp.g_varchar2_table(220) := '04b0304140006000800000021006b799616830000008a0000001c0000007468656d652f746865'||wwv_flow.LF||
'6d652f7468656d654d616';
    wwv_flow_imp.g_varchar2_table(221) := 'e616765722e786d6c0ccc4d0ac3201040e17da17790d93763bb284562b2cbaebbf600439c1a41c7a0d29fdbd7e5e38337ced';
    wwv_flow_imp.g_varchar2_table(222) := 'f14d59b'||wwv_flow.LF||
'4b0d592c9c070d8a65cd2e88b7f07c2ca71ba8da481cc52c6ce1c715e6e97818c9b48d13df49c873517d23d5908';
    wwv_flow_imp.g_varchar2_table(223) := '5adb5dd20d6b52bd521ef2cdd5eb9246a3d8b'||wwv_flow.LF||
'4757e8d3f729e245eb2b260a0238fd010000ffff0300504b0304140006000';
    wwv_flow_imp.g_varchar2_table(224) := '80000002100b6f4679893070000c9200000160000007468656d652f7468656d652f'||wwv_flow.LF||
'7468656d65312e786d6cec59cd8b1bc';
    wwv_flow_imp.g_varchar2_table(225) := '915bf07f23f347d97f5d5ad8fc1f2a24fcfda33b6b164873dd648a5eef2547789aad28cc56208de532e81c026e49085bd'||wwv_flow.LF||
'e';
    wwv_flow_imp.g_varchar2_table(226) := 'd21842cecc22eb9e48f31d8249b3f22afaa5bdd5552c99e191c3061463074977eefd5afde7bf5de53d5ddcf5e26d4bbc05c1';
    wwv_flow_imp.g_varchar2_table(227) := '096f6fcfa9d9aefe174ce16248d'||wwv_flow.LF||
'7afeb3d9a4d2f13d2151ba4094a5b8e76fb0f03fbbf7eb5fdd454732c609f6403e1547a';
    wwv_flow_imp.g_varchar2_table(228) := '8e7c752ae8eaa5531876124eeb0154ee1bb25e30992f0caa3ea82a34b'||wwv_flow.LF||
'd09bd06aa3566b55134452df4b51026a1f2f97648';
    wwv_flow_imp.g_varchar2_table(229) := 'ebd9952e9dfdb2a1f53784da5500373caa74a35b6243476715e5708b11143cabd0b447b3eccb3609733fc52'||wwv_flow.LF||
'fa1e4542c21';
    wwv_flow_imp.g_varchar2_table(230) := '73dbfa6fffceabdbb5574940b517940d6909be8bf5c2e17589c37f49c3c3a2b260d823068f50bfd1a40e53e6edc1eb7c6ad4';
    wwv_flow_imp.g_varchar2_table(231) := '29f06a0f91c569a71'||wwv_flow.LF||
'b175b61bc320c71aa0ecd1a17bd41e35eb16ded0dfdce3dc0fd5c7c26b50a63fd8c34f2643b0a285d';
    wwv_flow_imp.g_varchar2_table(232) := '7a00c1feee1c3417730b2f56b50866fede1dbb5fe28685b'||wwv_flow.LF||
'fa3528a6243ddf43d7c25673b85d6d0159327aec8477c360d26';
    wwv_flow_imp.g_varchar2_table(233) := 'ee4ca4b144443115d6a8a254be5a1584bd00bc6270050408a24493db959e1259a43140f112567'||wwv_flow.LF||
'9c7827248a21f05628650';
    wwv_flow_imp.g_varchar2_table(234) := '2866b8ddaa4d684ffea13e827ed5174849121ad780113b137a4f87862cec94af6fc07a0d537206f7ffef9cdeb1fdfbcfee9c';
    wwv_flow_imp.g_varchar2_table(235) := 'd575fbd'||wwv_flow.LF||
'79fdf77c6eadca923b466964cafdf2dd1ffef3cd6fbd7ffff0ed2f5fff319b7a172f4cfcbbbffdeedd3ffef93ef';
    wwv_flow_imp.g_varchar2_table(236) := '5b0e2d2146ffff4fdbb1fbf7ffbe7dfffebaf'||wwv_flow.LF||
'5f3bb4f7393a33e1339260e13dc297de5396c0021dfcf119bf9ec42c46c49';
    wwv_flow_imp.g_varchar2_table(237) := '4e8a791402952b338f48f656ca11f6d10450edc00db767cce21d5b880f7d72f2cc2'||wwv_flow.LF||
'd398af2571687c182716f094313a60d';
    wwv_flow_imp.g_varchar2_table(238) := 'c6985876a2ec3ccb3751ab927e76b13f714a10bd7dc43945a5e1eaf579063894be530c616cd2714a5124538c5d253dfb1'||wwv_flow.LF||
'7';
    wwv_flow_imp.g_varchar2_table(239) := '38c1dabfb8210cbaea764ce99604be97d41bc01224e93ccc899154da5d03149c02f1b1741f0b7659bd3e7de8051d7aa47f8c';
    wwv_flow_imp.g_varchar2_table(240) := '246c2de40d4417e86a965c6fb68'||wwv_flow.LF||
'2d51e252394309350d7e8264ec2239ddf0b9891b0b099e8e3065de78818570c93ce6b05';
    wwv_flow_imp.g_varchar2_table(241) := 'ec3e90f21cdb8dd7e4a37898de4929cbb749e20c64ce4889d0f6394ac'||wwv_flow.LF||
'5cd829496313fbb938871045de13265df05366ef1';
    wwv_flow_imp.g_varchar2_table(242) := '0f50e7e40e941773f27d872f787b3c133c8b026a53240d4376beef0e57dccacf89d6ee8126157aae9f3c44a'||wwv_flow.LF||
'b17d4e9cd13';
    wwv_flow_imp.g_varchar2_table(243) := '1584756689f604cd1255a60ec3dfbdcc160c05696cd4bd20f62c82ac7d815580f901dabea3dc5027a25d5dcece7c91322ac9';
    wwv_flow_imp.g_varchar2_table(244) := '09de2881de073bad9'||wwv_flow.LF||
'493c1b9426881fd2fc08bc6eda7c0ca52e7105c0633a3f37818f08f480102f4ea33c16a0c308ee835';
    wwv_flow_imp.g_varchar2_table(245) := 'a9fc4c82a60ea5db8e375c32dff5d658fc1be7c61d1b8c2'||wwv_flow.LF||
'be04197c6d1948eca6cc7b6d3343d49aa00c9819822ec3956e4';
    wwv_flow_imp.g_varchar2_table(246) := '1c4727f29a28aab165b3be596f6a62ddd00dd91d5f42424fd6007b4d3fb84ffbbde073a8cb77f'||wwv_flow.LF||
'f9c6b10f3e4ebfe3566c2';
    wwv_flow_imp.g_varchar2_table(247) := '5ab6b763a8792c9f14e7f7308b7dbd50c195f904fbfa919a175fa04431dd9cf58b73dcd6d4fe3ffdff73487f6f36d2773a8d';
    wwv_flow_imp.g_varchar2_table(248) := 'fb8ed64'||wwv_flow.LF||
'7ce8306e3b99fc70e5e3743265f3027d8d3af0c80e7af4b14f72f0d46749289dca0dc527421ffc08f83db398c0a';
    wwv_flow_imp.g_varchar2_table(249) := '092d3279eb838055cc5f0a8ca1c4c60e1228e'||wwv_flow.LF||
'b48cc799fc0d91f134462b381daafb4a492472d591f0564cc0a1911e76ea5';
    wwv_flow_imp.g_varchar2_table(250) := '678ba4e4ed9223becacd7d5c16656590592e5782d2cc6e1a04a66e856bb3cc02bd4'||wwv_flow.LF||
'6bb6913e68dd1250b2d721614c66936';
    wwv_flow_imp.g_varchar2_table(251) := '83a48b4b783ca48fa58178ce620a157f65158741d2c3a4afdd6557b2c805ae115f8c1edc1cff49e1f06200242701e07cd'||wwv_flow.LF||
'f';
    wwv_flow_imp.g_varchar2_table(252) := '942f92973f5d6bbda991fd3d3878c69450034d8db08283ddd555c0f2e4fad2e0bb52b78da2261849b4d425b46377822869fc';
    wwv_flow_imp.g_varchar2_table(253) := '17974aad1abd0b8aeafbba54b2d'||wwv_flow.LF||
'7aca147a3e08ad9246bbf33e1637f535c8ede6069a9a9982a6de65cf6f35430899395af';
    wwv_flow_imp.g_varchar2_table(254) := '5fc251c1ac363b282d811ea3717a211dcbccc25cf36fc4d32cb8a0b39'||wwv_flow.LF||
'4222ce0cae934e960d122231f728497abe5a7ee10';
    wwv_flow_imp.g_varchar2_table(255) := '69aea1ca2b9d51b90103e59725d482b9f1a3970baed64bc5ce2b934dd6e8c284b67af90e1b35ce1fc568bdf'||wwv_flow.LF||
'1cac24d91ad';
    wwv_flow_imp.g_varchar2_table(256) := 'c3d8d1797de195df3a708422c6cd795011744c0dd413db3e682c0655891c8caf8db294c79da356fa3740c65e388ae6294571';
    wwv_flow_imp.g_varchar2_table(257) := '4339967709dca0b3a'||wwv_flow.LF||
'faadb081f196af190c6a98242f8467912ab0a651ad6a5a548d8cc3c1aafb6121653923699635d3ca2';
    wwv_flow_imp.g_varchar2_table(258) := 'aaa6abab39835c3b60cecd8f26645de60b53531e434b3c2'||wwv_flow.LF||
'67a97b37e576b7b96ea74f28aa0418bcb09fa3ea5ea12018d4c';
    wwv_flow_imp.g_varchar2_table(259) := 'ac92c6a8af17e1a56393b1fb56bc776811fa07695226164fdd656ed8edd8a1ae19c0e066f54f9'||wwv_flow.LF||
'416e376a6168b9ed2bb5a';
    wwv_flow_imp.g_varchar2_table(260) := '5f5adb979b1cdce5e40f2184197bba6526857c2c92e47d0104d754f92a50dd8222f65be35e0c95b73d2f3bfac85fd60d8088';
    wwv_flow_imp.g_varchar2_table(261) := '7955a27'||wwv_flow.LF||
'1c57826650ab74c27eb3d20fc3667d1cd66ba341e31514161927f530bbb19fc00506dde4f7f67a7cefee3ed9ded';
    wwv_flow_imp.g_varchar2_table(262) := '1dc99b3a4caf4dd7c5513d777f7f5c6e1bb7b'||wwv_flow.LF||
'8f40d2f9b2d598749bdd41abd26df627956034e854bac3d6a0326a0ddba3c';
    wwv_flow_imp.g_varchar2_table(263) := '9681876ba9357be77a1c141bf390c5ae34ea5551f0e2b41aba6e877ba9576d068f4'||wwv_flow.LF||
'8376bf330efaaff23606569ea58fdc1';
    wwv_flow_imp.g_varchar2_table(264) := '6605ecdebde7f010000ffff0300504b0304140006000800000021000dd1909fb60000001b010000270000007468656d65'||wwv_flow.LF||
'2';
    wwv_flow_imp.g_varchar2_table(265) := 'f7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73848f4d0ac2301484f78277086f6fd3ba1';
    wwv_flow_imp.g_varchar2_table(266) := '09126dd88d0add40384e4350d36'||wwv_flow.LF||
'3f2451eced0dae2c082e8761be9969bb979dc9136332de3168aa1a083ae995719ac16db';
    wwv_flow_imp.g_varchar2_table(267) := '8ec8e4052164e89d93b64b060828e6f37ed1567914b284d262452282e'||wwv_flow.LF||
'3198720e274a939cd08a54f980ae38a38f56e422a';
    wwv_flow_imp.g_varchar2_table(268) := '3a641c8bbd048f7757da0f19b017cc524bd62107bd5001996509affb3fd381a89672f1f165dfe514173d985'||wwv_flow.LF||
'0528a2c6cce';
    wwv_flow_imp.g_varchar2_table(269) := '0239baa4c04ca5bbabac4df000000ffff0300504b01022d0014000600080000002100e9de0fbfff0000001c0200001300000';
    wwv_flow_imp.g_varchar2_table(270) := '00000000000000000'||wwv_flow.LF||
'0000000000005b436f6e74656e745f54797065735d2e786d6c504b01022d001400060008000000210';
    wwv_flow_imp.g_varchar2_table(271) := '0a5d6a7e7c0000000360100000b00000000000000000000'||wwv_flow.LF||
'000000300100005f72656c732f2e72656c73504b01022d00140';
    wwv_flow_imp.g_varchar2_table(272) := '006000800000021006b799616830000008a0000001c0000000000000000000000000019020000'||wwv_flow.LF||
'7468656d652f7468656d6';
    wwv_flow_imp.g_varchar2_table(273) := '52f7468656d654d616e616765722e786d6c504b01022d0014000600080000002100b6f4679893070000c9200000160000000';
    wwv_flow_imp.g_varchar2_table(274) := '0000000'||wwv_flow.LF||
'000000000000d60200007468656d652f7468656d652f7468656d65312e786d6c504b01022d00140006000800000';
    wwv_flow_imp.g_varchar2_table(275) := '021000dd1909fb60000001b01000027000000'||wwv_flow.LF||
'000000000000000000009d0a00007468656d652f7468656d652f5f72656c7';
    wwv_flow_imp.g_varchar2_table(276) := '32f7468656d654d616e616765722e786d6c2e72656c73504b050600000000050005005d010000980b00000000}'||wwv_flow.LF||
'{\*\colo';
    wwv_flow_imp.g_varchar2_table(277) := 'rschememapping 3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554462d3822207374616e646';
    wwv_flow_imp.g_varchar2_table(278) := '16c6f6e653d22796573223f3e0d0a3c613a636c724d'||wwv_flow.LF||
'617020786d6c6e733a613d22687474703a2f2f736368656d61732e6';
    wwv_flow_imp.g_varchar2_table(279) := 'f70656e786d6c666f726d6174732e6f72672f64726177696e676d6c2f323030362f6d6169'||wwv_flow.LF||
'6e22206267313d226c7431222';
    wwv_flow_imp.g_varchar2_table(280) := '07478313d22646b3122206267323d226c743222207478323d22646b322220616363656e74313d22616363656e74312220616';
    wwv_flow_imp.g_varchar2_table(281) := '363'||wwv_flow.LF||
'656e74323d22616363656e74322220616363656e74333d22616363656e74332220616363656e74343d22616363656e7';
    wwv_flow_imp.g_varchar2_table(282) := '4342220616363656e74353d22616363656e74352220616363656e74363d22616363656e74362220686c696e6b3d22686c696';
    wwv_flow_imp.g_varchar2_table(283) := 'e6b2220666f6c486c696e6b3d22666f6c486c696e6b222f3e}'||wwv_flow.LF||
'{\*\latentstyles\lsdstimax371\lsdlockeddef0\lsds';
    wwv_flow_imp.g_varchar2_table(284) := 'emihiddendef0\lsdunhideuseddef0\lsdqformatdef0\lsdprioritydef99{\lsdlockedexcept \lsdqformat1 \lsdpr';
    wwv_flow_imp.g_varchar2_table(285) := 'iority0 \lsdlocked0 Normal;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 1;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdun';
    wwv_flow_imp.g_varchar2_table(286) := 'hideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 2;\lsdsemihidden1 \lsdunhideused1 \lsdqform';
    wwv_flow_imp.g_varchar2_table(287) := 'at1 \lsdpriority9 \lsdlocked0 heading 3;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \';
    wwv_flow_imp.g_varchar2_table(288) := 'lsdlocked0 heading 4;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 headin';
    wwv_flow_imp.g_varchar2_table(289) := 'g 5;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 6;\lsdsemihidden1';
    wwv_flow_imp.g_varchar2_table(290) := ' \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 7;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 ';
    wwv_flow_imp.g_varchar2_table(291) := '\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 8;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpr';
    wwv_flow_imp.g_varchar2_table(292) := 'iority9 \lsdlocked0 heading 9;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 1;'||wwv_flow.LF||
'\lsdsemihidden1 ';
    wwv_flow_imp.g_varchar2_table(293) := '\lsdunhideused1 \lsdlocked0 index 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 3;\lsdsemihidd';
    wwv_flow_imp.g_varchar2_table(294) := 'en1 \lsdunhideused1 \lsdlocked0 index 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 5;'||wwv_flow.LF||
'\lsdse';
    wwv_flow_imp.g_varchar2_table(295) := 'mihidden1 \lsdunhideused1 \lsdlocked0 index 6;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 7;\l';
    wwv_flow_imp.g_varchar2_table(296) := 'sdsemihidden1 \lsdunhideused1 \lsdlocked0 index 8;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index ';
    wwv_flow_imp.g_varchar2_table(297) := '9;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 1;\lsdsemihidden1 \lsdunhideused1';
    wwv_flow_imp.g_varchar2_table(298) := ' \lsdpriority39 \lsdlocked0 toc 2;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 3;';
    wwv_flow_imp.g_varchar2_table(299) := ''||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 4;\lsdsemihidden1 \lsdunhideused1 \l';
    wwv_flow_imp.g_varchar2_table(300) := 'sdpriority39 \lsdlocked0 toc 5;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 6;'||wwv_flow.LF||
'\l';
    wwv_flow_imp.g_varchar2_table(301) := 'sdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 7;\lsdsemihidden1 \lsdunhideused1 \lsdp';
    wwv_flow_imp.g_varchar2_table(302) := 'riority39 \lsdlocked0 toc 8;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 9;\lsdsem';
    wwv_flow_imp.g_varchar2_table(303) := 'ihidden1 \lsdunhideused1 \lsdlocked0 Normal Indent;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 foo';
    wwv_flow_imp.g_varchar2_table(304) := 'tnote text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 annotation text;\lsdsemihidden1 \lsdunhideuse';
    wwv_flow_imp.g_varchar2_table(305) := 'd1 \lsdlocked0 header;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 footer;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhid';
    wwv_flow_imp.g_varchar2_table(306) := 'eused1 \lsdlocked0 index heading;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority35 \lsdloc';
    wwv_flow_imp.g_varchar2_table(307) := 'ked0 caption;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 table of figures;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhi';
    wwv_flow_imp.g_varchar2_table(308) := 'deused1 \lsdlocked0 envelope address;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 envelope return;\ls';
    wwv_flow_imp.g_varchar2_table(309) := 'dsemihidden1 \lsdunhideused1 \lsdlocked0 footnote reference;\lsdsemihidden1 \lsdunhideused1 \lsdlock';
    wwv_flow_imp.g_varchar2_table(310) := 'ed0 annotation reference;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 line number;\lsdsemihidden1 \';
    wwv_flow_imp.g_varchar2_table(311) := 'lsdunhideused1 \lsdlocked0 page number;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 endnote reference';
    wwv_flow_imp.g_varchar2_table(312) := ';\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 endnote text;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlock';
    wwv_flow_imp.g_varchar2_table(313) := 'ed0 table of authorities;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 macro;\lsdsemihidden1 \lsdunhid';
    wwv_flow_imp.g_varchar2_table(314) := 'eused1 \lsdlocked0 toa heading;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List;'||wwv_flow.LF||
'\lsdsemihidden1 \l';
    wwv_flow_imp.g_varchar2_table(315) := 'sdunhideused1 \lsdlocked0 List Bullet;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number;\lsdse';
    wwv_flow_imp.g_varchar2_table(316) := 'mihidden1 \lsdunhideused1 \lsdlocked0 List 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List 3;'||wwv_flow.LF||
'\l';
    wwv_flow_imp.g_varchar2_table(317) := 'sdsemihidden1 \lsdunhideused1 \lsdlocked0 List 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List 5;';
    wwv_flow_imp.g_varchar2_table(318) := '\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(319) := '0 List Bullet 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 4;\lsdsemihidden1 \lsdunhi';
    wwv_flow_imp.g_varchar2_table(320) := 'deused1 \lsdlocked0 List Bullet 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number 2;\lsdsemi';
    wwv_flow_imp.g_varchar2_table(321) := 'hidden1 \lsdunhideused1 \lsdlocked0 List Number 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List';
    wwv_flow_imp.g_varchar2_table(322) := ' Number 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number 5;\lsdqformat1 \lsdpriority10 \lsd';
    wwv_flow_imp.g_varchar2_table(323) := 'locked0 Title;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Closing;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 ';
    wwv_flow_imp.g_varchar2_table(324) := '\lsdlocked0 Signature;\lsdsemihidden1 \lsdunhideused1 \lsdpriority1 \lsdlocked0 Default Paragraph Fo';
    wwv_flow_imp.g_varchar2_table(325) := 'nt;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(326) := ' Body Text Indent;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue;\lsdsemihidden1 \lsdun';
    wwv_flow_imp.g_varchar2_table(327) := 'hideused1 \lsdlocked0 List Continue 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue 3;\l';
    wwv_flow_imp.g_varchar2_table(328) := 'sdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue 4;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlock';
    wwv_flow_imp.g_varchar2_table(329) := 'ed0 List Continue 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Message Header;\lsdqformat1 \lsdprio';
    wwv_flow_imp.g_varchar2_table(330) := 'rity11 \lsdlocked0 Subtitle;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Salutation;'||wwv_flow.LF||
'\lsdsemihidden1';
    wwv_flow_imp.g_varchar2_table(331) := ' \lsdunhideused1 \lsdlocked0 Date;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text First Indent';
    wwv_flow_imp.g_varchar2_table(332) := ';\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text First Indent 2;\lsdsemihidden1 \lsdunhideused';
    wwv_flow_imp.g_varchar2_table(333) := '1 \lsdlocked0 Note Heading;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text 2;\lsdsemihidden1';
    wwv_flow_imp.g_varchar2_table(334) := ' \lsdunhideused1 \lsdlocked0 Body Text 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text Inden';
    wwv_flow_imp.g_varchar2_table(335) := 't 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text Indent 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1';
    wwv_flow_imp.g_varchar2_table(336) := ' \lsdlocked0 Block Text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Hyperlink;\lsdsemihidden1 \lsdun';
    wwv_flow_imp.g_varchar2_table(337) := 'hideused1 \lsdlocked0 FollowedHyperlink;\lsdqformat1 \lsdpriority22 \lsdlocked0 Strong;'||wwv_flow.LF||
'\lsdqformat';
    wwv_flow_imp.g_varchar2_table(338) := '1 \lsdpriority20 \lsdlocked0 Emphasis;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Document Map;\lsds';
    wwv_flow_imp.g_varchar2_table(339) := 'emihidden1 \lsdunhideused1 \lsdlocked0 Plain Text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 E-mail';
    wwv_flow_imp.g_varchar2_table(340) := ' Signature;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Top of Form;\lsdsemihidden1 \lsdunhide';
    wwv_flow_imp.g_varchar2_table(341) := 'used1 \lsdlocked0 HTML Bottom of Form;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Normal (Web);\lsds';
    wwv_flow_imp.g_varchar2_table(342) := 'emihidden1 \lsdunhideused1 \lsdlocked0 HTML Acronym;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HT';
    wwv_flow_imp.g_varchar2_table(343) := 'ML Address;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Cite;\lsdsemihidden1 \lsdunhideused1 \ls';
    wwv_flow_imp.g_varchar2_table(344) := 'dlocked0 HTML Code;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Definition;'||wwv_flow.LF||
'\lsdsemihidden1 \ls';
    wwv_flow_imp.g_varchar2_table(345) := 'dunhideused1 \lsdlocked0 HTML Keyboard;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Preformatted';
    wwv_flow_imp.g_varchar2_table(346) := ';\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Sample;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(347) := ' HTML Typewriter;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Variable;\lsdsemihidden1 \lsdunh';
    wwv_flow_imp.g_varchar2_table(348) := 'ideused1 \lsdlocked0 Normal Table;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 annotation subject;\ls';
    wwv_flow_imp.g_varchar2_table(349) := 'dsemihidden1 \lsdunhideused1 \lsdlocked0 No List;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Outli';
    wwv_flow_imp.g_varchar2_table(350) := 'ne List 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Outline List 2;\lsdsemihidden1 \lsdunhideused1';
    wwv_flow_imp.g_varchar2_table(351) := ' \lsdlocked0 Outline List 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Simple 1;'||wwv_flow.LF||
'\lsdsemihid';
    wwv_flow_imp.g_varchar2_table(352) := 'den1 \lsdunhideused1 \lsdlocked0 Table Simple 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Si';
    wwv_flow_imp.g_varchar2_table(353) := 'mple 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Classic 1;\lsdsemihidden1 \lsdunhideused1 \';
    wwv_flow_imp.g_varchar2_table(354) := 'lsdlocked0 Table Classic 2;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Classic 3;\lsdsemihid';
    wwv_flow_imp.g_varchar2_table(355) := 'den1 \lsdunhideused1 \lsdlocked0 Table Classic 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table C';
    wwv_flow_imp.g_varchar2_table(356) := 'olorful 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Colorful 2;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideu';
    wwv_flow_imp.g_varchar2_table(357) := 'sed1 \lsdlocked0 Table Colorful 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 1;\lsdse';
    wwv_flow_imp.g_varchar2_table(358) := 'mihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Ta';
    wwv_flow_imp.g_varchar2_table(359) := 'ble Columns 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 4;\lsdsemihidden1 \lsdunhi';
    wwv_flow_imp.g_varchar2_table(360) := 'deused1 \lsdlocked0 Table Columns 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 1;\lsdsem';
    wwv_flow_imp.g_varchar2_table(361) := 'ihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 2;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Tabl';
    wwv_flow_imp.g_varchar2_table(362) := 'e Grid 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 4;\lsdsemihidden1 \lsdunhideused1 \l';
    wwv_flow_imp.g_varchar2_table(363) := 'sdlocked0 Table Grid 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 6;'||wwv_flow.LF||
'\lsdsemihidden1 \l';
    wwv_flow_imp.g_varchar2_table(364) := 'sdunhideused1 \lsdlocked0 Table Grid 7;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 8;\lsd';
    wwv_flow_imp.g_varchar2_table(365) := 'semihidden1 \lsdunhideused1 \lsdlocked0 Table List 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Tab';
    wwv_flow_imp.g_varchar2_table(366) := 'le List 2;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 3;\lsdsemihidden1 \lsdunhideused1';
    wwv_flow_imp.g_varchar2_table(367) := ' \lsdlocked0 Table List 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 5;\lsdsemihidden1 \';
    wwv_flow_imp.g_varchar2_table(368) := 'lsdunhideused1 \lsdlocked0 Table List 6;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 7;\';
    wwv_flow_imp.g_varchar2_table(369) := 'lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 8;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(370) := 'Table 3D effects 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table 3D effects 2;'||wwv_flow.LF||
'\lsdsemihidden1 ';
    wwv_flow_imp.g_varchar2_table(371) := '\lsdunhideused1 \lsdlocked0 Table 3D effects 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Con';
    wwv_flow_imp.g_varchar2_table(372) := 'temporary;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Elegant;\lsdsemihidden1 \lsdunhideused1 ';
    wwv_flow_imp.g_varchar2_table(373) := '\lsdlocked0 Table Professional;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Subtle 1;\lsdsemi';
    wwv_flow_imp.g_varchar2_table(374) := 'hidden1 \lsdunhideused1 \lsdlocked0 Table Subtle 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table';
    wwv_flow_imp.g_varchar2_table(375) := ' Web 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Web 2;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \ls';
    wwv_flow_imp.g_varchar2_table(376) := 'dlocked0 Table Web 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Balloon Text;\lsdpriority39 \lsdloc';
    wwv_flow_imp.g_varchar2_table(377) := 'ked0 Table Grid;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Theme;\lsdsemihidden1 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(378) := 'Placeholder Text;'||wwv_flow.LF||
'\lsdqformat1 \lsdpriority1 \lsdlocked0 No Spacing;\lsdpriority60 \lsdlocked0 Ligh';
    wwv_flow_imp.g_varchar2_table(379) := 't Shading;\lsdpriority61 \lsdlocked0 Light List;\lsdpriority62 \lsdlocked0 Light Grid;\lsdpriority63';
    wwv_flow_imp.g_varchar2_table(380) := ' \lsdlocked0 Medium Shading 1;\lsdpriority64 \lsdlocked0 Medium Shading 2;'||wwv_flow.LF||
'\lsdpriority65 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(381) := 'd0 Medium List 1;\lsdpriority66 \lsdlocked0 Medium List 2;\lsdpriority67 \lsdlocked0 Medium Grid 1;\';
    wwv_flow_imp.g_varchar2_table(382) := 'lsdpriority68 \lsdlocked0 Medium Grid 2;\lsdpriority69 \lsdlocked0 Medium Grid 3;\lsdpriority70 \lsd';
    wwv_flow_imp.g_varchar2_table(383) := 'locked0 Dark List;'||wwv_flow.LF||
'\lsdpriority71 \lsdlocked0 Colorful Shading;\lsdpriority72 \lsdlocked0 Colorful ';
    wwv_flow_imp.g_varchar2_table(384) := 'List;\lsdpriority73 \lsdlocked0 Colorful Grid;\lsdpriority60 \lsdlocked0 Light Shading Accent 1;\lsd';
    wwv_flow_imp.g_varchar2_table(385) := 'priority61 \lsdlocked0 Light List Accent 1;'||wwv_flow.LF||
'\lsdpriority62 \lsdlocked0 Light Grid Accent 1;\lsdprio';
    wwv_flow_imp.g_varchar2_table(386) := 'rity63 \lsdlocked0 Medium Shading 1 Accent 1;\lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 1;\l';
    wwv_flow_imp.g_varchar2_table(387) := 'sdpriority65 \lsdlocked0 Medium List 1 Accent 1;\lsdsemihidden1 \lsdlocked0 Revision;'||wwv_flow.LF||
'\lsdqformat1 ';
    wwv_flow_imp.g_varchar2_table(388) := '\lsdpriority34 \lsdlocked0 List Paragraph;\lsdqformat1 \lsdpriority29 \lsdlocked0 Quote;\lsdqformat1';
    wwv_flow_imp.g_varchar2_table(389) := ' \lsdpriority30 \lsdlocked0 Intense Quote;\lsdpriority66 \lsdlocked0 Medium List 2 Accent 1;\lsdprio';
    wwv_flow_imp.g_varchar2_table(390) := 'rity67 \lsdlocked0 Medium Grid 1 Accent 1;'||wwv_flow.LF||
'\lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 1;\lsdpr';
    wwv_flow_imp.g_varchar2_table(391) := 'iority69 \lsdlocked0 Medium Grid 3 Accent 1;\lsdpriority70 \lsdlocked0 Dark List Accent 1;\lsdpriori';
    wwv_flow_imp.g_varchar2_table(392) := 'ty71 \lsdlocked0 Colorful Shading Accent 1;\lsdpriority72 \lsdlocked0 Colorful List Accent 1;'||wwv_flow.LF||
'\lsdp';
    wwv_flow_imp.g_varchar2_table(393) := 'riority73 \lsdlocked0 Colorful Grid Accent 1;\lsdpriority60 \lsdlocked0 Light Shading Accent 2;\lsdp';
    wwv_flow_imp.g_varchar2_table(394) := 'riority61 \lsdlocked0 Light List Accent 2;\lsdpriority62 \lsdlocked0 Light Grid Accent 2;\lsdpriorit';
    wwv_flow_imp.g_varchar2_table(395) := 'y63 \lsdlocked0 Medium Shading 1 Accent 2;'||wwv_flow.LF||
'\lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 2;\ls';
    wwv_flow_imp.g_varchar2_table(396) := 'dpriority65 \lsdlocked0 Medium List 1 Accent 2;\lsdpriority66 \lsdlocked0 Medium List 2 Accent 2;\ls';
    wwv_flow_imp.g_varchar2_table(397) := 'dpriority67 \lsdlocked0 Medium Grid 1 Accent 2;\lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 2;'||wwv_flow.LF||
'\';
    wwv_flow_imp.g_varchar2_table(398) := 'lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 2;\lsdpriority70 \lsdlocked0 Dark List Accent 2;\lsdp';
    wwv_flow_imp.g_varchar2_table(399) := 'riority71 \lsdlocked0 Colorful Shading Accent 2;\lsdpriority72 \lsdlocked0 Colorful List Accent 2;\l';
    wwv_flow_imp.g_varchar2_table(400) := 'sdpriority73 \lsdlocked0 Colorful Grid Accent 2;'||wwv_flow.LF||
'\lsdpriority60 \lsdlocked0 Light Shading Accent 3;';
    wwv_flow_imp.g_varchar2_table(401) := '\lsdpriority61 \lsdlocked0 Light List Accent 3;\lsdpriority62 \lsdlocked0 Light Grid Accent 3;\lsdpr';
    wwv_flow_imp.g_varchar2_table(402) := 'iority63 \lsdlocked0 Medium Shading 1 Accent 3;\lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 3;';
    wwv_flow_imp.g_varchar2_table(403) := ''||wwv_flow.LF||
'\lsdpriority65 \lsdlocked0 Medium List 1 Accent 3;\lsdpriority66 \lsdlocked0 Medium List 2 Accent ';
    wwv_flow_imp.g_varchar2_table(404) := '3;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 3;\lsdpriority68 \lsdlocked0 Medium Grid 2 Accent ';
    wwv_flow_imp.g_varchar2_table(405) := '3;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 3;'||wwv_flow.LF||
'\lsdpriority70 \lsdlocked0 Dark List Accent 3;';
    wwv_flow_imp.g_varchar2_table(406) := '\lsdpriority71 \lsdlocked0 Colorful Shading Accent 3;\lsdpriority72 \lsdlocked0 Colorful List Accent';
    wwv_flow_imp.g_varchar2_table(407) := ' 3;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 3;\lsdpriority60 \lsdlocked0 Light Shading Accent';
    wwv_flow_imp.g_varchar2_table(408) := ' 4;'||wwv_flow.LF||
'\lsdpriority61 \lsdlocked0 Light List Accent 4;\lsdpriority62 \lsdlocked0 Light Grid Accent 4;\';
    wwv_flow_imp.g_varchar2_table(409) := 'lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 4;\lsdpriority64 \lsdlocked0 Medium Shading 2 Acce';
    wwv_flow_imp.g_varchar2_table(410) := 'nt 4;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 4;'||wwv_flow.LF||
'\lsdpriority66 \lsdlocked0 Medium List 2 Ac';
    wwv_flow_imp.g_varchar2_table(411) := 'cent 4;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 4;\lsdpriority68 \lsdlocked0 Medium Grid 2 Ac';
    wwv_flow_imp.g_varchar2_table(412) := 'cent 4;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 4;\lsdpriority70 \lsdlocked0 Dark List Accent';
    wwv_flow_imp.g_varchar2_table(413) := ' 4;'||wwv_flow.LF||
'\lsdpriority71 \lsdlocked0 Colorful Shading Accent 4;\lsdpriority72 \lsdlocked0 Colorful List A';
    wwv_flow_imp.g_varchar2_table(414) := 'ccent 4;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 4;\lsdpriority60 \lsdlocked0 Light Shading A';
    wwv_flow_imp.g_varchar2_table(415) := 'ccent 5;\lsdpriority61 \lsdlocked0 Light List Accent 5;'||wwv_flow.LF||
'\lsdpriority62 \lsdlocked0 Light Grid Accen';
    wwv_flow_imp.g_varchar2_table(416) := 't 5;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 5;\lsdpriority64 \lsdlocked0 Medium Shading 2';
    wwv_flow_imp.g_varchar2_table(417) := ' Accent 5;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 5;\lsdpriority66 \lsdlocked0 Medium List 2';
    wwv_flow_imp.g_varchar2_table(418) := ' Accent 5;'||wwv_flow.LF||
'\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 5;\lsdpriority68 \lsdlocked0 Medium Grid';
    wwv_flow_imp.g_varchar2_table(419) := ' 2 Accent 5;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 5;\lsdpriority70 \lsdlocked0 Dark List A';
    wwv_flow_imp.g_varchar2_table(420) := 'ccent 5;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 5;'||wwv_flow.LF||
'\lsdpriority72 \lsdlocked0 Colorful L';
    wwv_flow_imp.g_varchar2_table(421) := 'ist Accent 5;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 5;\lsdpriority60 \lsdlocked0 Light Shad';
    wwv_flow_imp.g_varchar2_table(422) := 'ing Accent 6;\lsdpriority61 \lsdlocked0 Light List Accent 6;\lsdpriority62 \lsdlocked0 Light Grid Ac';
    wwv_flow_imp.g_varchar2_table(423) := 'cent 6;'||wwv_flow.LF||
'\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 6;\lsdpriority64 \lsdlocked0 Medium Shad';
    wwv_flow_imp.g_varchar2_table(424) := 'ing 2 Accent 6;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 6;\lsdpriority66 \lsdlocked0 Medium L';
    wwv_flow_imp.g_varchar2_table(425) := 'ist 2 Accent 6;'||wwv_flow.LF||
'\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 6;\lsdpriority68 \lsdlocked0 Medium';
    wwv_flow_imp.g_varchar2_table(426) := ' Grid 2 Accent 6;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 6;\lsdpriority70 \lsdlocked0 Dark L';
    wwv_flow_imp.g_varchar2_table(427) := 'ist Accent 6;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 6;'||wwv_flow.LF||
'\lsdpriority72 \lsdlocked0 Color';
    wwv_flow_imp.g_varchar2_table(428) := 'ful List Accent 6;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 6;\lsdqformat1 \lsdpriority19 \lsd';
    wwv_flow_imp.g_varchar2_table(429) := 'locked0 Subtle Emphasis;\lsdqformat1 \lsdpriority21 \lsdlocked0 Intense Emphasis;'||wwv_flow.LF||
'\lsdqformat1 \lsd';
    wwv_flow_imp.g_varchar2_table(430) := 'priority31 \lsdlocked0 Subtle Reference;\lsdqformat1 \lsdpriority32 \lsdlocked0 Intense Reference;\l';
    wwv_flow_imp.g_varchar2_table(431) := 'sdqformat1 \lsdpriority33 \lsdlocked0 Book Title;\lsdsemihidden1 \lsdunhideused1 \lsdpriority37 \lsd';
    wwv_flow_imp.g_varchar2_table(432) := 'locked0 Bibliography;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority39 \lsdlocked0 TOC H';
    wwv_flow_imp.g_varchar2_table(433) := 'eading;\lsdpriority41 \lsdlocked0 Plain Table 1;\lsdpriority42 \lsdlocked0 Plain Table 2;\lsdpriorit';
    wwv_flow_imp.g_varchar2_table(434) := 'y43 \lsdlocked0 Plain Table 3;\lsdpriority44 \lsdlocked0 Plain Table 4;'||wwv_flow.LF||
'\lsdpriority45 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(435) := 'Plain Table 5;\lsdpriority40 \lsdlocked0 Grid Table Light;\lsdpriority46 \lsdlocked0 Grid Table 1 Li';
    wwv_flow_imp.g_varchar2_table(436) := 'ght;\lsdpriority47 \lsdlocked0 Grid Table 2;\lsdpriority48 \lsdlocked0 Grid Table 3;\lsdpriority49 \';
    wwv_flow_imp.g_varchar2_table(437) := 'lsdlocked0 Grid Table 4;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 Grid Table 5 Dark;\lsdpriority51 \lsdlocked0 Gr';
    wwv_flow_imp.g_varchar2_table(438) := 'id Table 6 Colorful;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful;\lsdpriority46 \lsdlocked0 Grid';
    wwv_flow_imp.g_varchar2_table(439) := ' Table 1 Light Accent 1;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 1;'||wwv_flow.LF||
'\lsdpriority48 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(440) := '0 Grid Table 3 Accent 1;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 1;\lsdpriority50 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(441) := 'Grid Table 5 Dark Accent 1;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 1;'||wwv_flow.LF||
'\lsdpriority5';
    wwv_flow_imp.g_varchar2_table(442) := '2 \lsdlocked0 Grid Table 7 Colorful Accent 1;\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 2;';
    wwv_flow_imp.g_varchar2_table(443) := '\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 2;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 2;'||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(444) := '\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 2;\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent';
    wwv_flow_imp.g_varchar2_table(445) := ' 2;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 2;\lsdpriority52 \lsdlocked0 Grid Table 7';
    wwv_flow_imp.g_varchar2_table(446) := ' Colorful Accent 2;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 3;\lsdpriority47 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(447) := 'd0 Grid Table 2 Accent 3;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 3;\lsdpriority49 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(448) := ' Grid Table 4 Accent 3;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 3;\lsdpriority51 \lsdlo';
    wwv_flow_imp.g_varchar2_table(449) := 'cked0 Grid Table 6 Colorful Accent 3;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 3;\lsdp';
    wwv_flow_imp.g_varchar2_table(450) := 'riority46 \lsdlocked0 Grid Table 1 Light Accent 4;'||wwv_flow.LF||
'\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 4';
    wwv_flow_imp.g_varchar2_table(451) := ';\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 4;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 4;\';
    wwv_flow_imp.g_varchar2_table(452) := 'lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 4;'||wwv_flow.LF||
'\lsdpriority51 \lsdlocked0 Grid Table 6 Color';
    wwv_flow_imp.g_varchar2_table(453) := 'ful Accent 4;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 4;\lsdpriority46 \lsdlocked0 Gr';
    wwv_flow_imp.g_varchar2_table(454) := 'id Table 1 Light Accent 5;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 5;'||wwv_flow.LF||
'\lsdpriority48 \lsdlock';
    wwv_flow_imp.g_varchar2_table(455) := 'ed0 Grid Table 3 Accent 5;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 5;\lsdpriority50 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(456) := '0 Grid Table 5 Dark Accent 5;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 5;'||wwv_flow.LF||
'\lsdpriorit';
    wwv_flow_imp.g_varchar2_table(457) := 'y52 \lsdlocked0 Grid Table 7 Colorful Accent 5;\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent ';
    wwv_flow_imp.g_varchar2_table(458) := '6;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 6;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 6;';
    wwv_flow_imp.g_varchar2_table(459) := ''||wwv_flow.LF||
'\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 6;\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Acce';
    wwv_flow_imp.g_varchar2_table(460) := 'nt 6;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 6;\lsdpriority52 \lsdlocked0 Grid Table';
    wwv_flow_imp.g_varchar2_table(461) := ' 7 Colorful Accent 6;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 List Table 1 Light;\lsdpriority47 \lsdlocked0 List';
    wwv_flow_imp.g_varchar2_table(462) := ' Table 2;\lsdpriority48 \lsdlocked0 List Table 3;\lsdpriority49 \lsdlocked0 List Table 4;\lsdpriorit';
    wwv_flow_imp.g_varchar2_table(463) := 'y50 \lsdlocked0 List Table 5 Dark;'||wwv_flow.LF||
'\lsdpriority51 \lsdlocked0 List Table 6 Colorful;\lsdpriority52 ';
    wwv_flow_imp.g_varchar2_table(464) := '\lsdlocked0 List Table 7 Colorful;\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 1;\lsdpriorit';
    wwv_flow_imp.g_varchar2_table(465) := 'y47 \lsdlocked0 List Table 2 Accent 1;\lsdpriority48 \lsdlocked0 List Table 3 Accent 1;'||wwv_flow.LF||
'\lsdpriorit';
    wwv_flow_imp.g_varchar2_table(466) := 'y49 \lsdlocked0 List Table 4 Accent 1;\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 1;\lsdprio';
    wwv_flow_imp.g_varchar2_table(467) := 'rity51 \lsdlocked0 List Table 6 Colorful Accent 1;\lsdpriority52 \lsdlocked0 List Table 7 Colorful A';
    wwv_flow_imp.g_varchar2_table(468) := 'ccent 1;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 2;\lsdpriority47 \lsdlocked0 List Tab';
    wwv_flow_imp.g_varchar2_table(469) := 'le 2 Accent 2;\lsdpriority48 \lsdlocked0 List Table 3 Accent 2;\lsdpriority49 \lsdlocked0 List Table';
    wwv_flow_imp.g_varchar2_table(470) := ' 4 Accent 2;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 2;\lsdpriority51 \lsdlocked0 List ';
    wwv_flow_imp.g_varchar2_table(471) := 'Table 6 Colorful Accent 2;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 2;\lsdpriority46 \';
    wwv_flow_imp.g_varchar2_table(472) := 'lsdlocked0 List Table 1 Light Accent 3;'||wwv_flow.LF||
'\lsdpriority47 \lsdlocked0 List Table 2 Accent 3;\lsdpriori';
    wwv_flow_imp.g_varchar2_table(473) := 'ty48 \lsdlocked0 List Table 3 Accent 3;\lsdpriority49 \lsdlocked0 List Table 4 Accent 3;\lsdpriority';
    wwv_flow_imp.g_varchar2_table(474) := '50 \lsdlocked0 List Table 5 Dark Accent 3;'||wwv_flow.LF||
'\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent ';
    wwv_flow_imp.g_varchar2_table(475) := '3;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 3;\lsdpriority46 \lsdlocked0 List Table 1 ';
    wwv_flow_imp.g_varchar2_table(476) := 'Light Accent 4;\lsdpriority47 \lsdlocked0 List Table 2 Accent 4;'||wwv_flow.LF||
'\lsdpriority48 \lsdlocked0 List Ta';
    wwv_flow_imp.g_varchar2_table(477) := 'ble 3 Accent 4;\lsdpriority49 \lsdlocked0 List Table 4 Accent 4;\lsdpriority50 \lsdlocked0 List Tabl';
    wwv_flow_imp.g_varchar2_table(478) := 'e 5 Dark Accent 4;\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 4;'||wwv_flow.LF||
'\lsdpriority52 \lsdloc';
    wwv_flow_imp.g_varchar2_table(479) := 'ked0 List Table 7 Colorful Accent 4;\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 5;\lsdprior';
    wwv_flow_imp.g_varchar2_table(480) := 'ity47 \lsdlocked0 List Table 2 Accent 5;\lsdpriority48 \lsdlocked0 List Table 3 Accent 5;'||wwv_flow.LF||
'\lsdprior';
    wwv_flow_imp.g_varchar2_table(481) := 'ity49 \lsdlocked0 List Table 4 Accent 5;\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 5;\lsdpr';
    wwv_flow_imp.g_varchar2_table(482) := 'iority51 \lsdlocked0 List Table 6 Colorful Accent 5;\lsdpriority52 \lsdlocked0 List Table 7 Colorful';
    wwv_flow_imp.g_varchar2_table(483) := ' Accent 5;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 6;\lsdpriority47 \lsdlocked0 List T';
    wwv_flow_imp.g_varchar2_table(484) := 'able 2 Accent 6;\lsdpriority48 \lsdlocked0 List Table 3 Accent 6;\lsdpriority49 \lsdlocked0 List Tab';
    wwv_flow_imp.g_varchar2_table(485) := 'le 4 Accent 6;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 6;\lsdpriority51 \lsdlocked0 Lis';
    wwv_flow_imp.g_varchar2_table(486) := 't Table 6 Colorful Accent 6;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 6;}}{\*\datastor';
    wwv_flow_imp.g_varchar2_table(487) := 'e 010500000200000018000000'||wwv_flow.LF||
'4d73786d6c322e534158584d4c5265616465722e362e3000000000000000000000060000';
    wwv_flow_imp.g_varchar2_table(488) := ''||wwv_flow.LF||
'd0cf11e0a1b11ae1000000000000000000000000000000003e000300feff09000600000000000000000000000100000001';
    wwv_flow_imp.g_varchar2_table(489) := '0000000000000000100000feffffff00000000feffffff0000000000000000ffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(490) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(491) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(492) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(493) := 'ffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(494) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(495) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(496) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(497) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(498) := 'ffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffdfffffffeffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(499) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(500) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffff';
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
    wwv_flow_imp.g_varchar2_table(501) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(502) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(503) := 'ffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(504) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(505) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(506) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(507) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(508) := 'ffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffff52006f006f007400200045006e00740072';
    wwv_flow_imp.g_varchar2_table(509) := '0079000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000160005';
    wwv_flow_imp.g_varchar2_table(510) := '00ffffffffffffffffffffffff0c6ad98892f1d411a65f0040963251e5000000000000000000000000402a'||wwv_flow.LF||
'd5f3b370d801';
    wwv_flow_imp.g_varchar2_table(511) := 'feffffff00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(512) := '000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff0000000000000000';
    wwv_flow_imp.g_varchar2_table(513) := '0000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(514) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(515) := '000000000000000000ffffffffffffffffffffffff0000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000';
    wwv_flow_imp.g_varchar2_table(516) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(517) := '0000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(518) := '000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000001';
    wwv_flow_imp.g_varchar2_table(519) := '05000000000000}}';
wwv_flow_imp_shared.create_report_layout(
 p_id=>wwv_flow_imp.id(16225359072720949511)
,p_report_layout_name=>'Trial_balance'
,p_report_layout_type=>'RTF_FILE'
,p_varchar2_table=>wwv_flow_imp.g_varchar2_table
);
wwv_flow_imp.component_end;
end;
/
