prompt --application/shared_components/reports/report_layouts/comp_info
begin
--   Manifest
--     REPORT LAYOUT: comp_info
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
    wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
    wwv_flow_imp.g_varchar2_table(1) := '{\rtf1\adeflang1025\ansi\ansicpg1252\uc1\adeff0\deff0\stshfdbch0\stshfloch31506\stshfhich31506\stshf';
    wwv_flow_imp.g_varchar2_table(2) := 'bi31506\deflang1033\deflangfe1033\themelang1033\themelangfe0\themelangcs0{\fonttbl{\f0\fbidi \froman';
    wwv_flow_imp.g_varchar2_table(3) := '\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\f34\fbidi \froman\fcharset0\fprq2';
    wwv_flow_imp.g_varchar2_table(4) := '{\*\panose 02040503050406030204}Cambria Math;}'||wwv_flow.LF||
'{\f37\fbidi \fswiss\fcharset0\fprq2{\*\panose 020f05';
    wwv_flow_imp.g_varchar2_table(5) := '02020204030204}Calibri;}{\flomajor\f31500\fbidi \froman\fcharset0\fprq2{\*\panose 020206030504050203';
    wwv_flow_imp.g_varchar2_table(6) := '04}Times New Roman;}'||wwv_flow.LF||
'{\fdbmajor\f31501\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304';
    wwv_flow_imp.g_varchar2_table(7) := '}Times New Roman;}{\fhimajor\f31502\fbidi \fswiss\fcharset0\fprq2{\*\panose 020f0302020204030204}Cal';
    wwv_flow_imp.g_varchar2_table(8) := 'ibri Light;}'||wwv_flow.LF||
'{\fbimajor\f31503\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times N';
    wwv_flow_imp.g_varchar2_table(9) := 'ew Roman;}{\flominor\f31504\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New R';
    wwv_flow_imp.g_varchar2_table(10) := 'oman;}'||wwv_flow.LF||
'{\fdbminor\f31505\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Rom';
    wwv_flow_imp.g_varchar2_table(11) := 'an;}{\fhiminor\f31506\fbidi \fswiss\fcharset0\fprq2{\*\panose 020f0502020204030204}Calibri;}'||wwv_flow.LF||
'{\fbim';
    wwv_flow_imp.g_varchar2_table(12) := 'inor\f31507\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\f39\fbid';
    wwv_flow_imp.g_varchar2_table(13) := 'i \froman\fcharset238\fprq2 Times New Roman CE;}{\f40\fbidi \froman\fcharset204\fprq2 Times New Roma';
    wwv_flow_imp.g_varchar2_table(14) := 'n Cyr;}'||wwv_flow.LF||
'{\f42\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\f43\fbidi \froman\fcharset16';
    wwv_flow_imp.g_varchar2_table(15) := '2\fprq2 Times New Roman Tur;}{\f44\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\f45\f';
    wwv_flow_imp.g_varchar2_table(16) := 'bidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\f46\fbidi \froman\fcharset186\fprq2 Tim';
    wwv_flow_imp.g_varchar2_table(17) := 'es New Roman Baltic;}{\f47\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\f379\fbid';
    wwv_flow_imp.g_varchar2_table(18) := 'i \froman\fcharset238\fprq2 Cambria Math CE;}{\f380\fbidi \froman\fcharset204\fprq2 Cambria Math Cyr';
    wwv_flow_imp.g_varchar2_table(19) := ';}'||wwv_flow.LF||
'{\f382\fbidi \froman\fcharset161\fprq2 Cambria Math Greek;}{\f383\fbidi \froman\fcharset162\fprq';
    wwv_flow_imp.g_varchar2_table(20) := '2 Cambria Math Tur;}{\f386\fbidi \froman\fcharset186\fprq2 Cambria Math Baltic;}{\f387\fbidi \froman';
    wwv_flow_imp.g_varchar2_table(21) := '\fcharset163\fprq2 Cambria Math (Vietnamese);}'||wwv_flow.LF||
'{\f409\fbidi \fswiss\fcharset238\fprq2 Calibri CE;}{';
    wwv_flow_imp.g_varchar2_table(22) := '\f410\fbidi \fswiss\fcharset204\fprq2 Calibri Cyr;}{\f412\fbidi \fswiss\fcharset161\fprq2 Calibri Gr';
    wwv_flow_imp.g_varchar2_table(23) := 'eek;}{\f413\fbidi \fswiss\fcharset162\fprq2 Calibri Tur;}'||wwv_flow.LF||
'{\f414\fbidi \fswiss\fcharset177\fprq2 Ca';
    wwv_flow_imp.g_varchar2_table(24) := 'libri (Hebrew);}{\f415\fbidi \fswiss\fcharset178\fprq2 Calibri (Arabic);}{\f416\fbidi \fswiss\fchars';
    wwv_flow_imp.g_varchar2_table(25) := 'et186\fprq2 Calibri Baltic;}{\f417\fbidi \fswiss\fcharset163\fprq2 Calibri (Vietnamese);}'||wwv_flow.LF||
'{\flomajo';
    wwv_flow_imp.g_varchar2_table(26) := 'r\f31508\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\flomajor\f31509\fbidi \froman\fcharse';
    wwv_flow_imp.g_varchar2_table(27) := 't204\fprq2 Times New Roman Cyr;}{\flomajor\f31511\fbidi \froman\fcharset161\fprq2 Times New Roman Gr';
    wwv_flow_imp.g_varchar2_table(28) := 'eek;}'||wwv_flow.LF||
'{\flomajor\f31512\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\flomajor\f31513\fbid';
    wwv_flow_imp.g_varchar2_table(29) := 'i \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\flomajor\f31514\fbidi \froman\fcharset178\fp';
    wwv_flow_imp.g_varchar2_table(30) := 'rq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\flomajor\f31515\fbidi \froman\fcharset186\fprq2 Times New Roman Ba';
    wwv_flow_imp.g_varchar2_table(31) := 'ltic;}{\flomajor\f31516\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\fdbmajor\f31';
    wwv_flow_imp.g_varchar2_table(32) := '518\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}'||wwv_flow.LF||
'{\fdbmajor\f31519\fbidi \froman\fcharset20';
    wwv_flow_imp.g_varchar2_table(33) := '4\fprq2 Times New Roman Cyr;}{\fdbmajor\f31521\fbidi \froman\fcharset161\fprq2 Times New Roman Greek';
    wwv_flow_imp.g_varchar2_table(34) := ';}{\fdbmajor\f31522\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}'||wwv_flow.LF||
'{\fdbmajor\f31523\fbidi \';
    wwv_flow_imp.g_varchar2_table(35) := 'froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\fdbmajor\f31524\fbidi \froman\fcharset178\fprq2';
    wwv_flow_imp.g_varchar2_table(36) := ' Times New Roman (Arabic);}{\fdbmajor\f31525\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;';
    wwv_flow_imp.g_varchar2_table(37) := '}'||wwv_flow.LF||
'{\fdbmajor\f31526\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\fhimajor\f31528';
    wwv_flow_imp.g_varchar2_table(38) := '\fbidi \fswiss\fcharset238\fprq2 Calibri Light CE;}{\fhimajor\f31529\fbidi \fswiss\fcharset204\fprq2';
    wwv_flow_imp.g_varchar2_table(39) := ' Calibri Light Cyr;}'||wwv_flow.LF||
'{\fhimajor\f31531\fbidi \fswiss\fcharset161\fprq2 Calibri Light Greek;}{\fhima';
    wwv_flow_imp.g_varchar2_table(40) := 'jor\f31532\fbidi \fswiss\fcharset162\fprq2 Calibri Light Tur;}{\fhimajor\f31533\fbidi \fswiss\fchars';
    wwv_flow_imp.g_varchar2_table(41) := 'et177\fprq2 Calibri Light (Hebrew);}'||wwv_flow.LF||
'{\fhimajor\f31534\fbidi \fswiss\fcharset178\fprq2 Calibri Ligh';
    wwv_flow_imp.g_varchar2_table(42) := 't (Arabic);}{\fhimajor\f31535\fbidi \fswiss\fcharset186\fprq2 Calibri Light Baltic;}{\fhimajor\f3153';
    wwv_flow_imp.g_varchar2_table(43) := '6\fbidi \fswiss\fcharset163\fprq2 Calibri Light (Vietnamese);}'||wwv_flow.LF||
'{\fbimajor\f31538\fbidi \froman\fcha';
    wwv_flow_imp.g_varchar2_table(44) := 'rset238\fprq2 Times New Roman CE;}{\fbimajor\f31539\fbidi \froman\fcharset204\fprq2 Times New Roman ';
    wwv_flow_imp.g_varchar2_table(45) := 'Cyr;}{\fbimajor\f31541\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}'||wwv_flow.LF||
'{\fbimajor\f31542\fb';
    wwv_flow_imp.g_varchar2_table(46) := 'idi \froman\fcharset162\fprq2 Times New Roman Tur;}{\fbimajor\f31543\fbidi \froman\fcharset177\fprq2';
    wwv_flow_imp.g_varchar2_table(47) := ' Times New Roman (Hebrew);}{\fbimajor\f31544\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic';
    wwv_flow_imp.g_varchar2_table(48) := ');}'||wwv_flow.LF||
'{\fbimajor\f31545\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fbimajor\f31546\fbi';
    wwv_flow_imp.g_varchar2_table(49) := 'di \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\flominor\f31548\fbidi \froman\fcharset2';
    wwv_flow_imp.g_varchar2_table(50) := '38\fprq2 Times New Roman CE;}'||wwv_flow.LF||
'{\flominor\f31549\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr';
    wwv_flow_imp.g_varchar2_table(51) := ';}{\flominor\f31551\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\flominor\f31552\fbidi \';
    wwv_flow_imp.g_varchar2_table(52) := 'froman\fcharset162\fprq2 Times New Roman Tur;}'||wwv_flow.LF||
'{\flominor\f31553\fbidi \froman\fcharset177\fprq2 Ti';
    wwv_flow_imp.g_varchar2_table(53) := 'mes New Roman (Hebrew);}{\flominor\f31554\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}';
    wwv_flow_imp.g_varchar2_table(54) := '{\flominor\f31555\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}'||wwv_flow.LF||
'{\flominor\f31556\fbidi ';
    wwv_flow_imp.g_varchar2_table(55) := '\froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\fdbminor\f31558\fbidi \froman\fcharset238\';
    wwv_flow_imp.g_varchar2_table(56) := 'fprq2 Times New Roman CE;}{\fdbminor\f31559\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{';
    wwv_flow_imp.g_varchar2_table(57) := '\fdbminor\f31561\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\fdbminor\f31562\fbidi \fro';
    wwv_flow_imp.g_varchar2_table(58) := 'man\fcharset162\fprq2 Times New Roman Tur;}{\fdbminor\f31563\fbidi \froman\fcharset177\fprq2 Times N';
    wwv_flow_imp.g_varchar2_table(59) := 'ew Roman (Hebrew);}'||wwv_flow.LF||
'{\fdbminor\f31564\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\f';
    wwv_flow_imp.g_varchar2_table(60) := 'dbminor\f31565\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fdbminor\f31566\fbidi \from';
    wwv_flow_imp.g_varchar2_table(61) := 'an\fcharset163\fprq2 Times New Roman (Vietnamese);}'||wwv_flow.LF||
'{\fhiminor\f31568\fbidi \fswiss\fcharset238\fpr';
    wwv_flow_imp.g_varchar2_table(62) := 'q2 Calibri CE;}{\fhiminor\f31569\fbidi \fswiss\fcharset204\fprq2 Calibri Cyr;}{\fhiminor\f31571\fbid';
    wwv_flow_imp.g_varchar2_table(63) := 'i \fswiss\fcharset161\fprq2 Calibri Greek;}{\fhiminor\f31572\fbidi \fswiss\fcharset162\fprq2 Calibri';
    wwv_flow_imp.g_varchar2_table(64) := ' Tur;}'||wwv_flow.LF||
'{\fhiminor\f31573\fbidi \fswiss\fcharset177\fprq2 Calibri (Hebrew);}{\fhiminor\f31574\fbidi ';
    wwv_flow_imp.g_varchar2_table(65) := '\fswiss\fcharset178\fprq2 Calibri (Arabic);}{\fhiminor\f31575\fbidi \fswiss\fcharset186\fprq2 Calibr';
    wwv_flow_imp.g_varchar2_table(66) := 'i Baltic;}'||wwv_flow.LF||
'{\fhiminor\f31576\fbidi \fswiss\fcharset163\fprq2 Calibri (Vietnamese);}{\fbiminor\f3157';
    wwv_flow_imp.g_varchar2_table(67) := '8\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\fbiminor\f31579\fbidi \froman\fcharset204\fp';
    wwv_flow_imp.g_varchar2_table(68) := 'rq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\fbiminor\f31581\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}';
    wwv_flow_imp.g_varchar2_table(69) := '{\fbiminor\f31582\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\fbiminor\f31583\fbidi \from';
    wwv_flow_imp.g_varchar2_table(70) := 'an\fcharset177\fprq2 Times New Roman (Hebrew);}'||wwv_flow.LF||
'{\fbiminor\f31584\fbidi \froman\fcharset178\fprq2 T';
    wwv_flow_imp.g_varchar2_table(71) := 'imes New Roman (Arabic);}{\fbiminor\f31585\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{';
    wwv_flow_imp.g_varchar2_table(72) := '\fbiminor\f31586\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}}'||wwv_flow.LF||
'{\colortbl;\red0\g';
    wwv_flow_imp.g_varchar2_table(73) := 'reen0\blue0;\red0\green0\blue255;\red0\green255\blue255;\red0\green255\blue0;\red255\green0\blue255;';
    wwv_flow_imp.g_varchar2_table(74) := '\red255\green0\blue0;\red255\green255\blue0;\red255\green255\blue255;\red0\green0\blue128;\red0\gree';
    wwv_flow_imp.g_varchar2_table(75) := 'n128\blue128;\red0\green128\blue0;'||wwv_flow.LF||
'\red128\green0\blue128;\red128\green0\blue0;\red128\green128\blu';
    wwv_flow_imp.g_varchar2_table(76) := 'e0;\red128\green128\blue128;\red192\green192\blue192;\red0\green32\blue96;\cbackgroundone\ctint255\c';
    wwv_flow_imp.g_varchar2_table(77) := 'shade255\red255\green255\blue255;\caccentfive\ctint102\cshade255\red180\green198\blue231;'||wwv_flow.LF||
'\red0\gre';
    wwv_flow_imp.g_varchar2_table(78) := 'en51\blue0;}{\*\defchp \f31506\fs22 }{\*\defpap \ql \li0\ri0\sa160\sl259\slmult1\widctlpar\wrapdefau';
    wwv_flow_imp.g_varchar2_table(79) := 'lt\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 }\noqfpromote {\stylesheet{\ql \li0\ri0\sa160\';
    wwv_flow_imp.g_varchar2_table(80) := 'sl259\slmult1'||wwv_flow.LF||
'\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1';
    wwv_flow_imp.g_varchar2_table(81) := ' \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \sn';
    wwv_flow_imp.g_varchar2_table(82) := 'ext0 \sqformat \spriority0 Normal;}{\*\cs10 \additive '||wwv_flow.LF||
'\ssemihidden \sunhideused \spriority1 Defaul';
    wwv_flow_imp.g_varchar2_table(83) := 't Paragraph Font;}{\*\ts11\tsrowd\trftsWidthB3\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\t';
    wwv_flow_imp.g_varchar2_table(84) := 'rpaddfr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\t';
    wwv_flow_imp.g_varchar2_table(85) := 'sbrdrv '||wwv_flow.LF||
'\ql \li0\ri0\sa160\sl259\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\r';
    wwv_flow_imp.g_varchar2_table(86) := 'in0\lin0\itap0 \rtlch\fcs1 \af31506\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgr';
    wwv_flow_imp.g_varchar2_table(87) := 'id\langnp1033\langfenp1033 \snext11 \ssemihidden \sunhideused '||wwv_flow.LF||
'Normal Table;}{\*\ts15\tsrowd\trbrdr';
    wwv_flow_imp.g_varchar2_table(88) := 't\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\';
    wwv_flow_imp.g_varchar2_table(89) := 'brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidthB3\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\t';
    wwv_flow_imp.g_varchar2_table(90) := 'rpaddfr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\t';
    wwv_flow_imp.g_varchar2_table(91) := 'sbrdrv '||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlc';
    wwv_flow_imp.g_varchar2_table(92) := 'h\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp10';
    wwv_flow_imp.g_varchar2_table(93) := '33 \sbasedon11 \snext15 \spriority39 \styrsid14254050 '||wwv_flow.LF||
'Table Grid;}}{\*\rsidtbl \rsid1647464\rsid44';
    wwv_flow_imp.g_varchar2_table(94) := '84770\rsid4619988\rsid6841815\rsid7627543\rsid8014033\rsid14121831\rsid14254050\rsid14362731}{\mmath';
    wwv_flow_imp.g_varchar2_table(95) := 'Pr\mmathFont34\mbrkBin0\mbrkBinSub0\msmallFrac0\mdispDef1\mlMargin0\mrMargin0\mdefJc1\mwrapIndent144';
    wwv_flow_imp.g_varchar2_table(96) := '0\mintLim0'||wwv_flow.LF||
'\mnaryLim1}{\info{\author Sanid}{\operator Sanid}{\creatim\yr2022\mo4\dy18\min47}{\revti';
    wwv_flow_imp.g_varchar2_table(97) := 'm\yr2022\mo4\dy18\min55}{\version8}{\edmins4}{\nofpages1}{\nofwords41}{\nofchars235}{\nofcharsws275}';
    wwv_flow_imp.g_varchar2_table(98) := '{\vern57433}}{\*\xmlnstbl {\xmlns1 http://schemas.microsoft.com/off'||wwv_flow.LF||
'ice/word/2003/wordml}}\paperw12';
    wwv_flow_imp.g_varchar2_table(99) := '240\paperh15840\margl1440\margr1440\margt1440\margb1440\gutter0\ltrsect '||wwv_flow.LF||
'\widowctrl\ftnbj\aenddoc\t';
    wwv_flow_imp.g_varchar2_table(100) := 'rackmoves0\trackformatting1\donotembedsysfont1\relyonvml0\donotembedlingdata0\grfdocevents0\validate';
    wwv_flow_imp.g_varchar2_table(101) := 'xml1\showplaceholdtext0\ignoremixedcontent0\saveinvalidxml0\showxmlerrors1\noxlattoyen'||wwv_flow.LF||
'\expshrtn\no';
    wwv_flow_imp.g_varchar2_table(102) := 'ultrlspc\dntblnsbdb\nospaceforul\formshade\horzdoc\dgmargin\dghspace180\dgvspace180\dghorigin1440\dg';
    wwv_flow_imp.g_varchar2_table(103) := 'vorigin1440\dghshow1\dgvshow1'||wwv_flow.LF||
'\jexpand\viewkind1\viewscale110\pgbrdrhead\pgbrdrfoot\splytwnine\ftnl';
    wwv_flow_imp.g_varchar2_table(104) := 'ytwnine\htmautsp\nolnhtadjtbl\useltbaln\alntblind\lytcalctblwd\lyttblrtgr\lnbrkrule\nobrkwrptbl\snap';
    wwv_flow_imp.g_varchar2_table(105) := 'togridincell\allowfieldendsel\wrppunct'||wwv_flow.LF||
'\asianbrkrule\rsidroot1647464\newtblstyruls\nogrowautofit\us';
    wwv_flow_imp.g_varchar2_table(106) := 'enormstyforlist\noindnmbrts\felnbrelev\nocxsptable\indrlsweleven\noafcnsttbl\afelev\utinl\hwelev\spl';
    wwv_flow_imp.g_varchar2_table(107) := 'tpgpar\notcvasp\notbrkcnstfrctbl\notvatxbx\krnprsnet\cachedcolbal \nouicompat \fet0'||wwv_flow.LF||
'{\*\wgrffmtfilt';
    wwv_flow_imp.g_varchar2_table(108) := 'er 2450}\nofeaturethrottle1\ilfomacatclnup0{\*\docvar {xdo0001}{PD9mb3ItZWFjaC1ncm91cDpST1c7Li9DT01Q';
    wwv_flow_imp.g_varchar2_table(109) := 'QU5ZX05BTUU/Pjw/c29ydDpjdXJyZW50LWdyb3VwKCkvQ09NUEFOWV9OQU1FOydhc2NlbmRpbmcnO2RhdGEtdHlwZT0ndGV4dCc/';
    wwv_flow_imp.g_varchar2_table(110) := 'Pg==}}'||wwv_flow.LF||
'{\*\docvar {xdo0002}{PD92YXJpYWJsZUBpbmNvbnRleHQ6ZzFwb3M7cG9zaXRpb24oKT8+PD92YXJpYWJsZUBpbmN';
    wwv_flow_imp.g_varchar2_table(111) := 'vbnRleHQ6ZzE7Y3VycmVudC1ncm91cCgpPz4=}}{\*\docvar {xdo0003}{PD9pZkBjZWxsOnBvc2l0aW9uKCk9MSA/Pjw/ZW5k';
    wwv_flow_imp.g_varchar2_table(112) := 'IGlmPz4=}}{\*\docvar {xdo0004}{PD9DT01QQU5ZX05BTUU/Pg==}}'||wwv_flow.LF||
'{\*\docvar {xdo0005}{PHhzbDphdHRyaWJ1dGUg';
    wwv_flow_imp.g_varchar2_table(113) := 'bmFtZT0ibnVtYmVyLXJvd3Mtc3Bhbm5lZCIgIHhkb2ZvOmN0eD0iYmxvY2siPjx4c2w6dmFsdWUtb2Ygc2VsZWN0PSJjb3VudCgk';
    wwv_flow_imp.g_varchar2_table(114) := 'ZzEpICIvPjwveHNsOmF0dHJpYnV0ZT4=}}{\*\docvar {xdo0006}{PD9mb3ItZWFjaDpjdXJyZW50LWdyb3VwKCk/Pg==}}'||wwv_flow.LF||
'{';
    wwv_flow_imp.g_varchar2_table(115) := '\*\docvar {xdo0007}{PD9BRERSRVNTPz4=}}{\*\docvar {xdo0008}{PD9QSE9ORT8+}}{\*\docvar {xdo0009}{PD9GQV';
    wwv_flow_imp.g_varchar2_table(116) := 'g/Pg==}}{\*\docvar {xdo0010}{PD9FTUFJTD8+}}{\*\docvar {xdo0011}{PD9lbmQgZm9yLWVhY2g/Pg==}}{\*\docvar';
    wwv_flow_imp.g_varchar2_table(117) := ' {xdo0012}{PD9lbmQgZm9yLWVhY2gtZ3JvdXA/Pg==}}\ltrpar '||wwv_flow.LF||
'\sectd \ltrsect\linex0\endnhere\sectlinegrid3';
    wwv_flow_imp.g_varchar2_table(118) := '60\sectdefaultcl\sftnbj {\*\pnseclvl1\pnucrm\pnstart1\pnindent720\pnhang {\pntxta .}}{\*\pnseclvl2\p';
    wwv_flow_imp.g_varchar2_table(119) := 'nucltr\pnstart1\pnindent720\pnhang {\pntxta .}}{\*\pnseclvl3\pndec\pnstart1\pnindent720\pnhang {\pnt';
    wwv_flow_imp.g_varchar2_table(120) := 'xta .}}'||wwv_flow.LF||
'{\*\pnseclvl4\pnlcltr\pnstart1\pnindent720\pnhang {\pntxta )}}{\*\pnseclvl5\pndec\pnstart1\';
    wwv_flow_imp.g_varchar2_table(121) := 'pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnseclvl6\pnlcltr\pnstart1\pnindent720\pnhang {\pntxtb';
    wwv_flow_imp.g_varchar2_table(122) := ' (}{\pntxta )}}{\*\pnseclvl7\pnlcrm\pnstart1\pnindent720\pnhang '||wwv_flow.LF||
'{\pntxtb (}{\pntxta )}}{\*\pnseclv';
    wwv_flow_imp.g_varchar2_table(123) := 'l8\pnlcltr\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnseclvl9\pnlcrm\pnstart1\pnindent';
    wwv_flow_imp.g_varchar2_table(124) := '720\pnhang {\pntxtb (}{\pntxta )}}\pard\plain \ltrpar\qc \li0\ri0\sa160\sl259\slmult1'||wwv_flow.LF||
'\widctlpar\wr';
    wwv_flow_imp.g_varchar2_table(125) := 'apdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid8014033 \rtlch\fcs1 \af0\afs22\';
    wwv_flow_imp.g_varchar2_table(126) := 'alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \a';
    wwv_flow_imp.g_varchar2_table(127) := 'f0\afs40 \ltrch\fcs0 '||wwv_flow.LF||
'\b\fs40\ul\cf17\insrsid8014033\charrsid8014033 Company Details}{\rtlch\fcs1 \';
    wwv_flow_imp.g_varchar2_table(128) := 'af0\afs40 \ltrch\fcs0 \b\fs40\ul\cf17\insrsid14254050\charrsid8014033 '||wwv_flow.LF||
'\par \ltrrow}\trowd \irow0\i';
    wwv_flow_imp.g_varchar2_table(129) := 'rowband0\ltrrow\ts15\trgaph108\trleft-630\trhdr\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdr';
    wwv_flow_imp.g_varchar2_table(130) := 'b\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth3\';
    wwv_flow_imp.g_varchar2_table(131) := 'trwWidth10710\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddf';
    wwv_flow_imp.g_varchar2_table(132) := 'b3\trpaddfr3\tblrsid14362731\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind-522\tblindtype3 \clvert';
    wwv_flow_imp.g_varchar2_table(133) := 'alt\clbrdrt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cl';
    wwv_flow_imp.g_varchar2_table(134) := 'cbpat19\cltxlrtb\clftsWidth3\clwWidth2520\clcbpatraw19 \cellx1890\clvertalt\clbrdrt\brdrs\brdrw10 \c';
    wwv_flow_imp.g_varchar2_table(135) := 'lbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat19\cltxlrtb\clftsWidth3';
    wwv_flow_imp.g_varchar2_table(136) := '\clwWidth2340\clcbpatraw19 \cellx4230\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdr';
    wwv_flow_imp.g_varchar2_table(137) := 'b\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat19\cltxlrtb\clftsWidth3\clwWidth2160\clcbpatraw19 \ce';
    wwv_flow_imp.g_varchar2_table(138) := 'llx6390\clvertalt'||wwv_flow.LF||
'\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brd';
    wwv_flow_imp.g_varchar2_table(139) := 'rs\brdrw10 \clcbpat19\cltxlrtb\clftsWidth3\clwWidth1440\clcbpatraw19 \cellx7830\clvertalt\clbrdrt\br';
    wwv_flow_imp.g_varchar2_table(140) := 'drs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr'||wwv_flow.LF||
'\brdrs\brdrw10 \clcbpat19\cltxlr';
    wwv_flow_imp.g_varchar2_table(141) := 'tb\clftsWidth3\clwWidth2250\clcbpatraw19 \cellx10080\pard\plain \ltrpar\qc \li0\ri0\widctlpar\intbl\';
    wwv_flow_imp.g_varchar2_table(142) := 'wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid8014033\yts15 \rtlch\fcs1 \af0\afs2';
    wwv_flow_imp.g_varchar2_table(143) := '2\alang1025 '||wwv_flow.LF||
'\ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs';
    wwv_flow_imp.g_varchar2_table(144) := '1 \af0 \ltrch\fcs0 \b\cf18\insrsid14254050\charrsid8014033 Company Name}{\rtlch\fcs1 \af0 \ltrch\fcs';
    wwv_flow_imp.g_varchar2_table(145) := '0 \cf18\insrsid14254050\charrsid8014033 \cell }{\rtlch\fcs1 \af0 '||wwv_flow.LF||
'\ltrch\fcs0 \b\cf18\insrsid142540';
    wwv_flow_imp.g_varchar2_table(146) := '50\charrsid8014033 ADDRESS}{\rtlch\fcs1 \af0 \ltrch\fcs0 \cf18\insrsid14254050\charrsid8014033 \cell';
    wwv_flow_imp.g_varchar2_table(147) := ' }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\cf18\insrsid14254050\charrsid8014033 PHONE}{\rtlch\fcs1 \af0 \ltr';
    wwv_flow_imp.g_varchar2_table(148) := 'ch\fcs0 '||wwv_flow.LF||
'\cf18\insrsid14254050\charrsid8014033 \cell }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\cf18\insrsid';
    wwv_flow_imp.g_varchar2_table(149) := '14254050\charrsid8014033 FAX}{\rtlch\fcs1 \af0 \ltrch\fcs0 \cf18\insrsid14254050\charrsid8014033 \ce';
    wwv_flow_imp.g_varchar2_table(150) := 'll }{\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\b\cf18\insrsid14254050\charrsid8014033 EMAIL}{\rtlch\fcs1 \af0 ';
    wwv_flow_imp.g_varchar2_table(151) := '\ltrch\fcs0 \cf18\insrsid14254050\charrsid8014033 \cell }\pard\plain \ltrpar\ql \li0\ri0\sa160\sl259';
    wwv_flow_imp.g_varchar2_table(152) := '\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 '||wwv_flow.LF||
'\rtlch\fcs1 \af0';
    wwv_flow_imp.g_varchar2_table(153) := '\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\';
    wwv_flow_imp.g_varchar2_table(154) := 'fcs1 \af0 \ltrch\fcs0 \insrsid8014033 \trowd \irow0\irowband0\ltrrow\ts15\trgaph108\trleft-630\trhdr';
    wwv_flow_imp.g_varchar2_table(155) := '\trbrdrt\brdrs\brdrw10 \trbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrd';
    wwv_flow_imp.g_varchar2_table(156) := 'rh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth3\trwWidth10710\trftsWidthB3\trftsWidthA3\traut';
    wwv_flow_imp.g_varchar2_table(157) := 'ofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid14362731\tbllkhdrrows\tbl';
    wwv_flow_imp.g_varchar2_table(158) := 'lkhdrcols\tbllknocolband\tblind-522\tblindtype3 \clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\br';
    wwv_flow_imp.g_varchar2_table(159) := 'drw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat19\cltxlrtb\clftsWidth3\clwWidth2520\clc';
    wwv_flow_imp.g_varchar2_table(160) := 'bpatraw19 \cellx1890\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \';
    wwv_flow_imp.g_varchar2_table(161) := 'clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat19\cltxlrtb\clftsWidth3\clwWidth2340\clcbpatraw19 \cellx4230\clverta';
    wwv_flow_imp.g_varchar2_table(162) := 'lt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbp';
    wwv_flow_imp.g_varchar2_table(163) := 'at19\cltxlrtb\clftsWidth3\clwWidth2160\clcbpatraw19 \cellx6390\clvertalt'||wwv_flow.LF||
'\clbrdrt\brdrs\brdrw10 \cl';
    wwv_flow_imp.g_varchar2_table(164) := 'brdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat19\cltxlrtb\clftsWidth3\cl';
    wwv_flow_imp.g_varchar2_table(165) := 'wWidth1440\clcbpatraw19 \cellx7830\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\b';
    wwv_flow_imp.g_varchar2_table(166) := 'rdrs\brdrw10 \clbrdrr'||wwv_flow.LF||
'\brdrs\brdrw10 \clcbpat19\cltxlrtb\clftsWidth3\clwWidth2250\clcbpatraw19 \cel';
    wwv_flow_imp.g_varchar2_table(167) := 'lx10080\row \ltrrow}\trowd \irow1\irowband1\lastrow \ltrrow\ts15\trgaph108\trrh1727\trleft-630\trbrd';
    wwv_flow_imp.g_varchar2_table(168) := 'rt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr'||wwv_flow.LF||
'\brdrs\brdrw10 \trbrdrh\brd';
    wwv_flow_imp.g_varchar2_table(169) := 'rs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth3\trwWidth10710\trftsWidthB3\trftsWidthA3\trautofit1\';
    wwv_flow_imp.g_varchar2_table(170) := 'trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid14362731\tbllkhdrrows\tbllkhdrc';
    wwv_flow_imp.g_varchar2_table(171) := 'ols\tbllknocolband\tblind-522\tblindtype3 \clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 ';
    wwv_flow_imp.g_varchar2_table(172) := '\clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth2520\clshdrawnil \cellx1';
    wwv_flow_imp.g_varchar2_table(173) := '890\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brd';
    wwv_flow_imp.g_varchar2_table(174) := 'rw10 '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth2340\clshdrawnil \cellx4230\clvertalc\clbrdrt\brdrs\brdrw10 \cl';
    wwv_flow_imp.g_varchar2_table(175) := 'brdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth2160';
    wwv_flow_imp.g_varchar2_table(176) := '\clshdrawnil \cellx6390\clvertalc\clbrdrt\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdr';
    wwv_flow_imp.g_varchar2_table(177) := 'w10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1440\clshdrawnil \cellx7830\clvertalc\clbrd';
    wwv_flow_imp.g_varchar2_table(178) := 'rt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\cl';
    wwv_flow_imp.g_varchar2_table(179) := 'ftsWidth3\clwWidth2250\clshdrawnil \cellx10080\pard\plain \ltrpar\qc \li0\ri0\widctlpar\intbl\wrapde';
    wwv_flow_imp.g_varchar2_table(180) := 'fault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid14254050\yts15 \rtlch\fcs1 \af0\afs22\ala';
    wwv_flow_imp.g_varchar2_table(181) := 'ng1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\*\bkmkstart Te';
    wwv_flow_imp.g_varchar2_table(182) := 'xt1}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\insrsid14254050\charrsid14254050 ';
    wwv_flow_imp.g_varchar2_table(183) := ' FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\cf9\insrsid14254050\charrsid14254050 {\*\datafield 80010';
    wwv_flow_imp.g_varchar2_table(184) := '000000000000554657874310002472000000000000f3c3f7265663a78646f303030313f3e0000000000}{\*\formfield{\f';
    wwv_flow_imp.g_varchar2_table(185) := 'ftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text1}{\*\ffdeftext G }{\*\ffstattext '||wwv_flow.LF||
'<?ref:xdo000';
    wwv_flow_imp.g_varchar2_table(186) := '1?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\lang1024\langfe1024\noproof\insrsid14254050\cha';
    wwv_flow_imp.g_varchar2_table(187) := 'rrsid14254050 G }}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\*\bkmkstar';
    wwv_flow_imp.g_varchar2_table(188) := 't Text2}{\*\bkmkend Text1}'||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid142540';
    wwv_flow_imp.g_varchar2_table(189) := '50\charrsid14254050  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14254050\charrsid14254050 {\*\d';
    wwv_flow_imp.g_varchar2_table(190) := 'atafield '||wwv_flow.LF||
'80010000000000000554657874320002562000000000000f3c3f7265663a78646f303030323f3e0000000000}';
    wwv_flow_imp.g_varchar2_table(191) := '{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text2}{\*\ffdeftext V }{\*\ffstattex';
    wwv_flow_imp.g_varchar2_table(192) := 't <?ref:xdo0002?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\lang1024\langfe1024\noproof\insrsid';
    wwv_flow_imp.g_varchar2_table(193) := '14254050\charrsid14254050 V }}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj ';
    wwv_flow_imp.g_varchar2_table(194) := '{\*\bkmkstart Text3}{\*\bkmkend Text2}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\i';
    wwv_flow_imp.g_varchar2_table(195) := 'nsrsid14254050\charrsid14254050  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14254050\charrsid14';
    wwv_flow_imp.g_varchar2_table(196) := '254050 {\*\datafield 80010000000000000554657874330002494600000000000f3c3f7265663a78646f303030333f3e0';
    wwv_flow_imp.g_varchar2_table(197) := '000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text3}{\*\ffdeftext IF}{';
    wwv_flow_imp.g_varchar2_table(198) := '\*\ffstattext <?ref:xdo0003?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \lang1024\langfe1024\nopro';
    wwv_flow_imp.g_varchar2_table(199) := 'of\insrsid14254050\charrsid14254050 IF}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\endnhere\sectlinegrid360\sectdefau';
    wwv_flow_imp.g_varchar2_table(200) := 'ltcl\sftnbj {\*\bkmkstart Text4}{\*\bkmkend Text3}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltr';
    wwv_flow_imp.g_varchar2_table(201) := 'ch\fcs0 \insrsid14254050\charrsid14254050  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid1425405';
    wwv_flow_imp.g_varchar2_table(202) := '0\charrsid14254050 {\*\datafield 8001000000000000055465787434000c434f4d50414e595f4e414d4500000000000';
    wwv_flow_imp.g_varchar2_table(203) := 'f3c3f7265663a78646f303030343f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\f';
    wwv_flow_imp.g_varchar2_table(204) := 'fname Text4}{\*\ffdeftext COMPANY_NAME}'||wwv_flow.LF||
'{\*\ffstattext <?ref:xdo0004?>}}}}}{\fldrslt {\rtlch\fcs1 \';
    wwv_flow_imp.g_varchar2_table(205) := 'af0 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid14254050\charrsid14254050 COMPANY_NAME}}}\sectd ';
    wwv_flow_imp.g_varchar2_table(206) := '\ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\*\bkmkstart Text5}'||wwv_flow.LF||
'{\*\bkmkend Text';
    wwv_flow_imp.g_varchar2_table(207) := '4}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14254050\charrsid14254050  FORMT';
    wwv_flow_imp.g_varchar2_table(208) := 'EXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14254050\charrsid14254050 {\*\datafield '||wwv_flow.LF||
'800100000000000';
    wwv_flow_imp.g_varchar2_table(209) := '00554657874350002525300000000000f3c3f7265663a78646f303030353f3e0000000000}{\*\formfield{\fftype0\ffo';
    wwv_flow_imp.g_varchar2_table(210) := 'wnhelp\ffownstat\fftypetxt0{\*\ffname Text5}{\*\ffdeftext RS}{\*\ffstattext <?ref:xdo0005?>}}}}}{\fl';
    wwv_flow_imp.g_varchar2_table(211) := 'drslt {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\lang1024\langfe1024\noproof\insrsid14254050\charrsid14254050 ';
    wwv_flow_imp.g_varchar2_table(212) := 'RS}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af0 \ltrch\f';
    wwv_flow_imp.g_varchar2_table(213) := 'cs0 \insrsid14254050 {\*\bkmkend Text5}\cell }\pard \ltrpar'||wwv_flow.LF||
'\qc \li0\ri0\widctlpar\intbl\wrapdefaul';
    wwv_flow_imp.g_varchar2_table(214) := 't\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid7627543\yts15 {\*\bkmkstart Text6}{\field\fld';
    wwv_flow_imp.g_varchar2_table(215) := 'dirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \cf20\insrsid14254050\charrsid14254050  FORMTEXT }{\r';
    wwv_flow_imp.g_varchar2_table(216) := 'tlch\fcs1 \af0 '||wwv_flow.LF||
'\ltrch\fcs0 \cf20\insrsid14254050\charrsid14254050 {\*\datafield 800100000000000005';
    wwv_flow_imp.g_varchar2_table(217) := '54657874360002462000000000000f3c3f7265663a78646f303030363f3e0000000000}{\*\formfield{\fftype0\ffownh';
    wwv_flow_imp.g_varchar2_table(218) := 'elp\ffownstat\fftypetxt0{\*\ffname Text6}{\*\ffdeftext F }'||wwv_flow.LF||
'{\*\ffstattext <?ref:xdo0006?>}}}}}{\fld';
    wwv_flow_imp.g_varchar2_table(219) := 'rslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \cf20\lang1024\langfe1024\noproof\insrsid14254050\charrsid1425405';
    wwv_flow_imp.g_varchar2_table(220) := '0 F }}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\*\bkmkstart Text7}{\*\';
    wwv_flow_imp.g_varchar2_table(221) := 'bkmkend Text6}'||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14254050\charrsid1';
    wwv_flow_imp.g_varchar2_table(222) := '4254050  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14254050\charrsid14254050 {\*\datafield '||wwv_flow.LF||
'8';
    wwv_flow_imp.g_varchar2_table(223) := '00100000000000005546578743700074144445245535300000000000f3c3f7265663a78646f303030373f3e0000000000}{\';
    wwv_flow_imp.g_varchar2_table(224) := '*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text7}{\*\ffdeftext ADDRESS}{\*\ffstat';
    wwv_flow_imp.g_varchar2_table(225) := 'text <?ref:xdo0007?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 '||wwv_flow.LF||
'\ltrch\fcs0 \lang1024\langfe1024\noproof\insr';
    wwv_flow_imp.g_varchar2_table(226) := 'sid14254050\charrsid14254050 ADDRESS}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl';
    wwv_flow_imp.g_varchar2_table(227) := '\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14254050 {\*\bkmkend Text7}\cell {\*\bkmkstart Text8}}';
    wwv_flow_imp.g_varchar2_table(228) := ''||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14254050\charrsid14254050  FORMT';
    wwv_flow_imp.g_varchar2_table(229) := 'EXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14254050\charrsid14254050 {\*\datafield '||wwv_flow.LF||
'800100000000000';
    wwv_flow_imp.g_varchar2_table(230) := '0055465787438000550484f4e4500000000000f3c3f7265663a78646f303030383f3e0000000000}{\*\formfield{\fftyp';
    wwv_flow_imp.g_varchar2_table(231) := 'e0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text8}{\*\ffdeftext PHONE}{\*\ffstattext <?ref:xdo0008?>';
    wwv_flow_imp.g_varchar2_table(232) := '}}}}}{\fldrslt {\rtlch\fcs1 \af0 '||wwv_flow.LF||
'\ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid14254050\charrsid';
    wwv_flow_imp.g_varchar2_table(233) := '14254050 PHONE}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \';
    wwv_flow_imp.g_varchar2_table(234) := 'af0 \ltrch\fcs0 \insrsid14254050 {\*\bkmkend Text8}\cell {\*\bkmkstart Text9}}'||wwv_flow.LF||
'{\field\flddirty{\*\';
    wwv_flow_imp.g_varchar2_table(235) := 'fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14254050\charrsid14254050  FORMTEXT }{\rtlch\fcs1 \af0';
    wwv_flow_imp.g_varchar2_table(236) := ' \ltrch\fcs0 \insrsid14254050\charrsid14254050 {\*\datafield '||wwv_flow.LF||
'8001000000000000055465787439000346415';
    wwv_flow_imp.g_varchar2_table(237) := '800000000000f3c3f7265663a78646f303030393f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fft';
    wwv_flow_imp.g_varchar2_table(238) := 'ypetxt0{\*\ffname Text9}{\*\ffdeftext FAX}{\*\ffstattext <?ref:xdo0009?>}}}}}{\fldrslt {\rtlch\fcs1 ';
    wwv_flow_imp.g_varchar2_table(239) := '\af0 \ltrch\fcs0 '||wwv_flow.LF||
'\lang1024\langfe1024\noproof\insrsid14254050\charrsid14254050 FAX}}}\sectd \ltrse';
    wwv_flow_imp.g_varchar2_table(240) := 'ct\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid142540';
    wwv_flow_imp.g_varchar2_table(241) := '50 {\*\bkmkend Text9}\cell {\*\bkmkstart Text10}}'||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \lt';
    wwv_flow_imp.g_varchar2_table(242) := 'rch\fcs0 \insrsid14254050\charrsid14254050  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14254050';
    wwv_flow_imp.g_varchar2_table(243) := '\charrsid14254050 {\*\datafield '||wwv_flow.LF||
'8001000000000000065465787431300005454d41494c00000000000f3c3f726566';
    wwv_flow_imp.g_varchar2_table(244) := '3a78646f303031303f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text1';
    wwv_flow_imp.g_varchar2_table(245) := '0}{\*\ffdeftext EMAIL}{\*\ffstattext <?ref:xdo0010?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 '||wwv_flow.LF||
'\ltrch\fcs0 \';
    wwv_flow_imp.g_varchar2_table(246) := 'lang1024\langfe1024\noproof\insrsid14254050\charrsid14254050 EMAIL}}}\sectd \ltrsect\linex0\endnhere';
    wwv_flow_imp.g_varchar2_table(247) := '\sectlinegrid360\sectdefaultcl\sftnbj {\*\bkmkstart Text11}{\*\bkmkend Text10}{\field\flddirty{\*\fl';
    wwv_flow_imp.g_varchar2_table(248) := 'dinst {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\cf20\insrsid14254050\charrsid14254050  FORMTEXT }{\rtlch\fcs1';
    wwv_flow_imp.g_varchar2_table(249) := ' \af0 \ltrch\fcs0 \cf20\insrsid14254050\charrsid14254050 {\*\datafield 80010000000000000654657874313';
    wwv_flow_imp.g_varchar2_table(250) := '10002204500000000000f3c3f7265663a78646f303031313f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ffo';
    wwv_flow_imp.g_varchar2_table(251) := 'wnstat\fftypetxt0{\*\ffname Text11}{\*\ffdeftext  E}{\*\ffstattext <?ref:xdo0011?>}}}}}{\fldrslt {\r';
    wwv_flow_imp.g_varchar2_table(252) := 'tlch\fcs1 \af0 \ltrch\fcs0 \cf20\lang1024\langfe1024\noproof\insrsid14254050\charrsid14254050  E}}}\';
    wwv_flow_imp.g_varchar2_table(253) := 'sectd \ltrsect'||wwv_flow.LF||
'\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\*\bkmkstart Text12}{\*\bkmke';
    wwv_flow_imp.g_varchar2_table(254) := 'nd Text11}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\insrsid14254050\charrsid142';
    wwv_flow_imp.g_varchar2_table(255) := '54050  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\cf9\insrsid14254050\charrsid14254050 {\*\datafield';
    wwv_flow_imp.g_varchar2_table(256) := ' 8001000000000000065465787431320002204500000000000f3c3f7265663a78646f303031323f3e0000000000}{\*\form';
    wwv_flow_imp.g_varchar2_table(257) := 'field{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text12}{\*\ffdeftext  E}{\*\ffstattext '||wwv_flow.LF||
'<?r';
    wwv_flow_imp.g_varchar2_table(258) := 'ef:xdo0012?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\lang1024\langfe1024\noproof\insrsid142';
    wwv_flow_imp.g_varchar2_table(259) := '54050\charrsid14254050  E}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\r';
    wwv_flow_imp.g_varchar2_table(260) := 'tlch\fcs1 \af0 \ltrch\fcs0 \insrsid14254050 '||wwv_flow.LF||
'{\*\bkmkend Text12}\cell }\pard\plain \ltrpar\ql \li0\';
    wwv_flow_imp.g_varchar2_table(261) := 'ri0\sa160\sl259\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rt';
    wwv_flow_imp.g_varchar2_table(262) := 'lch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfe';
    wwv_flow_imp.g_varchar2_table(263) := 'np1033 {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14254050 \trowd \irow1\irowband1\lastrow \ltrrow\ts15\t';
    wwv_flow_imp.g_varchar2_table(264) := 'rgaph108\trrh1727\trleft-630\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 '||wwv_flow.LF||
'\';
    wwv_flow_imp.g_varchar2_table(265) := 'trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth3\trwWidth10710\trf';
    wwv_flow_imp.g_varchar2_table(266) := 'tsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblr';
    wwv_flow_imp.g_varchar2_table(267) := 'sid14362731\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind-522\tblindtype3 \clvertalc\clbrdrt\brdrs';
    wwv_flow_imp.g_varchar2_table(268) := '\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth';
    wwv_flow_imp.g_varchar2_table(269) := '3\clwWidth2520\clshdrawnil \cellx1890\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdr';
    wwv_flow_imp.g_varchar2_table(270) := 'b\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth2340\clshdrawnil \cellx4230\c';
    wwv_flow_imp.g_varchar2_table(271) := 'lvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 ';
    wwv_flow_imp.g_varchar2_table(272) := '\cltxlrtb\clftsWidth3\clwWidth2160\clshdrawnil \cellx6390\clvertalc\clbrdrt\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrl';
    wwv_flow_imp.g_varchar2_table(273) := '\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1440\clsh';
    wwv_flow_imp.g_varchar2_table(274) := 'drawnil \cellx7830\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \cl';
    wwv_flow_imp.g_varchar2_table(275) := 'brdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth2250\clshdrawnil \cellx10080\row }\pard \ltrpar\';
    wwv_flow_imp.g_varchar2_table(276) := 'ql \li0\ri0\sa160\sl259\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\i';
    wwv_flow_imp.g_varchar2_table(277) := 'tap0 {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid4619988 '||wwv_flow.LF||
'\par }{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid142';
    wwv_flow_imp.g_varchar2_table(278) := '54050 '||wwv_flow.LF||
'\par }{\*\themedata 504b030414000600080000002100e9de0fbfff0000001c020000130000005b436f6e7465';
    wwv_flow_imp.g_varchar2_table(279) := '6e745f54797065735d2e786d6cac91cb4ec3301045f748fc83e52d4a'||wwv_flow.LF||
'9cb2400825e982c78ec7a27cc0c8992416c9d8b2a7';
    wwv_flow_imp.g_varchar2_table(280) := '55fbf74cd25442a820166c2cd933f79e3be372bd1f07b5c3989ca74aaff2422b24eb1b475da5df374fd9ad'||wwv_flow.LF||
'5689811a183c';
    wwv_flow_imp.g_varchar2_table(281) := '61a50f98f4babebc2837878049899a52a57be670674cb23d8e90721f90a4d2fa3802cb35762680fd800ecd7551dc18eb8991';
    wwv_flow_imp.g_varchar2_table(282) := '38e3c943d7e503b6'||wwv_flow.LF||
'b01d583deee5f99824e290b4ba3f364eac4a430883b3c092d4eca8f946c916422ecab927f52ea42b89';
    wwv_flow_imp.g_varchar2_table(283) := 'a1cd59c254f919b0e85e6535d135a8de20f20b8c12c3b0'||wwv_flow.LF||
'0c895fcf6720192de6bf3b9e89ecdbd6596cbcdd8eb28e7c365e';
    wwv_flow_imp.g_varchar2_table(284) := 'cc4ec1ff1460f53fe813d3cc7f5b7f020000ffff0300504b030414000600080000002100a5d6'||wwv_flow.LF||
'a7e7c0000000360100000b';
    wwv_flow_imp.g_varchar2_table(285) := '0000005f72656c732f2e72656c73848fcf6ac3300c87ef85bd83d17d51d2c31825762fa590432fa37d00e1287f68221bdb1b';
    wwv_flow_imp.g_varchar2_table(286) := 'ebdb4f'||wwv_flow.LF||
'c7060abb0884a4eff7a93dfeae8bf9e194e720169aaa06c3e2433fcb68e1763dbf7f82c985a4a725085b787086a3';
    wwv_flow_imp.g_varchar2_table(287) := '7bdbb55fbc50d1a33ccd311ba548b6309512'||wwv_flow.LF||
'0f88d94fbc52ae4264d1c910d24a45db3462247fa791715fd71f989e19e036';
    wwv_flow_imp.g_varchar2_table(288) := '4cd3f51652d73760ae8fa8c9ffb3c330cc9e4fc17faf2ce545046e37944c69e462'||wwv_flow.LF||
'a1a82fe353bd90a865aad41ed0b5b8f9';
    wwv_flow_imp.g_varchar2_table(289) := 'd6fd010000ffff0300504b0304140006000800000021006b799616830000008a0000001c0000007468656d652f746865'||wwv_flow.LF||
'6d';
    wwv_flow_imp.g_varchar2_table(290) := '652f7468656d654d616e616765722e786d6c0ccc4d0ac3201040e17da17790d93763bb284562b2cbaebbf600439c1a41c7a0';
    wwv_flow_imp.g_varchar2_table(291) := 'd29fdbd7e5e38337cedf14d59b'||wwv_flow.LF||
'4b0d592c9c070d8a65cd2e88b7f07c2ca71ba8da481cc52c6ce1c715e6e97818c9b48d13';
    wwv_flow_imp.g_varchar2_table(292) := 'df49c873517d23d59085adb5dd20d6b52bd521ef2cdd5eb9246a3d8b'||wwv_flow.LF||
'4757e8d3f729e245eb2b260a0238fd010000ffff03';
    wwv_flow_imp.g_varchar2_table(293) := '00504b030414000600080000002100aa5225dfc60600008b1a0000160000007468656d652f7468656d652f'||wwv_flow.LF||
'7468656d6531';
    wwv_flow_imp.g_varchar2_table(294) := '2e786d6cec595d8bdb46147d2ff43f08bd3bfe92fcb1c41b6cd9ceb6d94d42eca4e4716c8fadc98e344633de8d0981923c16';
    wwv_flow_imp.g_varchar2_table(295) := '0aa569e943037deb'||wwv_flow.LF||
'43691b48a02fe9afd936a54d217fa17746b63c638fbb9b2585a5640d8b343af7ce997bafce1d4997af';
    wwv_flow_imp.g_varchar2_table(296) := 'dc8fa87384134e58dc708b970aae83e3211b9178d2706f'||wwv_flow.LF||
'f7bbb99aeb7081e211a22cc60d778eb97b65f7c30f2ea31d11e2';
    wwv_flow_imp.g_varchar2_table(297) := '083b601ff31dd4704321a63bf93c1fc230e297d814c7706dcc920809384d26f951828ec16f44'||wwv_flow.LF||
'f3a542a1928f10895d2746';
    wwv_flow_imp.g_varchar2_table(298) := '11b8bd311e932176fad2a5bbbb74dea1701a0b2e078634e949d7d8b050d8d1615122f89c0734718e106db830cf881df7f17d';
    wwv_flow_imp.g_varchar2_table(299) := 'e13a14'||wwv_flow.LF||
'7101171a6e41fdb9f9ddcb79b4b330a2628bad66d7557f0bbb85c1e8b0a4e64c26836c52cff3bd4a33f3af00546c';
    wwv_flow_imp.g_varchar2_table(300) := 'e23ad54ea553c9fc29001a0e61a52917dda7'||wwv_flow.LF||
'dfaab7dafe02ab81d2438bef76b55d2e1a78cd7f798373d3973f03af40a97f';
    wwv_flow_imp.g_varchar2_table(301) := '6f03dfed06104503af4029dedfc07b5eb51478065e81527c65035f2d34db5ed5c0'||wwv_flow.LF||
'2b5048497cb8812ef89572b05c6d0619';
    wwv_flow_imp.g_varchar2_table(302) := '33ba6785d77daf5b2d2d9caf50500d5975c929c62c16db6a2d42f758d2058004522448ec88f9148fd110aa3840940c12'||wwv_flow.LF||
'e2';
    wwv_flow_imp.g_varchar2_table(303) := 'ec93490885374531e3305c2815ba8532fc973f4f1da988a01d8c346bc90b98f08d21c9c7e1c3844c45c3fd18bcba1ae4cdcb';
    wwv_flow_imp.g_varchar2_table(304) := '1fdfbc7cee9c3c7a71f2e89793'||wwv_flow.LF||
'c78f4f1efd9c3a32acf6503cd1ad5e7fffc5df4f3f75fe7afeddeb275fd9f15cc7fffed3';
    wwv_flow_imp.g_varchar2_table(305) := '67bffdfaa51d082b5d85e0d5d7cffe78f1ecd5379ffff9c3130bbc99'||wwv_flow.LF||
'a0810eef930873e73a3e766eb10816a6426032c783';
    wwv_flow_imp.g_varchar2_table(306) := 'e4ed2cfa2122ba45339e701423398bc57f478406fafa1c5164c1b5b019c13b09488c0d787576cf20dc0b93'||wwv_flow.LF||
'9920168fd7c2';
    wwv_flow_imp.g_varchar2_table(307) := 'c8001e30465b2cb146e19a9c4b0b737f164fec9327331d770ba123dbdc018a8dfc766653d05662731984d8a07993a258a009';
    wwv_flow_imp.g_varchar2_table(308) := '8eb170e4357688b1'||wwv_flow.LF||
'6575770931e27a408609e36c2c9cbbc46921620d499f0c8c6a5a19ed9108f232b711847c1bb139b8e3';
    wwv_flow_imp.g_varchar2_table(309) := 'b418b5adba8d8f4c24dc15885ac8f73135c27815cd048a'||wwv_flow.LF||
'6c2efb28a27ac0f791086d247bf364a8e33a5c40a6279832a733';
    wwv_flow_imp.g_varchar2_table(310) := 'c29cdb6c6e24b05e2de9d7405eec693fa0f3c84426821cda7cee23c674649b1d06218aa6366c'||wwv_flow.LF||
'8fc4a18efd881f428922e7';
    wwv_flow_imp.g_varchar2_table(311) := '261336f80133ef10790e7940f1d674df21d848f7e96a701b9455a7b42a107965965872791533a37e7b733a4658490d08bfa1';
    wwv_flow_imp.g_varchar2_table(312) := 'e71189'||wwv_flow.LF||
'4f15f73559f7ff5b5907217df5ed53cbaa2eaaa0371362bda3f6d6647c1b6e5dbc03968cc8c5d7ee369ac53731dc';
    wwv_flow_imp.g_varchar2_table(313) := '2e9b0decbd74bf976ef77f2fdddbeee7772f'||wwv_flow.LF||
'd82b8d06f9965bc574abae36eed1d67dfb9850da13738af7b9daba73e84ca3';
    wwv_flow_imp.g_varchar2_table(314) := '2e0c4a3bf5cc8ab3e7b8690887f24e86090cdc2441cac64998f88488b017a229ec'||wwv_flow.LF||
'ef8bae7432e10bd713ee4c19876dbf1a';
    wwv_flow_imp.g_varchar2_table(315) := 'b6fa96783a8b0ed8287d5c2d16e5a3692a1e1c89d578c1cfc6e15143a4e84a75f50896b9576c27ea51794940dabe0d09'||wwv_flow.LF||
'6d';
    wwv_flow_imp.g_varchar2_table(316) := '329344d942a2ba1c9441520fe610340b09b5b277c2a26e615193ee97a9da6001d4b2acc0d6c9810d57c3f53d30012378a242';
    wwv_flow_imp.g_varchar2_table(317) := '148f649ed2542fb3ab92f92e33'||wwv_flow.LF||
'bd2d984605c03e625901ab4cd725d7adcb93ab4b4bed0c99364868e566925091513d8c87';
    wwv_flow_imp.g_varchar2_table(318) := '688417d52947cf42e36d735d5fa5d4a02743a1e683d25ad1a8d6fe8d'||wwv_flow.LF||
'c579730d76ebda40635d2968ec1c37dc4ad9879219';
    wwv_flow_imp.g_varchar2_table(319) := 'a269c31dc3633f1c4653a81d2eb7bc884ee0ddd95024e90d7f1e6599265cb4110fd3802bd149d520220227'||wwv_flow.LF||
'0e2551c395cb';
    wwv_flow_imp.g_varchar2_table(320) := 'cfd24063a5218a5bb104827061c9d541562e1a3948ba99643c1ee3a1d0d3ae8dc848a7a7a0f0a95658af2af3f383a5259b41';
    wwv_flow_imp.g_varchar2_table(321) := 'ba7be1e8d819d059'||wwv_flow.LF||
'720b4189f9d5a20ce0887078fb534ca33922f03a3313b255fdad35a685eceaef13550da5e3884e43b4';
    wwv_flow_imp.g_varchar2_table(322) := 'e828ba98a77025e5191d7596c5403b5bac1902aa8564d1'||wwv_flow.LF||
'080713d960f5a01add34eb1a2987ad5df7742319394d34573dd3';
    wwv_flow_imp.g_varchar2_table(323) := '5015d935ed2a66ccb06c036bb13c5f93d7582d430c9aa677f854bad725b7bed4bab57d42d625'||wwv_flow.LF||
'20e059fc2c5df70c0d41a3';
    wwv_flow_imp.g_varchar2_table(324) := 'b69acca026196fcab0d4ecc5a8d93b960b3c85da599a84a6fa95a5dbb5b8653dc23a1d0c9eabf383dd7ad5c2d078b9af5491';
    wwv_flow_imp.g_varchar2_table(325) := '56df3d'||wwv_flow.LF||
'f44f136c700fc4a30d2f81675470954af8f09020d810f5d49e24950db845ee8bc5ad0147ce2c210df741c16f7a41';
    wwv_flow_imp.g_varchar2_table(326) := 'c90f72859adfc97965af90abf9cd72aee9fb'||wwv_flow.LF||
'e562c72f16daadd243682c228c8a7efacda50bafa2e87cf1e5458d6f7c7d89';
    wwv_flow_imp.g_varchar2_table(327) := '966fdb2e0d599467eaeb4a5e11575f5f8aa5ed5f5f1c02a2f3a052ead6cbf55625'||wwv_flow.LF||
'572f37bb39afddaae5ea41a5956b5782';
    wwv_flow_imp.g_varchar2_table(328) := '6abbdb0efc5abdfbd0758e14d86b9603afd2a9e52ac520c8799582a45fabe7aa5ea9d4f4aacd5ac76b3e5c6c6360e5a9'||wwv_flow.LF||
'7c';
    wwv_flow_imp.g_varchar2_table(329) := '2c6201e155bc76ff010000ffff0300504b0304140006000800000021000dd1909fb60000001b010000270000007468656d65';
    wwv_flow_imp.g_varchar2_table(330) := '2f7468656d652f5f72656c732f'||wwv_flow.LF||
'7468656d654d616e616765722e786d6c2e72656c73848f4d0ac2301484f78277086f6fd3';
    wwv_flow_imp.g_varchar2_table(331) := 'ba109126dd88d0add40384e4350d363f2451eced0dae2c082e8761be'||wwv_flow.LF||
'9969bb979dc9136332de3168aa1a083ae995719ac1';
    wwv_flow_imp.g_varchar2_table(332) := '6db8ec8e4052164e89d93b64b060828e6f37ed1567914b284d262452282e3198720e274a939cd08a54f980'||wwv_flow.LF||
'ae38a38f56e4';
    wwv_flow_imp.g_varchar2_table(333) := '22a3a641c8bbd048f7757da0f19b017cc524bd62107bd5001996509affb3fd381a89672f1f165dfe514173d9850528a2c6cc';
    wwv_flow_imp.g_varchar2_table(334) := 'e0239baa4c04ca5b'||wwv_flow.LF||
'babac4df000000ffff0300504b01022d0014000600080000002100e9de0fbfff0000001c0200001300';
    wwv_flow_imp.g_varchar2_table(335) := '000000000000000000000000000000005b436f6e74656e'||wwv_flow.LF||
'745f54797065735d2e786d6c504b01022d001400060008000000';
    wwv_flow_imp.g_varchar2_table(336) := '2100a5d6a7e7c0000000360100000b00000000000000000000000000300100005f72656c732f'||wwv_flow.LF||
'2e72656c73504b01022d00';
    wwv_flow_imp.g_varchar2_table(337) := '140006000800000021006b799616830000008a0000001c00000000000000000000000000190200007468656d652f7468656d';
    wwv_flow_imp.g_varchar2_table(338) := '652f74'||wwv_flow.LF||
'68656d654d616e616765722e786d6c504b01022d0014000600080000002100aa5225dfc60600008b1a0000160000';
    wwv_flow_imp.g_varchar2_table(339) := '0000000000000000000000d6020000746865'||wwv_flow.LF||
'6d652f7468656d652f7468656d65312e786d6c504b01022d00140006000800';
    wwv_flow_imp.g_varchar2_table(340) := '000021000dd1909fb60000001b0100002700000000000000000000000000d00900007468656d652f7468656d652f5f72656c';
    wwv_flow_imp.g_varchar2_table(341) := '732f7468656d654d616e616765722e786d6c2e72656c73504b050600000000050005005d010000cb0a00000000}'||wwv_flow.LF||
'{\*\col';
    wwv_flow_imp.g_varchar2_table(342) := 'orschememapping 3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554462d3822207374616e64';
    wwv_flow_imp.g_varchar2_table(343) := '616c6f6e653d22796573223f3e0d0a3c613a636c724d'||wwv_flow.LF||
'617020786d6c6e733a613d22687474703a2f2f736368656d61732e';
    wwv_flow_imp.g_varchar2_table(344) := '6f70656e786d6c666f726d6174732e6f72672f64726177696e676d6c2f323030362f6d6169'||wwv_flow.LF||
'6e22206267313d226c743122';
    wwv_flow_imp.g_varchar2_table(345) := '207478313d22646b3122206267323d226c743222207478323d22646b322220616363656e74313d22616363656e7431222061';
    wwv_flow_imp.g_varchar2_table(346) := '6363'||wwv_flow.LF||
'656e74323d22616363656e74322220616363656e74333d22616363656e74332220616363656e74343d22616363656e';
    wwv_flow_imp.g_varchar2_table(347) := '74342220616363656e74353d22616363656e74352220616363656e74363d22616363656e74362220686c696e6b3d22686c69';
    wwv_flow_imp.g_varchar2_table(348) := '6e6b2220666f6c486c696e6b3d22666f6c486c696e6b222f3e}'||wwv_flow.LF||
'{\*\latentstyles\lsdstimax371\lsdlockeddef0\lsd';
    wwv_flow_imp.g_varchar2_table(349) := 'semihiddendef0\lsdunhideuseddef0\lsdqformatdef0\lsdprioritydef99{\lsdlockedexcept \lsdqformat1 \lsdp';
    wwv_flow_imp.g_varchar2_table(350) := 'riority0 \lsdlocked0 Normal;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 1;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdu';
    wwv_flow_imp.g_varchar2_table(351) := 'nhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 2;\lsdsemihidden1 \lsdunhideused1 \lsdqfor';
    wwv_flow_imp.g_varchar2_table(352) := 'mat1 \lsdpriority9 \lsdlocked0 heading 3;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 ';
    wwv_flow_imp.g_varchar2_table(353) := '\lsdlocked0 heading 4;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 headi';
    wwv_flow_imp.g_varchar2_table(354) := 'ng 5;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 6;\lsdsemihidden';
    wwv_flow_imp.g_varchar2_table(355) := '1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 7;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1';
    wwv_flow_imp.g_varchar2_table(356) := ' \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 8;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdp';
    wwv_flow_imp.g_varchar2_table(357) := 'riority9 \lsdlocked0 heading 9;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 1;'||wwv_flow.LF||
'\lsdsemihidden1';
    wwv_flow_imp.g_varchar2_table(358) := ' \lsdunhideused1 \lsdlocked0 index 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 3;\lsdsemihid';
    wwv_flow_imp.g_varchar2_table(359) := 'den1 \lsdunhideused1 \lsdlocked0 index 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 5;'||wwv_flow.LF||
'\lsds';
    wwv_flow_imp.g_varchar2_table(360) := 'emihidden1 \lsdunhideused1 \lsdlocked0 index 6;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 7;\';
    wwv_flow_imp.g_varchar2_table(361) := 'lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 8;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index';
    wwv_flow_imp.g_varchar2_table(362) := ' 9;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 1;\lsdsemihidden1 \lsdunhideused';
    wwv_flow_imp.g_varchar2_table(363) := '1 \lsdpriority39 \lsdlocked0 toc 2;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 3;';
    wwv_flow_imp.g_varchar2_table(364) := ''||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 4;\lsdsemihidden1 \lsdunhideused1 \';
    wwv_flow_imp.g_varchar2_table(365) := 'lsdpriority39 \lsdlocked0 toc 5;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 6;'||wwv_flow.LF||
'\';
    wwv_flow_imp.g_varchar2_table(366) := 'lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 7;\lsdsemihidden1 \lsdunhideused1 \lsd';
    wwv_flow_imp.g_varchar2_table(367) := 'priority39 \lsdlocked0 toc 8;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 9;\lsdse';
    wwv_flow_imp.g_varchar2_table(368) := 'mihidden1 \lsdunhideused1 \lsdlocked0 Normal Indent;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 fo';
    wwv_flow_imp.g_varchar2_table(369) := 'otnote text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 annotation text;\lsdsemihidden1 \lsdunhideus';
    wwv_flow_imp.g_varchar2_table(370) := 'ed1 \lsdlocked0 header;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 footer;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhi';
    wwv_flow_imp.g_varchar2_table(371) := 'deused1 \lsdlocked0 index heading;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority35 \lsdlo';
    wwv_flow_imp.g_varchar2_table(372) := 'cked0 caption;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 table of figures;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunh';
    wwv_flow_imp.g_varchar2_table(373) := 'ideused1 \lsdlocked0 envelope address;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 envelope return;\l';
    wwv_flow_imp.g_varchar2_table(374) := 'sdsemihidden1 \lsdunhideused1 \lsdlocked0 footnote reference;\lsdsemihidden1 \lsdunhideused1 \lsdloc';
    wwv_flow_imp.g_varchar2_table(375) := 'ked0 annotation reference;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 line number;\lsdsemihidden1 ';
    wwv_flow_imp.g_varchar2_table(376) := '\lsdunhideused1 \lsdlocked0 page number;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 endnote referenc';
    wwv_flow_imp.g_varchar2_table(377) := 'e;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 endnote text;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdloc';
    wwv_flow_imp.g_varchar2_table(378) := 'ked0 table of authorities;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 macro;\lsdsemihidden1 \lsdunhi';
    wwv_flow_imp.g_varchar2_table(379) := 'deused1 \lsdlocked0 toa heading;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List;'||wwv_flow.LF||
'\lsdsemihidden1 \';
    wwv_flow_imp.g_varchar2_table(380) := 'lsdunhideused1 \lsdlocked0 List Bullet;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number;\lsds';
    wwv_flow_imp.g_varchar2_table(381) := 'emihidden1 \lsdunhideused1 \lsdlocked0 List 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List 3;'||wwv_flow.LF||
'\';
    wwv_flow_imp.g_varchar2_table(382) := 'lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List 5';
    wwv_flow_imp.g_varchar2_table(383) := ';\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(384) := 'd0 List Bullet 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 4;\lsdsemihidden1 \lsdunh';
    wwv_flow_imp.g_varchar2_table(385) := 'ideused1 \lsdlocked0 List Bullet 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number 2;\lsdsem';
    wwv_flow_imp.g_varchar2_table(386) := 'ihidden1 \lsdunhideused1 \lsdlocked0 List Number 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Lis';
    wwv_flow_imp.g_varchar2_table(387) := 't Number 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number 5;\lsdqformat1 \lsdpriority10 \ls';
    wwv_flow_imp.g_varchar2_table(388) := 'dlocked0 Title;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Closing;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1';
    wwv_flow_imp.g_varchar2_table(389) := ' \lsdlocked0 Signature;\lsdsemihidden1 \lsdunhideused1 \lsdpriority1 \lsdlocked0 Default Paragraph F';
    wwv_flow_imp.g_varchar2_table(390) := 'ont;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(391) := '0 Body Text Indent;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue;\lsdsemihidden1 \lsdu';
    wwv_flow_imp.g_varchar2_table(392) := 'nhideused1 \lsdlocked0 List Continue 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue 3;\';
    wwv_flow_imp.g_varchar2_table(393) := 'lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue 4;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdloc';
    wwv_flow_imp.g_varchar2_table(394) := 'ked0 List Continue 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Message Header;\lsdqformat1 \lsdpri';
    wwv_flow_imp.g_varchar2_table(395) := 'ority11 \lsdlocked0 Subtitle;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Salutation;'||wwv_flow.LF||
'\lsdsemihidden';
    wwv_flow_imp.g_varchar2_table(396) := '1 \lsdunhideused1 \lsdlocked0 Date;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text First Inden';
    wwv_flow_imp.g_varchar2_table(397) := 't;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text First Indent 2;\lsdsemihidden1 \lsdunhideuse';
    wwv_flow_imp.g_varchar2_table(398) := 'd1 \lsdlocked0 Note Heading;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text 2;\lsdsemihidden';
    wwv_flow_imp.g_varchar2_table(399) := '1 \lsdunhideused1 \lsdlocked0 Body Text 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text Inde';
    wwv_flow_imp.g_varchar2_table(400) := 'nt 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text Indent 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused';
    wwv_flow_imp.g_varchar2_table(401) := '1 \lsdlocked0 Block Text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Hyperlink;\lsdsemihidden1 \lsdu';
    wwv_flow_imp.g_varchar2_table(402) := 'nhideused1 \lsdlocked0 FollowedHyperlink;\lsdqformat1 \lsdpriority22 \lsdlocked0 Strong;'||wwv_flow.LF||
'\lsdqforma';
    wwv_flow_imp.g_varchar2_table(403) := 't1 \lsdpriority20 \lsdlocked0 Emphasis;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Document Map;\lsd';
    wwv_flow_imp.g_varchar2_table(404) := 'semihidden1 \lsdunhideused1 \lsdlocked0 Plain Text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 E-mai';
    wwv_flow_imp.g_varchar2_table(405) := 'l Signature;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Top of Form;\lsdsemihidden1 \lsdunhid';
    wwv_flow_imp.g_varchar2_table(406) := 'eused1 \lsdlocked0 HTML Bottom of Form;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Normal (Web);\lsd';
    wwv_flow_imp.g_varchar2_table(407) := 'semihidden1 \lsdunhideused1 \lsdlocked0 HTML Acronym;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 H';
    wwv_flow_imp.g_varchar2_table(408) := 'TML Address;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Cite;\lsdsemihidden1 \lsdunhideused1 \l';
    wwv_flow_imp.g_varchar2_table(409) := 'sdlocked0 HTML Code;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Definition;'||wwv_flow.LF||
'\lsdsemihidden1 \l';
    wwv_flow_imp.g_varchar2_table(410) := 'sdunhideused1 \lsdlocked0 HTML Keyboard;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Preformatte';
    wwv_flow_imp.g_varchar2_table(411) := 'd;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Sample;\lsdsemihidden1 \lsdunhideused1 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(412) := '0 HTML Typewriter;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Variable;\lsdsemihidden1 \lsdun';
    wwv_flow_imp.g_varchar2_table(413) := 'hideused1 \lsdlocked0 annotation subject;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 No List;\lsdsem';
    wwv_flow_imp.g_varchar2_table(414) := 'ihidden1 \lsdunhideused1 \lsdlocked0 Outline List 1;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Ou';
    wwv_flow_imp.g_varchar2_table(415) := 'tline List 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Outline List 3;\lsdsemihidden1 \lsdunhideus';
    wwv_flow_imp.g_varchar2_table(416) := 'ed1 \lsdlocked0 Balloon Text;\lsdpriority39 \lsdlocked0 Table Grid;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdlocked0 Pla';
    wwv_flow_imp.g_varchar2_table(417) := 'ceholder Text;\lsdqformat1 \lsdpriority1 \lsdlocked0 No Spacing;\lsdpriority60 \lsdlocked0 Light Sha';
    wwv_flow_imp.g_varchar2_table(418) := 'ding;\lsdpriority61 \lsdlocked0 Light List;\lsdpriority62 \lsdlocked0 Light Grid;'||wwv_flow.LF||
'\lsdpriority63 \l';
    wwv_flow_imp.g_varchar2_table(419) := 'sdlocked0 Medium Shading 1;\lsdpriority64 \lsdlocked0 Medium Shading 2;\lsdpriority65 \lsdlocked0 Me';
    wwv_flow_imp.g_varchar2_table(420) := 'dium List 1;\lsdpriority66 \lsdlocked0 Medium List 2;\lsdpriority67 \lsdlocked0 Medium Grid 1;\lsdpr';
    wwv_flow_imp.g_varchar2_table(421) := 'iority68 \lsdlocked0 Medium Grid 2;'||wwv_flow.LF||
'\lsdpriority69 \lsdlocked0 Medium Grid 3;\lsdpriority70 \lsdloc';
    wwv_flow_imp.g_varchar2_table(422) := 'ked0 Dark List;\lsdpriority71 \lsdlocked0 Colorful Shading;\lsdpriority72 \lsdlocked0 Colorful List;';
    wwv_flow_imp.g_varchar2_table(423) := '\lsdpriority73 \lsdlocked0 Colorful Grid;\lsdpriority60 \lsdlocked0 Light Shading Accent 1;'||wwv_flow.LF||
'\lsdpri';
    wwv_flow_imp.g_varchar2_table(424) := 'ority61 \lsdlocked0 Light List Accent 1;\lsdpriority62 \lsdlocked0 Light Grid Accent 1;\lsdpriority6';
    wwv_flow_imp.g_varchar2_table(425) := '3 \lsdlocked0 Medium Shading 1 Accent 1;\lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 1;\lsdpri';
    wwv_flow_imp.g_varchar2_table(426) := 'ority65 \lsdlocked0 Medium List 1 Accent 1;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdlocked0 Revision;\lsdqformat1 \lsdp';
    wwv_flow_imp.g_varchar2_table(427) := 'riority34 \lsdlocked0 List Paragraph;\lsdqformat1 \lsdpriority29 \lsdlocked0 Quote;\lsdqformat1 \lsd';
    wwv_flow_imp.g_varchar2_table(428) := 'priority30 \lsdlocked0 Intense Quote;\lsdpriority66 \lsdlocked0 Medium List 2 Accent 1;'||wwv_flow.LF||
'\lsdpriorit';
    wwv_flow_imp.g_varchar2_table(429) := 'y67 \lsdlocked0 Medium Grid 1 Accent 1;\lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 1;\lsdpriorit';
    wwv_flow_imp.g_varchar2_table(430) := 'y69 \lsdlocked0 Medium Grid 3 Accent 1;\lsdpriority70 \lsdlocked0 Dark List Accent 1;\lsdpriority71 ';
    wwv_flow_imp.g_varchar2_table(431) := '\lsdlocked0 Colorful Shading Accent 1;'||wwv_flow.LF||
'\lsdpriority72 \lsdlocked0 Colorful List Accent 1;\lsdpriori';
    wwv_flow_imp.g_varchar2_table(432) := 'ty73 \lsdlocked0 Colorful Grid Accent 1;\lsdpriority60 \lsdlocked0 Light Shading Accent 2;\lsdpriori';
    wwv_flow_imp.g_varchar2_table(433) := 'ty61 \lsdlocked0 Light List Accent 2;\lsdpriority62 \lsdlocked0 Light Grid Accent 2;'||wwv_flow.LF||
'\lsdpriority63';
    wwv_flow_imp.g_varchar2_table(434) := ' \lsdlocked0 Medium Shading 1 Accent 2;\lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 2;\lsdprio';
    wwv_flow_imp.g_varchar2_table(435) := 'rity65 \lsdlocked0 Medium List 1 Accent 2;\lsdpriority66 \lsdlocked0 Medium List 2 Accent 2;'||wwv_flow.LF||
'\lsdpr';
    wwv_flow_imp.g_varchar2_table(436) := 'iority67 \lsdlocked0 Medium Grid 1 Accent 2;\lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 2;\lsdpr';
    wwv_flow_imp.g_varchar2_table(437) := 'iority69 \lsdlocked0 Medium Grid 3 Accent 2;\lsdpriority70 \lsdlocked0 Dark List Accent 2;\lsdpriori';
    wwv_flow_imp.g_varchar2_table(438) := 'ty71 \lsdlocked0 Colorful Shading Accent 2;'||wwv_flow.LF||
'\lsdpriority72 \lsdlocked0 Colorful List Accent 2;\lsdp';
    wwv_flow_imp.g_varchar2_table(439) := 'riority73 \lsdlocked0 Colorful Grid Accent 2;\lsdpriority60 \lsdlocked0 Light Shading Accent 3;\lsdp';
    wwv_flow_imp.g_varchar2_table(440) := 'riority61 \lsdlocked0 Light List Accent 3;\lsdpriority62 \lsdlocked0 Light Grid Accent 3;'||wwv_flow.LF||
'\lsdprior';
    wwv_flow_imp.g_varchar2_table(441) := 'ity63 \lsdlocked0 Medium Shading 1 Accent 3;\lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 3;\ls';
    wwv_flow_imp.g_varchar2_table(442) := 'dpriority65 \lsdlocked0 Medium List 1 Accent 3;\lsdpriority66 \lsdlocked0 Medium List 2 Accent 3;'||wwv_flow.LF||
'\';
    wwv_flow_imp.g_varchar2_table(443) := 'lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 3;\lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 3;\';
    wwv_flow_imp.g_varchar2_table(444) := 'lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 3;\lsdpriority70 \lsdlocked0 Dark List Accent 3;\lsdp';
    wwv_flow_imp.g_varchar2_table(445) := 'riority71 \lsdlocked0 Colorful Shading Accent 3;'||wwv_flow.LF||
'\lsdpriority72 \lsdlocked0 Colorful List Accent 3;';
    wwv_flow_imp.g_varchar2_table(446) := '\lsdpriority73 \lsdlocked0 Colorful Grid Accent 3;\lsdpriority60 \lsdlocked0 Light Shading Accent 4;';
    wwv_flow_imp.g_varchar2_table(447) := '\lsdpriority61 \lsdlocked0 Light List Accent 4;\lsdpriority62 \lsdlocked0 Light Grid Accent 4;'||wwv_flow.LF||
'\lsd';
    wwv_flow_imp.g_varchar2_table(448) := 'priority63 \lsdlocked0 Medium Shading 1 Accent 4;\lsdpriority64 \lsdlocked0 Medium Shading 2 Accent ';
    wwv_flow_imp.g_varchar2_table(449) := '4;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 4;\lsdpriority66 \lsdlocked0 Medium List 2 Accent ';
    wwv_flow_imp.g_varchar2_table(450) := '4;'||wwv_flow.LF||
'\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 4;\lsdpriority68 \lsdlocked0 Medium Grid 2 Accen';
    wwv_flow_imp.g_varchar2_table(451) := 't 4;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 4;\lsdpriority70 \lsdlocked0 Dark List Accent 4;';
    wwv_flow_imp.g_varchar2_table(452) := '\lsdpriority71 \lsdlocked0 Colorful Shading Accent 4;'||wwv_flow.LF||
'\lsdpriority72 \lsdlocked0 Colorful List Acce';
    wwv_flow_imp.g_varchar2_table(453) := 'nt 4;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 4;\lsdpriority60 \lsdlocked0 Light Shading Acce';
    wwv_flow_imp.g_varchar2_table(454) := 'nt 5;\lsdpriority61 \lsdlocked0 Light List Accent 5;\lsdpriority62 \lsdlocked0 Light Grid Accent 5;';
    wwv_flow_imp.g_varchar2_table(455) := ''||wwv_flow.LF||
'\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 5;\lsdpriority64 \lsdlocked0 Medium Shading 2 Ac';
    wwv_flow_imp.g_varchar2_table(456) := 'cent 5;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 5;\lsdpriority66 \lsdlocked0 Medium List 2 Ac';
    wwv_flow_imp.g_varchar2_table(457) := 'cent 5;'||wwv_flow.LF||
'\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 5;\lsdpriority68 \lsdlocked0 Medium Grid 2 ';
    wwv_flow_imp.g_varchar2_table(458) := 'Accent 5;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 5;\lsdpriority70 \lsdlocked0 Dark List Acce';
    wwv_flow_imp.g_varchar2_table(459) := 'nt 5;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 5;'||wwv_flow.LF||
'\lsdpriority72 \lsdlocked0 Colorful List';
    wwv_flow_imp.g_varchar2_table(460) := ' Accent 5;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 5;\lsdpriority60 \lsdlocked0 Light Shading';
    wwv_flow_imp.g_varchar2_table(461) := ' Accent 6;\lsdpriority61 \lsdlocked0 Light List Accent 6;\lsdpriority62 \lsdlocked0 Light Grid Accen';
    wwv_flow_imp.g_varchar2_table(462) := 't 6;'||wwv_flow.LF||
'\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 6;\lsdpriority64 \lsdlocked0 Medium Shading';
    wwv_flow_imp.g_varchar2_table(463) := ' 2 Accent 6;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 6;\lsdpriority66 \lsdlocked0 Medium List';
    wwv_flow_imp.g_varchar2_table(464) := ' 2 Accent 6;'||wwv_flow.LF||
'\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 6;\lsdpriority68 \lsdlocked0 Medium Gr';
    wwv_flow_imp.g_varchar2_table(465) := 'id 2 Accent 6;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 6;\lsdpriority70 \lsdlocked0 Dark List';
    wwv_flow_imp.g_varchar2_table(466) := ' Accent 6;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 6;'||wwv_flow.LF||
'\lsdpriority72 \lsdlocked0 Colorful';
    wwv_flow_imp.g_varchar2_table(467) := ' List Accent 6;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 6;\lsdqformat1 \lsdpriority19 \lsdloc';
    wwv_flow_imp.g_varchar2_table(468) := 'ked0 Subtle Emphasis;\lsdqformat1 \lsdpriority21 \lsdlocked0 Intense Emphasis;'||wwv_flow.LF||
'\lsdqformat1 \lsdpri';
    wwv_flow_imp.g_varchar2_table(469) := 'ority31 \lsdlocked0 Subtle Reference;\lsdqformat1 \lsdpriority32 \lsdlocked0 Intense Reference;\lsdq';
    wwv_flow_imp.g_varchar2_table(470) := 'format1 \lsdpriority33 \lsdlocked0 Book Title;\lsdsemihidden1 \lsdunhideused1 \lsdpriority37 \lsdloc';
    wwv_flow_imp.g_varchar2_table(471) := 'ked0 Bibliography;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority39 \lsdlocked0 TOC Head';
    wwv_flow_imp.g_varchar2_table(472) := 'ing;\lsdpriority41 \lsdlocked0 Plain Table 1;\lsdpriority42 \lsdlocked0 Plain Table 2;\lsdpriority43';
    wwv_flow_imp.g_varchar2_table(473) := ' \lsdlocked0 Plain Table 3;\lsdpriority44 \lsdlocked0 Plain Table 4;'||wwv_flow.LF||
'\lsdpriority45 \lsdlocked0 Pla';
    wwv_flow_imp.g_varchar2_table(474) := 'in Table 5;\lsdpriority40 \lsdlocked0 Grid Table Light;\lsdpriority46 \lsdlocked0 Grid Table 1 Light';
    wwv_flow_imp.g_varchar2_table(475) := ';\lsdpriority47 \lsdlocked0 Grid Table 2;\lsdpriority48 \lsdlocked0 Grid Table 3;\lsdpriority49 \lsd';
    wwv_flow_imp.g_varchar2_table(476) := 'locked0 Grid Table 4;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 Grid Table 5 Dark;\lsdpriority51 \lsdlocked0 Grid ';
    wwv_flow_imp.g_varchar2_table(477) := 'Table 6 Colorful;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful;\lsdpriority46 \lsdlocked0 Grid Ta';
    wwv_flow_imp.g_varchar2_table(478) := 'ble 1 Light Accent 1;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 1;'||wwv_flow.LF||
'\lsdpriority48 \lsdlocked0 G';
    wwv_flow_imp.g_varchar2_table(479) := 'rid Table 3 Accent 1;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 1;\lsdpriority50 \lsdlocked0 Gri';
    wwv_flow_imp.g_varchar2_table(480) := 'd Table 5 Dark Accent 1;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 1;'||wwv_flow.LF||
'\lsdpriority52 \';
    wwv_flow_imp.g_varchar2_table(481) := 'lsdlocked0 Grid Table 7 Colorful Accent 1;\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 2;\ls';
    wwv_flow_imp.g_varchar2_table(482) := 'dpriority47 \lsdlocked0 Grid Table 2 Accent 2;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 2;'||wwv_flow.LF||
'\ls';
    wwv_flow_imp.g_varchar2_table(483) := 'dpriority49 \lsdlocked0 Grid Table 4 Accent 2;\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 2;';
    wwv_flow_imp.g_varchar2_table(484) := '\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 2;\lsdpriority52 \lsdlocked0 Grid Table 7 Co';
    wwv_flow_imp.g_varchar2_table(485) := 'lorful Accent 2;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 3;\lsdpriority47 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(486) := 'Grid Table 2 Accent 3;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 3;\lsdpriority49 \lsdlocked0 Gr';
    wwv_flow_imp.g_varchar2_table(487) := 'id Table 4 Accent 3;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 3;\lsdpriority51 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(488) := 'd0 Grid Table 6 Colorful Accent 3;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 3;\lsdprio';
    wwv_flow_imp.g_varchar2_table(489) := 'rity46 \lsdlocked0 Grid Table 1 Light Accent 4;'||wwv_flow.LF||
'\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 4;\l';
    wwv_flow_imp.g_varchar2_table(490) := 'sdpriority48 \lsdlocked0 Grid Table 3 Accent 4;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 4;\lsd';
    wwv_flow_imp.g_varchar2_table(491) := 'priority50 \lsdlocked0 Grid Table 5 Dark Accent 4;'||wwv_flow.LF||
'\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful';
    wwv_flow_imp.g_varchar2_table(492) := ' Accent 4;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 4;\lsdpriority46 \lsdlocked0 Grid ';
    wwv_flow_imp.g_varchar2_table(493) := 'Table 1 Light Accent 5;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 5;'||wwv_flow.LF||
'\lsdpriority48 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(494) := ' Grid Table 3 Accent 5;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 5;\lsdpriority50 \lsdlocked0 G';
    wwv_flow_imp.g_varchar2_table(495) := 'rid Table 5 Dark Accent 5;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 5;'||wwv_flow.LF||
'\lsdpriority52';
    wwv_flow_imp.g_varchar2_table(496) := ' \lsdlocked0 Grid Table 7 Colorful Accent 5;\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 6;\';
    wwv_flow_imp.g_varchar2_table(497) := 'lsdpriority47 \lsdlocked0 Grid Table 2 Accent 6;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 6;'||wwv_flow.LF||
'\';
    wwv_flow_imp.g_varchar2_table(498) := 'lsdpriority49 \lsdlocked0 Grid Table 4 Accent 6;\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent ';
    wwv_flow_imp.g_varchar2_table(499) := '6;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 6;\lsdpriority52 \lsdlocked0 Grid Table 7 ';
    wwv_flow_imp.g_varchar2_table(500) := 'Colorful Accent 6;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 List Table 1 Light;\lsdpriority47 \lsdlocked0 List Ta';
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
    wwv_flow_imp.g_varchar2_table(501) := 'ble 2;\lsdpriority48 \lsdlocked0 List Table 3;\lsdpriority49 \lsdlocked0 List Table 4;\lsdpriority50';
    wwv_flow_imp.g_varchar2_table(502) := ' \lsdlocked0 List Table 5 Dark;'||wwv_flow.LF||
'\lsdpriority51 \lsdlocked0 List Table 6 Colorful;\lsdpriority52 \ls';
    wwv_flow_imp.g_varchar2_table(503) := 'dlocked0 List Table 7 Colorful;\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 1;\lsdpriority47';
    wwv_flow_imp.g_varchar2_table(504) := ' \lsdlocked0 List Table 2 Accent 1;\lsdpriority48 \lsdlocked0 List Table 3 Accent 1;'||wwv_flow.LF||
'\lsdpriority49';
    wwv_flow_imp.g_varchar2_table(505) := ' \lsdlocked0 List Table 4 Accent 1;\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 1;\lsdpriorit';
    wwv_flow_imp.g_varchar2_table(506) := 'y51 \lsdlocked0 List Table 6 Colorful Accent 1;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Acce';
    wwv_flow_imp.g_varchar2_table(507) := 'nt 1;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 2;\lsdpriority47 \lsdlocked0 List Table ';
    wwv_flow_imp.g_varchar2_table(508) := '2 Accent 2;\lsdpriority48 \lsdlocked0 List Table 3 Accent 2;\lsdpriority49 \lsdlocked0 List Table 4 ';
    wwv_flow_imp.g_varchar2_table(509) := 'Accent 2;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 2;\lsdpriority51 \lsdlocked0 List Tab';
    wwv_flow_imp.g_varchar2_table(510) := 'le 6 Colorful Accent 2;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 2;\lsdpriority46 \lsd';
    wwv_flow_imp.g_varchar2_table(511) := 'locked0 List Table 1 Light Accent 3;'||wwv_flow.LF||
'\lsdpriority47 \lsdlocked0 List Table 2 Accent 3;\lsdpriority4';
    wwv_flow_imp.g_varchar2_table(512) := '8 \lsdlocked0 List Table 3 Accent 3;\lsdpriority49 \lsdlocked0 List Table 4 Accent 3;\lsdpriority50 ';
    wwv_flow_imp.g_varchar2_table(513) := '\lsdlocked0 List Table 5 Dark Accent 3;'||wwv_flow.LF||
'\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 3;\';
    wwv_flow_imp.g_varchar2_table(514) := 'lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 3;\lsdpriority46 \lsdlocked0 List Table 1 Lig';
    wwv_flow_imp.g_varchar2_table(515) := 'ht Accent 4;\lsdpriority47 \lsdlocked0 List Table 2 Accent 4;'||wwv_flow.LF||
'\lsdpriority48 \lsdlocked0 List Table';
    wwv_flow_imp.g_varchar2_table(516) := ' 3 Accent 4;\lsdpriority49 \lsdlocked0 List Table 4 Accent 4;\lsdpriority50 \lsdlocked0 List Table 5';
    wwv_flow_imp.g_varchar2_table(517) := ' Dark Accent 4;\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 4;'||wwv_flow.LF||
'\lsdpriority52 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(518) := '0 List Table 7 Colorful Accent 4;\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 5;\lsdpriority';
    wwv_flow_imp.g_varchar2_table(519) := '47 \lsdlocked0 List Table 2 Accent 5;\lsdpriority48 \lsdlocked0 List Table 3 Accent 5;'||wwv_flow.LF||
'\lsdpriority';
    wwv_flow_imp.g_varchar2_table(520) := '49 \lsdlocked0 List Table 4 Accent 5;\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 5;\lsdprior';
    wwv_flow_imp.g_varchar2_table(521) := 'ity51 \lsdlocked0 List Table 6 Colorful Accent 5;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Ac';
    wwv_flow_imp.g_varchar2_table(522) := 'cent 5;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 6;\lsdpriority47 \lsdlocked0 List Tabl';
    wwv_flow_imp.g_varchar2_table(523) := 'e 2 Accent 6;\lsdpriority48 \lsdlocked0 List Table 3 Accent 6;\lsdpriority49 \lsdlocked0 List Table ';
    wwv_flow_imp.g_varchar2_table(524) := '4 Accent 6;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 6;\lsdpriority51 \lsdlocked0 List T';
    wwv_flow_imp.g_varchar2_table(525) := 'able 6 Colorful Accent 6;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 6;}}{\*\datastore 0';
    wwv_flow_imp.g_varchar2_table(526) := '10500000200000018000000'||wwv_flow.LF||
'4d73786d6c322e534158584d4c5265616465722e362e3000000000000000000000060000'||wwv_flow.LF||
'd';
    wwv_flow_imp.g_varchar2_table(527) := '0cf11e0a1b11ae1000000000000000000000000000000003e000300feff09000600000000000000000000000100000001000';
    wwv_flow_imp.g_varchar2_table(528) := '0000000000000100000feffffff00000000feffffff0000000000000000fffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(529) := 'fffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(530) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(531) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(532) := 'fffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(533) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(534) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(535) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(536) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(537) := 'fffffffffffff'||wwv_flow.LF||
'fffffffffffffffffdfffffffefffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(538) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(539) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(540) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(541) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(542) := 'fffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(543) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(544) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(545) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(546) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(547) := 'fffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffff52006f006f007400200045006e00740072007';
    wwv_flow_imp.g_varchar2_table(548) := '900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016000500f';
    wwv_flow_imp.g_varchar2_table(549) := 'fffffffffffffffffffffff0c6ad98892f1d411a65f0040963251e5000000000000000000000000e08f'||wwv_flow.LF||
'1ab78c52d801fef';
    wwv_flow_imp.g_varchar2_table(550) := 'fffff00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(551) := '000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff0000000000000000000';
    wwv_flow_imp.g_varchar2_table(552) := '0000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(553) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(554) := '000000000000000ffffffffffffffffffffffff0000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000';
    wwv_flow_imp.g_varchar2_table(555) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(556) := '0000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff000';
    wwv_flow_imp.g_varchar2_table(557) := '000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000001050';
    wwv_flow_imp.g_varchar2_table(558) := '00000000000}}';
wwv_flow_imp_shared.create_report_layout(
 p_id=>wwv_flow_imp.id(1410090043887221280)
,p_report_layout_name=>'comp_info'
,p_report_layout_type=>'RTF_FILE'
,p_varchar2_table=>wwv_flow_imp.g_varchar2_table
);
wwv_flow_imp.component_end;
end;
/
