prompt --application/shared_components/reports/report_layouts/balance_sheet
begin
--   Manifest
--     REPORT LAYOUT: Balance_sheet
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
    wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
    wwv_flow_imp.g_varchar2_table(1) := '{\rtf1\adeflang1025\ansi\ansicpg1252\uc1\adeff31507\deff0\stshfdbch31506\stshfloch31506\stshfhich315';
    wwv_flow_imp.g_varchar2_table(2) := '06\stshfbi31507\deflang1033\deflangfe1033\themelang1033\themelangfe0\themelangcs0{\fonttbl{\f0\fbidi';
    wwv_flow_imp.g_varchar2_table(3) := ' \froman\fcharset0\fprq2{\*\panose 00000000000000000000}Times New Roman;}{\f0\fbidi \froman\fcharset';
    wwv_flow_imp.g_varchar2_table(4) := '0\fprq2{\*\panose 00000000000000000000}Times New Roman;}'||wwv_flow.LF||
'{\f38\fbidi \fswiss\fcharset0\fprq2{\*\pan';
    wwv_flow_imp.g_varchar2_table(5) := 'ose 020f0302020204030204}Calibri Light;}{\f39\fbidi \fswiss\fcharset0\fprq2{\*\panose 020f0502020204';
    wwv_flow_imp.g_varchar2_table(6) := '030204}Calibri;}{\flomajor\f31500\fbidi \froman\fcharset0\fprq2{\*\panose 00000000000000000000}Times';
    wwv_flow_imp.g_varchar2_table(7) := ' New Roman;}'||wwv_flow.LF||
'{\fdbmajor\f31501\fbidi \froman\fcharset0\fprq2{\*\panose 00000000000000000000}Times N';
    wwv_flow_imp.g_varchar2_table(8) := 'ew Roman;}{\fhimajor\f31502\fbidi \fswiss\fcharset0\fprq2{\*\panose 020f0302020204030204}Calibri Lig';
    wwv_flow_imp.g_varchar2_table(9) := 'ht;}'||wwv_flow.LF||
'{\fbimajor\f31503\fbidi \froman\fcharset0\fprq2{\*\panose 00000000000000000000}Times New Roman';
    wwv_flow_imp.g_varchar2_table(10) := ';}{\flominor\f31504\fbidi \froman\fcharset0\fprq2{\*\panose 00000000000000000000}Times New Roman;}'||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(11) := '{\fdbminor\f31505\fbidi \froman\fcharset0\fprq2{\*\panose 00000000000000000000}Times New Roman;}{\fh';
    wwv_flow_imp.g_varchar2_table(12) := 'iminor\f31506\fbidi \fswiss\fcharset0\fprq2{\*\panose 020f0502020204030204}Calibri;}'||wwv_flow.LF||
'{\fbiminor\f31';
    wwv_flow_imp.g_varchar2_table(13) := '507\fbidi \froman\fcharset0\fprq2{\*\panose 00000000000000000000}Times New Roman;}{\f359\fbidi \from';
    wwv_flow_imp.g_varchar2_table(14) := 'an\fcharset238\fprq2 Times New Roman CE;}{\f360\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;';
    wwv_flow_imp.g_varchar2_table(15) := '}'||wwv_flow.LF||
'{\f362\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\f363\fbidi \froman\fcharset162\fp';
    wwv_flow_imp.g_varchar2_table(16) := 'rq2 Times New Roman Tur;}{\f364\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\f365\fbi';
    wwv_flow_imp.g_varchar2_table(17) := 'di \froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\f366\fbidi \froman\fcharset186\fprq2 Time';
    wwv_flow_imp.g_varchar2_table(18) := 's New Roman Baltic;}{\f367\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\f359\fbid';
    wwv_flow_imp.g_varchar2_table(19) := 'i \froman\fcharset238\fprq2 Times New Roman CE;}{\f360\fbidi \froman\fcharset204\fprq2 Times New Rom';
    wwv_flow_imp.g_varchar2_table(20) := 'an Cyr;}'||wwv_flow.LF||
'{\f362\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\f363\fbidi \froman\fcharse';
    wwv_flow_imp.g_varchar2_table(21) := 't162\fprq2 Times New Roman Tur;}{\f364\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\f';
    wwv_flow_imp.g_varchar2_table(22) := '365\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\f366\fbidi \froman\fcharset186\fpr';
    wwv_flow_imp.g_varchar2_table(23) := 'q2 Times New Roman Baltic;}{\f367\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\f7';
    wwv_flow_imp.g_varchar2_table(24) := '39\fbidi \fswiss\fcharset238\fprq2 Calibri Light CE;}{\f740\fbidi \fswiss\fcharset204\fprq2 Calibri ';
    wwv_flow_imp.g_varchar2_table(25) := 'Light Cyr;}'||wwv_flow.LF||
'{\f742\fbidi \fswiss\fcharset161\fprq2 Calibri Light Greek;}{\f743\fbidi \fswiss\fchars';
    wwv_flow_imp.g_varchar2_table(26) := 'et162\fprq2 Calibri Light Tur;}{\f744\fbidi \fswiss\fcharset177\fprq2 Calibri Light (Hebrew);}{\f745';
    wwv_flow_imp.g_varchar2_table(27) := '\fbidi \fswiss\fcharset178\fprq2 Calibri Light (Arabic);}'||wwv_flow.LF||
'{\f746\fbidi \fswiss\fcharset186\fprq2 Ca';
    wwv_flow_imp.g_varchar2_table(28) := 'libri Light Baltic;}{\f747\fbidi \fswiss\fcharset163\fprq2 Calibri Light (Vietnamese);}{\f749\fbidi ';
    wwv_flow_imp.g_varchar2_table(29) := '\fswiss\fcharset238\fprq2 Calibri CE;}{\f750\fbidi \fswiss\fcharset204\fprq2 Calibri Cyr;}'||wwv_flow.LF||
'{\f752\f';
    wwv_flow_imp.g_varchar2_table(30) := 'bidi \fswiss\fcharset161\fprq2 Calibri Greek;}{\f753\fbidi \fswiss\fcharset162\fprq2 Calibri Tur;}{\';
    wwv_flow_imp.g_varchar2_table(31) := 'f754\fbidi \fswiss\fcharset177\fprq2 Calibri (Hebrew);}{\f755\fbidi \fswiss\fcharset178\fprq2 Calibr';
    wwv_flow_imp.g_varchar2_table(32) := 'i (Arabic);}'||wwv_flow.LF||
'{\f756\fbidi \fswiss\fcharset186\fprq2 Calibri Baltic;}{\f757\fbidi \fswiss\fcharset16';
    wwv_flow_imp.g_varchar2_table(33) := '3\fprq2 Calibri (Vietnamese);}{\flomajor\f31508\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}';
    wwv_flow_imp.g_varchar2_table(34) := ''||wwv_flow.LF||
'{\flomajor\f31509\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\flomajor\f31511\fbidi \fr';
    wwv_flow_imp.g_varchar2_table(35) := 'oman\fcharset161\fprq2 Times New Roman Greek;}{\flomajor\f31512\fbidi \froman\fcharset162\fprq2 Time';
    wwv_flow_imp.g_varchar2_table(36) := 's New Roman Tur;}'||wwv_flow.LF||
'{\flomajor\f31513\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\flo';
    wwv_flow_imp.g_varchar2_table(37) := 'major\f31514\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\flomajor\f31515\fbidi \from';
    wwv_flow_imp.g_varchar2_table(38) := 'an\fcharset186\fprq2 Times New Roman Baltic;}'||wwv_flow.LF||
'{\flomajor\f31516\fbidi \froman\fcharset163\fprq2 Tim';
    wwv_flow_imp.g_varchar2_table(39) := 'es New Roman (Vietnamese);}{\fdbmajor\f31518\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\f';
    wwv_flow_imp.g_varchar2_table(40) := 'dbmajor\f31519\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\fdbmajor\f31521\fbidi \froma';
    wwv_flow_imp.g_varchar2_table(41) := 'n\fcharset161\fprq2 Times New Roman Greek;}{\fdbmajor\f31522\fbidi \froman\fcharset162\fprq2 Times N';
    wwv_flow_imp.g_varchar2_table(42) := 'ew Roman Tur;}{\fdbmajor\f31523\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}'||wwv_flow.LF||
'{\fdbmaj';
    wwv_flow_imp.g_varchar2_table(43) := 'or\f31524\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\fdbmajor\f31525\fbidi \froman\';
    wwv_flow_imp.g_varchar2_table(44) := 'fcharset186\fprq2 Times New Roman Baltic;}{\fdbmajor\f31526\fbidi \froman\fcharset163\fprq2 Times Ne';
    wwv_flow_imp.g_varchar2_table(45) := 'w Roman (Vietnamese);}'||wwv_flow.LF||
'{\fhimajor\f31528\fbidi \fswiss\fcharset238\fprq2 Calibri Light CE;}{\fhimaj';
    wwv_flow_imp.g_varchar2_table(46) := 'or\f31529\fbidi \fswiss\fcharset204\fprq2 Calibri Light Cyr;}{\fhimajor\f31531\fbidi \fswiss\fcharse';
    wwv_flow_imp.g_varchar2_table(47) := 't161\fprq2 Calibri Light Greek;}'||wwv_flow.LF||
'{\fhimajor\f31532\fbidi \fswiss\fcharset162\fprq2 Calibri Light Tu';
    wwv_flow_imp.g_varchar2_table(48) := 'r;}{\fhimajor\f31533\fbidi \fswiss\fcharset177\fprq2 Calibri Light (Hebrew);}{\fhimajor\f31534\fbidi';
    wwv_flow_imp.g_varchar2_table(49) := ' \fswiss\fcharset178\fprq2 Calibri Light (Arabic);}'||wwv_flow.LF||
'{\fhimajor\f31535\fbidi \fswiss\fcharset186\fpr';
    wwv_flow_imp.g_varchar2_table(50) := 'q2 Calibri Light Baltic;}{\fhimajor\f31536\fbidi \fswiss\fcharset163\fprq2 Calibri Light (Vietnamese';
    wwv_flow_imp.g_varchar2_table(51) := ');}{\fbimajor\f31538\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}'||wwv_flow.LF||
'{\fbimajor\f31539\fbidi \';
    wwv_flow_imp.g_varchar2_table(52) := 'froman\fcharset204\fprq2 Times New Roman Cyr;}{\fbimajor\f31541\fbidi \froman\fcharset161\fprq2 Time';
    wwv_flow_imp.g_varchar2_table(53) := 's New Roman Greek;}{\fbimajor\f31542\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}'||wwv_flow.LF||
'{\fbimaj';
    wwv_flow_imp.g_varchar2_table(54) := 'or\f31543\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\fbimajor\f31544\fbidi \froman\';
    wwv_flow_imp.g_varchar2_table(55) := 'fcharset178\fprq2 Times New Roman (Arabic);}{\fbimajor\f31545\fbidi \froman\fcharset186\fprq2 Times ';
    wwv_flow_imp.g_varchar2_table(56) := 'New Roman Baltic;}'||wwv_flow.LF||
'{\fbimajor\f31546\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}';
    wwv_flow_imp.g_varchar2_table(57) := '{\flominor\f31548\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\flominor\f31549\fbidi \froma';
    wwv_flow_imp.g_varchar2_table(58) := 'n\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\flominor\f31551\fbidi \froman\fcharset161\fprq2 Times N';
    wwv_flow_imp.g_varchar2_table(59) := 'ew Roman Greek;}{\flominor\f31552\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\flominor\f3';
    wwv_flow_imp.g_varchar2_table(60) := '1553\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}'||wwv_flow.LF||
'{\flominor\f31554\fbidi \froman\fch';
    wwv_flow_imp.g_varchar2_table(61) := 'arset178\fprq2 Times New Roman (Arabic);}{\flominor\f31555\fbidi \froman\fcharset186\fprq2 Times New';
    wwv_flow_imp.g_varchar2_table(62) := ' Roman Baltic;}{\flominor\f31556\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}'||wwv_flow.LF||
'{\f';
    wwv_flow_imp.g_varchar2_table(63) := 'dbminor\f31558\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\fdbminor\f31559\fbidi \froman\f';
    wwv_flow_imp.g_varchar2_table(64) := 'charset204\fprq2 Times New Roman Cyr;}{\fdbminor\f31561\fbidi \froman\fcharset161\fprq2 Times New Ro';
    wwv_flow_imp.g_varchar2_table(65) := 'man Greek;}'||wwv_flow.LF||
'{\fdbminor\f31562\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\fdbminor\f3156';
    wwv_flow_imp.g_varchar2_table(66) := '3\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\fdbminor\f31564\fbidi \froman\fcharset';
    wwv_flow_imp.g_varchar2_table(67) := '178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\fdbminor\f31565\fbidi \froman\fcharset186\fprq2 Times New Ro';
    wwv_flow_imp.g_varchar2_table(68) := 'man Baltic;}{\fdbminor\f31566\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\fhimin';
    wwv_flow_imp.g_varchar2_table(69) := 'or\f31568\fbidi \fswiss\fcharset238\fprq2 Calibri CE;}'||wwv_flow.LF||
'{\fhiminor\f31569\fbidi \fswiss\fcharset204\';
    wwv_flow_imp.g_varchar2_table(70) := 'fprq2 Calibri Cyr;}{\fhiminor\f31571\fbidi \fswiss\fcharset161\fprq2 Calibri Greek;}{\fhiminor\f3157';
    wwv_flow_imp.g_varchar2_table(71) := '2\fbidi \fswiss\fcharset162\fprq2 Calibri Tur;}'||wwv_flow.LF||
'{\fhiminor\f31573\fbidi \fswiss\fcharset177\fprq2 C';
    wwv_flow_imp.g_varchar2_table(72) := 'alibri (Hebrew);}{\fhiminor\f31574\fbidi \fswiss\fcharset178\fprq2 Calibri (Arabic);}{\fhiminor\f315';
    wwv_flow_imp.g_varchar2_table(73) := '75\fbidi \fswiss\fcharset186\fprq2 Calibri Baltic;}'||wwv_flow.LF||
'{\fhiminor\f31576\fbidi \fswiss\fcharset163\fpr';
    wwv_flow_imp.g_varchar2_table(74) := 'q2 Calibri (Vietnamese);}{\fbiminor\f31578\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\fbi';
    wwv_flow_imp.g_varchar2_table(75) := 'minor\f31579\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\fbiminor\f31581\fbidi \froman\';
    wwv_flow_imp.g_varchar2_table(76) := 'fcharset161\fprq2 Times New Roman Greek;}{\fbiminor\f31582\fbidi \froman\fcharset162\fprq2 Times New';
    wwv_flow_imp.g_varchar2_table(77) := ' Roman Tur;}{\fbiminor\f31583\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}'||wwv_flow.LF||
'{\fbiminor';
    wwv_flow_imp.g_varchar2_table(78) := '\f31584\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\fbiminor\f31585\fbidi \froman\fc';
    wwv_flow_imp.g_varchar2_table(79) := 'harset186\fprq2 Times New Roman Baltic;}{\fbiminor\f31586\fbidi \froman\fcharset163\fprq2 Times New ';
    wwv_flow_imp.g_varchar2_table(80) := 'Roman (Vietnamese);}}'||wwv_flow.LF||
'{\colortbl;\red0\green0\blue0;\red0\green0\blue255;\red0\green255\blue255;\re';
    wwv_flow_imp.g_varchar2_table(81) := 'd0\green255\blue0;\red255\green0\blue255;\red255\green0\blue0;\red255\green255\blue0;\red255\green25';
    wwv_flow_imp.g_varchar2_table(82) := '5\blue255;\red0\green0\blue128;\red0\green128\blue128;\red0\green128\blue0;'||wwv_flow.LF||
'\red128\green0\blue128;';
    wwv_flow_imp.g_varchar2_table(83) := '\red128\green0\blue0;\red128\green128\blue0;\red128\green128\blue128;\red192\green192\blue192;\cacce';
    wwv_flow_imp.g_varchar2_table(84) := 'ntone\ctint255\cshade191\red47\green84\blue150;\cbackgroundone\ctint255\cshade242\red242\green242\bl';
    wwv_flow_imp.g_varchar2_table(85) := 'ue242;'||wwv_flow.LF||
'\cbackgroundone\ctint255\cshade255\red255\green255\blue255;\ctextone\ctint128\cshade255\red1';
    wwv_flow_imp.g_varchar2_table(86) := '27\green127\blue127;\red255\green255\blue255;\cbackgroundone\ctint255\cshade191\red191\green191\blue';
    wwv_flow_imp.g_varchar2_table(87) := '191;}{\*\defchp \f31506\fs22 }{\*\defpap '||wwv_flow.LF||
'\ql \li0\ri0\sa160\sl259\slmult1\widctlpar\wrapdefault\as';
    wwv_flow_imp.g_varchar2_table(88) := 'palpha\aspnum\faauto\adjustright\rin0\lin0\itap0 }\noqfpromote {\stylesheet{\ql \li0\ri0\sa160\sl259';
    wwv_flow_imp.g_varchar2_table(89) := '\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 '||wwv_flow.LF||
'\af3';
    wwv_flow_imp.g_varchar2_table(90) := '1507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \sne';
    wwv_flow_imp.g_varchar2_table(91) := 'xt0 \sqformat \spriority0 Normal;}{\s2\ql \li0\ri0\sb40\sl259\slmult1'||wwv_flow.LF||
'\keep\keepn\widctlpar\wrapdef';
    wwv_flow_imp.g_varchar2_table(92) := 'ault\aspalpha\aspnum\faauto\outlinelevel1\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af31503\afs26\ala';
    wwv_flow_imp.g_varchar2_table(93) := 'ng1025 \ltrch\fcs0 \fs26\cf17\lang1033\langfe1033\loch\f31502\hich\af31502\dbch\af31501\cgrid\langnp';
    wwv_flow_imp.g_varchar2_table(94) := '1033\langfenp1033 '||wwv_flow.LF||
'\sbasedon0 \snext0 \slink17 \sunhideused \sqformat \spriority9 \styrsid13067081 ';
    wwv_flow_imp.g_varchar2_table(95) := 'heading 2;}{\*\cs10 \additive \ssemihidden \sunhideused \spriority1 Default Paragraph Font;}{\*'||wwv_flow.LF||
'\ts';
    wwv_flow_imp.g_varchar2_table(96) := '11\tsrowd\trftsWidthB3\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblind0\tblindt';
    wwv_flow_imp.g_varchar2_table(97) := 'ype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\tsbrdrv \ql \li0\ri0\sa16';
    wwv_flow_imp.g_varchar2_table(98) := '0\sl259\slmult1'||wwv_flow.LF||
'\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fc';
    wwv_flow_imp.g_varchar2_table(99) := 's1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp10';
    wwv_flow_imp.g_varchar2_table(100) := '33 \snext11 \ssemihidden \sunhideused Normal Table;}{\*\ts15\tsrowd'||wwv_flow.LF||
'\trbrdrt\brdrs\brdrw10 \trbrdrl';
    wwv_flow_imp.g_varchar2_table(101) := '\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\b';
    wwv_flow_imp.g_varchar2_table(102) := 'rdrw10 '||wwv_flow.LF||
'\trftsWidthB3\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblind0\tblindt';
    wwv_flow_imp.g_varchar2_table(103) := 'ype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\tsbrdrv '||wwv_flow.LF||
'\ql \li0\ri0\wi';
    wwv_flow_imp.g_varchar2_table(104) := 'dctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af31507\afs22\al';
    wwv_flow_imp.g_varchar2_table(105) := 'ang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \sbasedon11 \snex';
    wwv_flow_imp.g_varchar2_table(106) := 't15 \spriority39 \styrsid13067081 '||wwv_flow.LF||
'Table Grid;}{\*\ts16\tsrowd\trftsWidthB3\trpaddl108\trpaddr108\t';
    wwv_flow_imp.g_varchar2_table(107) := 'rpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tscbandsh1\tscbandsv1\tblind0\tblindtype3\tsvertalt\tsbrdrt\t';
    wwv_flow_imp.g_varchar2_table(108) := 'sbrdrl\tsbrdrb\tsbrdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\tsbrdrv '||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\wrapdefault\aspa';
    wwv_flow_imp.g_varchar2_table(109) := 'lpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31';
    wwv_flow_imp.g_varchar2_table(110) := '506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \sbasedon11 \snext16 \spriority44 \styrsi';
    wwv_flow_imp.g_varchar2_table(111) := 'd13067081 '||wwv_flow.LF||
'Plain Table 4;}{\*\ts16\tsrowd \rtlch\fcs1 \ab\af31507 \ltrch\fcs0 \b \tscfirstrow Plain';
    wwv_flow_imp.g_varchar2_table(112) := ' Table 4;}{\*\ts16\tsrowd \rtlch\fcs1 \ab\af31507 \ltrch\fcs0 \b \tsclastrow Plain Table 4;}{\*\ts16';
    wwv_flow_imp.g_varchar2_table(113) := '\tsrowd \rtlch\fcs1 \ab\af31507 \ltrch\fcs0 \b \tscfirstcol '||wwv_flow.LF||
'Plain Table 4;}{\*\ts16\tsrowd \rtlch\';
    wwv_flow_imp.g_varchar2_table(114) := 'fcs1 \ab\af31507 \ltrch\fcs0 \b \tsclastcol Plain Table 4;}{\*\ts16\tsrowd\tscellcfpat0\tscellcbpat1';
    wwv_flow_imp.g_varchar2_table(115) := '8\tscellpct0 \rtlch\fcs1 \af31507 \ltrch\fcs0 \tscbandvertodd Plain Table 4;}{\*'||wwv_flow.LF||
'\ts16\tsrowd\tscel';
    wwv_flow_imp.g_varchar2_table(116) := 'lcfpat0\tscellcbpat18\tscellpct0 \rtlch\fcs1 \af31507 \ltrch\fcs0 \tscbandhorzodd Plain Table 4;}{\*';
    wwv_flow_imp.g_varchar2_table(117) := '\cs17 \additive \rtlch\fcs1 \af31503\afs26 \ltrch\fcs0 \fs26\cf17\loch\f31502\hich\af31502\dbch\af31';
    wwv_flow_imp.g_varchar2_table(118) := '501 '||wwv_flow.LF||
'\sbasedon10 \slink2 \slocked \spriority9 \styrsid13067081 Heading 2 Char;}{\*'||wwv_flow.LF||
'\ts18\tsrowd\tr';
    wwv_flow_imp.g_varchar2_table(119) := 'ftsWidthB3\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tscbandsh1\tscbandsv1\tblin';
    wwv_flow_imp.g_varchar2_table(120) := 'd0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\tsbrdrv '||wwv_flow.LF||
'\ql \';
    wwv_flow_imp.g_varchar2_table(121) := 'li0\ri0\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af3150';
    wwv_flow_imp.g_varchar2_table(122) := '7\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \sbased';
    wwv_flow_imp.g_varchar2_table(123) := 'on11 \snext18 \spriority45 \styrsid13067081 '||wwv_flow.LF||
'Plain Table 5;}{\*\ts18\tsrowd\tscellcfpat0\tscellcbpa';
    wwv_flow_imp.g_varchar2_table(124) := 't19\tscellpct0\tsbrdrb\brdrs\brdrw10\brdrcf20 \rtlch\fcs1 \ai\af31503 \ltrch\fcs0 \i\fs26\loch\f3150';
    wwv_flow_imp.g_varchar2_table(125) := '2\hich\af31502\dbch\af31501 \tscfirstrow Plain Table 5;}{\*'||wwv_flow.LF||
'\ts18\tsrowd\tscellcfpat0\tscellcbpat19';
    wwv_flow_imp.g_varchar2_table(126) := '\tscellpct0\tsbrdrt\brdrs\brdrw10\brdrcf20 \rtlch\fcs1 \ai\af31503 \ltrch\fcs0 \i\fs26\loch\f31502\h';
    wwv_flow_imp.g_varchar2_table(127) := 'ich\af31502\dbch\af31501 \tsclastrow Plain Table 5;}{\*\ts18\tsrowd\tscellcfpat0\tscellcbpat19\tscel';
    wwv_flow_imp.g_varchar2_table(128) := 'lpct0\tsbrdrr'||wwv_flow.LF||
'\brdrs\brdrw10\brdrcf20 \qr \rtlch\fcs1 \ai\af31503 \ltrch\fcs0 \i\fs26\loch\f31502\h';
    wwv_flow_imp.g_varchar2_table(129) := 'ich\af31502\dbch\af31501 \tscfirstcol Plain Table 5;}{\*\ts18\tsrowd\tscellcfpat0\tscellcbpat19\tsce';
    wwv_flow_imp.g_varchar2_table(130) := 'llpct0\tsbrdrl\brdrs\brdrw10\brdrcf20 \rtlch\fcs1 \ai\af31503 '||wwv_flow.LF||
'\ltrch\fcs0 \i\fs26\loch\f31502\hich';
    wwv_flow_imp.g_varchar2_table(131) := '\af31502\dbch\af31501 \tsclastcol Plain Table 5;}{\*\ts18\tsrowd\tscellcfpat0\tscellcbpat18\tscellpc';
    wwv_flow_imp.g_varchar2_table(132) := 't0 \rtlch\fcs1 \af31507 \ltrch\fcs0 \tscbandvertodd Plain Table 5;}{\*'||wwv_flow.LF||
'\ts18\tsrowd\tscellcfpat0\ts';
    wwv_flow_imp.g_varchar2_table(133) := 'cellcbpat18\tscellpct0 \rtlch\fcs1 \af31507 \ltrch\fcs0 \tscbandhorzodd Plain Table 5;}{\*\ts18\tsro';
    wwv_flow_imp.g_varchar2_table(134) := 'wd\tsbrdrl\brdrnone \rtlch\fcs1 \af31507 \ltrch\fcs0 \tscnecell Plain Table 5;}{\*\ts18\tsrowd\tsbrd';
    wwv_flow_imp.g_varchar2_table(135) := 'rr\brdrnone \rtlch\fcs1 '||wwv_flow.LF||
'\af31507 \ltrch\fcs0 \tscnwcell Plain Table 5;}{\*\ts18\tsrowd\tsbrdrl\brd';
    wwv_flow_imp.g_varchar2_table(136) := 'rnone \rtlch\fcs1 \af31507 \ltrch\fcs0 \tscsecell Plain Table 5;}{\*\ts18\tsrowd\tsbrdrr\brdrnone \r';
    wwv_flow_imp.g_varchar2_table(137) := 'tlch\fcs1 \af31507 \ltrch\fcs0 \tscswcell Plain Table 5;}{\*\ts19\tsrowd\trbrdrt'||wwv_flow.LF||
'\brdrs\brdrw10\brd';
    wwv_flow_imp.g_varchar2_table(138) := 'rcf22 \trbrdrl\brdrs\brdrw10\brdrcf22 \trbrdrb\brdrs\brdrw10\brdrcf22 \trbrdrr\brdrs\brdrw10\brdrcf2';
    wwv_flow_imp.g_varchar2_table(139) := '2 \trbrdrh\brdrs\brdrw10\brdrcf22 \trbrdrv\brdrs\brdrw10\brdrcf22 '||wwv_flow.LF||
'\trftsWidthB3\trpaddl108\trpaddr';
    wwv_flow_imp.g_varchar2_table(140) := '108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\ts';
    wwv_flow_imp.g_varchar2_table(141) := 'brdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\tsbrdrv '||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\wrapdefault\aspalpha\aspnum\faaut';
    wwv_flow_imp.g_varchar2_table(142) := 'o\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033';
    wwv_flow_imp.g_varchar2_table(143) := '\langfe1033\cgrid\langnp1033\langfenp1033 \sbasedon11 \snext19 \spriority40 \styrsid11891781 '||wwv_flow.LF||
'Grid ';
    wwv_flow_imp.g_varchar2_table(144) := 'Table Light;}}{\*\rsidtbl \rsid157986\rsid9326372\rsid10640845\rsid11891781\rsid13067081\rsid1613286';
    wwv_flow_imp.g_varchar2_table(145) := '0}{\mmathPr\mmathFont34\mbrkBin0\mbrkBinSub0\msmallFrac0\mdispDef1\mlMargin0\mrMargin0\mdefJc1\mwrap';
    wwv_flow_imp.g_varchar2_table(146) := 'Indent1440\mintLim0\mnaryLim1}{\info'||wwv_flow.LF||
'{\author Bappy}{\operator Bappy}{\creatim\yr2022\mo7\dy9\hr19\';
    wwv_flow_imp.g_varchar2_table(147) := 'min10}{\revtim\yr2022\mo7\dy9\hr19\min34}{\version5}{\edmins24}{\nofpages1}{\nofwords92}{\nofchars53';
    wwv_flow_imp.g_varchar2_table(148) := '1}{\nofcharsws622}{\vern87}}{\*\xmlnstbl {\xmlns1 http://schemas.microsoft.com/office/word/20'||wwv_flow.LF||
'03/wo';
    wwv_flow_imp.g_varchar2_table(149) := 'rdml}}\paperw12240\paperh15840\margl1440\margr1440\margt1440\margb1440\gutter0\ltrsect '||wwv_flow.LF||
'\widowctrl\';
    wwv_flow_imp.g_varchar2_table(150) := 'ftnbj\aenddoc\trackmoves0\trackformatting1\donotembedsysfont1\relyonvml1\donotembedlingdata0\grfdoce';
    wwv_flow_imp.g_varchar2_table(151) := 'vents0\validatexml1\showplaceholdtext0\ignoremixedcontent0\saveinvalidxml0\showxmlerrors1\noxlattoye';
    wwv_flow_imp.g_varchar2_table(152) := 'n'||wwv_flow.LF||
'\expshrtn\noultrlspc\dntblnsbdb\nospaceforul\formshade\horzdoc\dgmargin\dghspace180\dgvspace180\d';
    wwv_flow_imp.g_varchar2_table(153) := 'ghorigin1440\dgvorigin1440\dghshow1\dgvshow1'||wwv_flow.LF||
'\jexpand\viewkind1\viewscale100\pgbrdrhead\pgbrdrfoot\';
    wwv_flow_imp.g_varchar2_table(154) := 'splytwnine\ftnlytwnine\htmautsp\nolnhtadjtbl\useltbaln\alntblind\lytcalctblwd\lyttblrtgr\lnbrkrule\n';
    wwv_flow_imp.g_varchar2_table(155) := 'obrkwrptbl\snaptogridincell\allowfieldendsel\wrppunct'||wwv_flow.LF||
'\asianbrkrule\rsidroot13067081\newtblstyruls\';
    wwv_flow_imp.g_varchar2_table(156) := 'nogrowautofit\usenormstyforlist\noindnmbrts\felnbrelev\nocxsptable\indrlsweleven\noafcnsttbl\afelev\';
    wwv_flow_imp.g_varchar2_table(157) := 'utinl\hwelev\spltpgpar\notcvasp\notbrkcnstfrctbl\notvatxbx\krnprsnet\cachedcolbal \nouicompat \fet0';
    wwv_flow_imp.g_varchar2_table(158) := ''||wwv_flow.LF||
'{\*\wgrffmtfilter 2450}\nofeaturethrottle1\ilfomacatclnup0{\*\docvar {xdo0001}{PD9mb3ItZWFjaDpST1dT';
    wwv_flow_imp.g_varchar2_table(159) := 'RVQyPz4=}}{\*\docvar {xdo0002}{PD9QQVJUSUNVTEFSU19BU1NFVD8+}}{\*\docvar {xdo0003}{PD9BTU9VTlQ/Pg==}}';
    wwv_flow_imp.g_varchar2_table(160) := '{\*\docvar {xdo0004}{PD9lbmQgZm9yLWVhY2g/Pg==}}'||wwv_flow.LF||
'{\*\docvar {xdo0005}{PD9UT1RBTF9BTU9VTlRfQVNTRVQ/Pg';
    wwv_flow_imp.g_varchar2_table(161) := '==}}{\*\docvar {xdo0006}{PD9mb3ItZWFjaDpST1dTRVQ0Pz4=}}{\*\docvar {xdo0007}{PD9QQVJUSUNVTEFSUz8+}}{\';
    wwv_flow_imp.g_varchar2_table(162) := '*\docvar {xdo0008}{PD9BTU9VTlRfTElBQklMSVRJRVM/Pg==}}{\*\docvar {xdo0009}{PD9lbmQgZm9yLWVhY2g/Pg==}}';
    wwv_flow_imp.g_varchar2_table(163) := ''||wwv_flow.LF||
'{\*\docvar {xdo0010}{PD9UT1RBTF9BTU9VTlRfTElBQklMSVRJRVM/Pg==}}{\*\docvar {xdo0011}{PD9mb3ItZWFjaD';
    wwv_flow_imp.g_varchar2_table(164) := 'pST1dTRVQ2Pz4=}}{\*\docvar {xdo0012}{PD9QQVJUSUNVTEFSU19PV05FUl9FUVVJVFk/Pg==}}{\*\docvar {xdo0013}{';
    wwv_flow_imp.g_varchar2_table(165) := 'PD9BTU9VTlQ/Pg==}}'||wwv_flow.LF||
'{\*\docvar {xdo0014}{PD9lbmQgZm9yLWVhY2g/Pg==}}{\*\docvar {xdo0015}{PD9UT1RBTF9B';
    wwv_flow_imp.g_varchar2_table(166) := 'TU9VTlRfRVFVSVRZPz4=}}{\*\docvar {xdo0016}{PD9UT1RBTF9BTU9VTlRfQVNTRVQ/Pg==}}{\*\docvar {xdo0017}{PD';
    wwv_flow_imp.g_varchar2_table(167) := '9UT1RBTF9CT1RIX0xRPz4=}}{\*\docvar {xdo0018}{PD9DT01QQU5ZX05BTUU/Pg==}}'||wwv_flow.LF||
'{\*\docvar {xdo0019}{PD9BRE';
    wwv_flow_imp.g_varchar2_table(168) := 'RSRVNTPz4=}}{\*\docvar {xdo0020}{PD9QSE9ORT8+}}{\*\docvar {xdo0021}{PD9GQVg/Pg==}}{\*\docvar {xdo002';
    wwv_flow_imp.g_varchar2_table(169) := '2}{PD9FTUFJTD8+}}{\*\docvar {xdo0023}{PD9mb3ItZWFjaDpST1dTRVQyX1JPVz8+}}{\*\docvar {xdo0024}{PD9QQVJ';
    wwv_flow_imp.g_varchar2_table(170) := 'USUNVTEFSU19BU1NFVD8+}}'||wwv_flow.LF||
'{\*\docvar {xdo0025}{PD9BTU9VTlQ/Pg==}}{\*\docvar {xdo0026}{PD9lbmQgZm9yLWV';
    wwv_flow_imp.g_varchar2_table(171) := 'hY2g/Pg==}}{\*\docvar {xdo0027}{PD9mb3ItZWFjaDpST1dTRVQ0X1JPVz8+}}{\*\docvar {xdo0028}{PD9QQVJUSUNVT';
    wwv_flow_imp.g_varchar2_table(172) := 'EFSUz8+}}{\*\docvar {xdo0029}{PD9BTU9VTlRfTElBQklMSVRJRVM/Pg==}}'||wwv_flow.LF||
'{\*\docvar {xdo0030}{PD9lbmQgZm9yL';
    wwv_flow_imp.g_varchar2_table(173) := 'WVhY2g/Pg==}}{\*\docvar {xdo0031}{PD9mb3ItZWFjaDpST1dTRVQ2X1JPVz8+}}{\*\docvar {xdo0032}{PD9QQVJUSUN';
    wwv_flow_imp.g_varchar2_table(174) := 'VTEFSU19PV05FUl9FUVVJVFk/Pg==}}{\*\docvar {xdo0033}{PD9BTU9VTlQ/Pg==}}{\*\docvar {xdo0034}{PD9lbmQgZ';
    wwv_flow_imp.g_varchar2_table(175) := 'm9yLWVhY2g/Pg==}}'||wwv_flow.LF||
'{\*\docvar {xdo0035}{PD9UT1RBTF9BTU9VTlRfTElBQklMSVRJRVM/Pg==}}{\*\docvar {xdo003';
    wwv_flow_imp.g_varchar2_table(176) := '6}{PD9UT1RBTF9BTU9VTlRfRVFVSVRZPz4=}}\ltrpar \sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdef';
    wwv_flow_imp.g_varchar2_table(177) := 'aultcl\sectrsid16132860\sftnbj {\*\pnseclvl1'||wwv_flow.LF||
'\pnucrm\pnstart1\pnindent720\pnhang {\pntxta .}}{\*\pn';
    wwv_flow_imp.g_varchar2_table(178) := 'seclvl2\pnucltr\pnstart1\pnindent720\pnhang {\pntxta .}}{\*\pnseclvl3\pndec\pnstart1\pnindent720\pnh';
    wwv_flow_imp.g_varchar2_table(179) := 'ang {\pntxta .}}{\*\pnseclvl4\pnlcltr\pnstart1\pnindent720\pnhang {\pntxta )}}{\*\pnseclvl5'||wwv_flow.LF||
'\pndec\';
    wwv_flow_imp.g_varchar2_table(180) := 'pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnseclvl6\pnlcltr\pnstart1\pnindent720\pnhang';
    wwv_flow_imp.g_varchar2_table(181) := ' {\pntxtb (}{\pntxta )}}{\*\pnseclvl7\pnlcrm\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\';
    wwv_flow_imp.g_varchar2_table(182) := 'pnseclvl8\pnlcltr\pnstart1\pnindent720\pnhang '||wwv_flow.LF||
'{\pntxtb (}{\pntxta )}}{\*\pnseclvl9\pnlcrm\pnstart1';
    wwv_flow_imp.g_varchar2_table(183) := '\pnindent720\pnhang {\pntxtb (}{\pntxta )}}\ltrrow\trowd \irow0\irowband-1\ltrrow'||wwv_flow.LF||
'\ts16\trgaph108\t';
    wwv_flow_imp.g_varchar2_table(184) := 'rrh252\trleft-108\trftsWidth1\trftsWidthB3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpa';
    wwv_flow_imp.g_varchar2_table(185) := 'ddfb3\trpaddfr3\tscbandsh1\tscbandsv1\tblrsid13067081\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblin';
    wwv_flow_imp.g_varchar2_table(186) := 'd0\tblindtype3 \clvertalc\clbrdrt'||wwv_flow.LF||
'\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltx';
    wwv_flow_imp.g_varchar2_table(187) := 'lrtb\clftsWidth3\clwWidth12574\clshdrawnil \cellx9468\pard\plain \ltrpar'||wwv_flow.LF||
'\s2\qc \li0\ri0\sb40\keep\';
    wwv_flow_imp.g_varchar2_table(188) := 'keepn\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\outlinelevel1\adjustright\rin0\lin0\pararsi';
    wwv_flow_imp.g_varchar2_table(189) := 'd13067081\tscfirstrow\tscfirstcol\yts16 \rtlch\fcs1 \ab\af31503\afs26\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\b\fs2';
    wwv_flow_imp.g_varchar2_table(190) := '6\cf17\lang1033\langfe1033\loch\af31502\hich\af31502\dbch\af31501\cgrid\langnp1033\langfenp1033 {\fi';
    wwv_flow_imp.g_varchar2_table(191) := 'eld\flddirty{\*\fldinst {\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid13067081\charrsid13067081 {\*\bkmk';
    wwv_flow_imp.g_varchar2_table(192) := 'start Text18}'||wwv_flow.LF||
'\hich\af31502\dbch\af31501\loch\f31502  \hich\af31502\dbch\af31501\loch\f31502 FORMTE';
    wwv_flow_imp.g_varchar2_table(193) := 'XT\hich\af31502\dbch\af31501\loch\f31502  }{\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid13067081\charrs';
    wwv_flow_imp.g_varchar2_table(194) := 'id13067081 {\*\datafield '||wwv_flow.LF||
'800100000000000006546578743138000c434f4d50414e595f4e414d4500000000000f3c3';
    wwv_flow_imp.g_varchar2_table(195) := 'f7265663a78646f303031383f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffnam';
    wwv_flow_imp.g_varchar2_table(196) := 'e Text18}{\*\ffdeftext COMPANY_NAME}{\*\ffstattext <?ref:xdo0018?>}}}}}{\fldrslt {'||wwv_flow.LF||
'\rtlch\fcs1 \af3';
    wwv_flow_imp.g_varchar2_table(197) := '1503 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid13067081\charrsid13067081 \hich\af31502\dbch\af';
    wwv_flow_imp.g_varchar2_table(198) := '31501\loch\f31502 COMPANY_NAME}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectr';
    wwv_flow_imp.g_varchar2_table(199) := 'sid16132860\sftnbj {\rtlch\fcs1 '||wwv_flow.LF||
'\af31503 \ltrch\fcs0 \insrsid13067081 {\*\bkmkend Text18}\cell }\p';
    wwv_flow_imp.g_varchar2_table(200) := 'ard\plain \ltrpar\ql \li0\ri0\sa160\sl259\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto';
    wwv_flow_imp.g_varchar2_table(201) := '\adjustright\rin0\lin0 \rtlch\fcs1 \af31503\afs26\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\fs26\cf17\lang1033\langfe';
    wwv_flow_imp.g_varchar2_table(202) := '1033\loch\af31502\hich\af31502\dbch\af31501\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31503 \ltr';
    wwv_flow_imp.g_varchar2_table(203) := 'ch\fcs0 \insrsid13067081 \trowd \irow0\irowband-1\ltrrow'||wwv_flow.LF||
'\ts16\trgaph108\trrh252\trleft-108\trftsWi';
    wwv_flow_imp.g_varchar2_table(204) := 'dth1\trftsWidthB3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tscbandsh';
    wwv_flow_imp.g_varchar2_table(205) := '1\tscbandsv1\tblrsid13067081\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalc';
    wwv_flow_imp.g_varchar2_table(206) := '\clbrdrt'||wwv_flow.LF||
'\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth';
    wwv_flow_imp.g_varchar2_table(207) := '12574\clshdrawnil \cellx9468\row \ltrrow}\trowd \irow1\irowband0\ltrrow'||wwv_flow.LF||
'\ts16\trgaph108\trrh252\trl';
    wwv_flow_imp.g_varchar2_table(208) := 'eft-108\trftsWidth1\trftsWidthB3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpa';
    wwv_flow_imp.g_varchar2_table(209) := 'ddfr3\tscbandsh1\tscbandsv1\tblrsid13067081\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindt';
    wwv_flow_imp.g_varchar2_table(210) := 'ype3 \clvertalc\clbrdrt'||wwv_flow.LF||
'\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \clcbpat18\cltx';
    wwv_flow_imp.g_varchar2_table(211) := 'lrtb\clftsWidth3\clwWidth12574\clcbpatraw18 \cellx9468\pard\plain \ltrpar'||wwv_flow.LF||
'\s2\qc \li0\ri0\sb40\keep';
    wwv_flow_imp.g_varchar2_table(212) := '\keepn\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\outlinelevel1\adjustright\rin0\lin0\parars';
    wwv_flow_imp.g_varchar2_table(213) := 'id13067081\tscfirstcol\tscbandhorzodd\yts16 \rtlch\fcs1 \ab\af31503\afs26\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\b';
    wwv_flow_imp.g_varchar2_table(214) := '\fs26\cf17\lang1033\langfe1033\loch\af31502\hich\af31502\dbch\af31501\cgrid\langnp1033\langfenp1033 ';
    wwv_flow_imp.g_varchar2_table(215) := '{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid13067081\charrsid13067081 {\*\';
    wwv_flow_imp.g_varchar2_table(216) := 'bkmkstart Text19}'||wwv_flow.LF||
'\hich\af31502\dbch\af31501\loch\f31502  \hich\af31502\dbch\af31501\loch\f31502 FO';
    wwv_flow_imp.g_varchar2_table(217) := 'RMTEXT\hich\af31502\dbch\af31501\loch\f31502  }{\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid13067081\ch';
    wwv_flow_imp.g_varchar2_table(218) := 'arrsid13067081 {\*\datafield '||wwv_flow.LF||
'80010000000000000654657874313900074144445245535300000000000f3c3f72656';
    wwv_flow_imp.g_varchar2_table(219) := '63a78646f303031393f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text';
    wwv_flow_imp.g_varchar2_table(220) := '19}{\*\ffdeftext ADDRESS}{\*\ffstattext <?ref:xdo0019?>}}}}}{\fldrslt {\rtlch\fcs1 '||wwv_flow.LF||
'\af31503 \ltrch';
    wwv_flow_imp.g_varchar2_table(221) := '\fcs0 \lang1024\langfe1024\noproof\insrsid13067081\charrsid13067081 \hich\af31502\dbch\af31501\loch\';
    wwv_flow_imp.g_varchar2_table(222) := 'f31502 ADDRESS}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid16132860\sftn';
    wwv_flow_imp.g_varchar2_table(223) := 'bj {\rtlch\fcs1 \af31503 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid13067081 {\*\bkmkend Text19}\hich\af31502\dbch\af3150';
    wwv_flow_imp.g_varchar2_table(224) := '1\loch\f31502 , }{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid13067081\char';
    wwv_flow_imp.g_varchar2_table(225) := 'rsid13067081 {\*\bkmkstart Text20}\hich\af31502\dbch\af31501\loch\f31502  '||wwv_flow.LF||
'\hich\af31502\dbch\af315';
    wwv_flow_imp.g_varchar2_table(226) := '01\loch\f31502 FORMTEXT\hich\af31502\dbch\af31501\loch\f31502  }{\rtlch\fcs1 \af31503 \ltrch\fcs0 \i';
    wwv_flow_imp.g_varchar2_table(227) := 'nsrsid13067081\charrsid13067081 {\*\datafield '||wwv_flow.LF||
'800100000000000006546578743230000550484f4e4500000000';
    wwv_flow_imp.g_varchar2_table(228) := '000f3c3f7265663a78646f303032303f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\';
    wwv_flow_imp.g_varchar2_table(229) := '*\ffname Text20}{\*\ffdeftext PHONE}{\*\ffstattext <?ref:xdo0020?>}}}}}{\fldrslt {\rtlch\fcs1 \af315';
    wwv_flow_imp.g_varchar2_table(230) := '03 '||wwv_flow.LF||
'\ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid13067081\charrsid13067081 \hich\af31502\dbch\af';
    wwv_flow_imp.g_varchar2_table(231) := '31501\loch\f31502 PHONE}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid1613';
    wwv_flow_imp.g_varchar2_table(232) := '2860\sftnbj {\rtlch\fcs1 \af31503 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid13067081 {\*\bkmkend Text20}\cell }\pard\pla';
    wwv_flow_imp.g_varchar2_table(233) := 'in \ltrpar\ql \li0\ri0\sa160\sl259\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjust';
    wwv_flow_imp.g_varchar2_table(234) := 'right\rin0\lin0 \rtlch\fcs1 \af31503\afs26\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\fs26\cf17\lang1033\langfe1033\lo';
    wwv_flow_imp.g_varchar2_table(235) := 'ch\af31502\hich\af31502\dbch\af31501\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31503 \ltrch\fcs0';
    wwv_flow_imp.g_varchar2_table(236) := ' \insrsid13067081 \trowd \irow1\irowband0\ltrrow'||wwv_flow.LF||
'\ts16\trgaph108\trrh252\trleft-108\trftsWidth1\trf';
    wwv_flow_imp.g_varchar2_table(237) := 'tsWidthB3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tscbandsh1\tscban';
    wwv_flow_imp.g_varchar2_table(238) := 'dsv1\tblrsid13067081\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalc\clbrdrt';
    wwv_flow_imp.g_varchar2_table(239) := ''||wwv_flow.LF||
'\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \clcbpat18\cltxlrtb\clftsWidth3\clwWid';
    wwv_flow_imp.g_varchar2_table(240) := 'th12574\clcbpatraw18 \cellx9468\row \ltrrow}\trowd \irow2\irowband1\lastrow \ltrrow'||wwv_flow.LF||
'\ts16\trgaph108';
    wwv_flow_imp.g_varchar2_table(241) := '\trrh252\trleft-108\trftsWidth1\trftsWidthB3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\tr';
    wwv_flow_imp.g_varchar2_table(242) := 'paddfb3\trpaddfr3\tscbandsh1\tscbandsv1\tblrsid13067081\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tbl';
    wwv_flow_imp.g_varchar2_table(243) := 'ind0\tblindtype3 \clvertalc\clbrdrt'||wwv_flow.LF||
'\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cl';
    wwv_flow_imp.g_varchar2_table(244) := 'txlrtb\clftsWidth3\clwWidth12574\clshdrawnil \cellx9468\pard\plain \ltrpar'||wwv_flow.LF||
'\s2\qc \li0\ri0\sb40\kee';
    wwv_flow_imp.g_varchar2_table(245) := 'p\keepn\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\outlinelevel1\adjustright\rin0\lin0\parar';
    wwv_flow_imp.g_varchar2_table(246) := 'sid13067081\tscfirstcol\yts16 \rtlch\fcs1 \ab\af31503\afs26\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\b\fs26\cf17\lan';
    wwv_flow_imp.g_varchar2_table(247) := 'g1033\langfe1033\loch\af31502\hich\af31502\dbch\af31501\cgrid\langnp1033\langfenp1033 {\field\flddir';
    wwv_flow_imp.g_varchar2_table(248) := 'ty{\*\fldinst {\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid13067081\charrsid13067081 {\*\bkmkstart Text';
    wwv_flow_imp.g_varchar2_table(249) := '21}'||wwv_flow.LF||
'\hich\af31502\dbch\af31501\loch\f31502  \hich\af31502\dbch\af31501\loch\f31502 FORMTEXT\hich\af';
    wwv_flow_imp.g_varchar2_table(250) := '31502\dbch\af31501\loch\f31502  }{\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid13067081\charrsid13067081';
    wwv_flow_imp.g_varchar2_table(251) := ' {\*\datafield '||wwv_flow.LF||
'800100000000000006546578743231000346415800000000000f3c3f7265663a78646f303032313f3e0';
    wwv_flow_imp.g_varchar2_table(252) := '000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text21}{\*\ffdeftext FAX}{';
    wwv_flow_imp.g_varchar2_table(253) := '\*\ffstattext <?ref:xdo0021?>}}}}}{\fldrslt {\rtlch\fcs1 \af31503 '||wwv_flow.LF||
'\ltrch\fcs0 \lang1024\langfe1024';
    wwv_flow_imp.g_varchar2_table(254) := '\noproof\insrsid13067081\charrsid13067081 \hich\af31502\dbch\af31501\loch\f31502 FAX}}}\sectd \ltrse';
    wwv_flow_imp.g_varchar2_table(255) := 'ct\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid16132860\sftnbj {\rtlch\fcs1 \af31503 \ltrc';
    wwv_flow_imp.g_varchar2_table(256) := 'h\fcs0 '||wwv_flow.LF||
'\insrsid13067081 {\*\bkmkend Text21}\hich\af31502\dbch\af31501\loch\f31502 , }{\field\flddi';
    wwv_flow_imp.g_varchar2_table(257) := 'rty{\*\fldinst {\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid13067081\charrsid13067081 {\*\bkmkstart Tex';
    wwv_flow_imp.g_varchar2_table(258) := 't22}\hich\af31502\dbch\af31501\loch\f31502  '||wwv_flow.LF||
'\hich\af31502\dbch\af31501\loch\f31502 FORMTEXT\hich\a';
    wwv_flow_imp.g_varchar2_table(259) := 'f31502\dbch\af31501\loch\f31502  }{\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid13067081\charrsid1306708';
    wwv_flow_imp.g_varchar2_table(260) := '1 {\*\datafield '||wwv_flow.LF||
'8001000000000000065465787432320005454d41494c00000000000f3c3f7265663a78646f30303232';
    wwv_flow_imp.g_varchar2_table(261) := '3f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text22}{\*\ffdeftext ';
    wwv_flow_imp.g_varchar2_table(262) := 'EMAIL}{\*\ffstattext <?ref:xdo0022?>}}}}}{\fldrslt {\rtlch\fcs1 \af31503 '||wwv_flow.LF||
'\ltrch\fcs0 \lang1024\lan';
    wwv_flow_imp.g_varchar2_table(263) := 'gfe1024\noproof\insrsid13067081\charrsid13067081 \hich\af31502\dbch\af31501\loch\f31502 EMAIL}}}\sec';
    wwv_flow_imp.g_varchar2_table(264) := 'td \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid16132860\sftnbj {\rtlch\fcs1 \af31';
    wwv_flow_imp.g_varchar2_table(265) := '503 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid13067081 {\*\bkmkend Text22}\cell }\pard\plain \ltrpar\ql \li0\ri0\sa160\s';
    wwv_flow_imp.g_varchar2_table(266) := 'l259\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \a';
    wwv_flow_imp.g_varchar2_table(267) := 'f31503\afs26\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\fs26\cf17\lang1033\langfe1033\loch\af31502\hich\af31502\dbch\a';
    wwv_flow_imp.g_varchar2_table(268) := 'f31501\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid13067081 \trowd \irow';
    wwv_flow_imp.g_varchar2_table(269) := '2\irowband1\lastrow \ltrrow'||wwv_flow.LF||
'\ts16\trgaph108\trrh252\trleft-108\trftsWidth1\trftsWidthB3\trautofit1\';
    wwv_flow_imp.g_varchar2_table(270) := 'trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tscbandsh1\tscbandsv1\tblrsid13067081\';
    wwv_flow_imp.g_varchar2_table(271) := 'tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalc\clbrdrt'||wwv_flow.LF||
'\brdrtbl \clbrdrl\b';
    wwv_flow_imp.g_varchar2_table(272) := 'rdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth12574\clshdrawnil \cellx9468\';
    wwv_flow_imp.g_varchar2_table(273) := 'row }\pard \ltrpar\ql \li0\ri0\sa160\sl259\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adju';
    wwv_flow_imp.g_varchar2_table(274) := 'stright\rin0\lin0\itap0 {'||wwv_flow.LF||
'\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid9326372 '||wwv_flow.LF||
'\par }{\rtlch\fcs1 \af';
    wwv_flow_imp.g_varchar2_table(275) := '31507 \ltrch\fcs0 \insrsid13067081 '||wwv_flow.LF||
'\par }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid11891781 '||wwv_flow.LF||
'\par';
    wwv_flow_imp.g_varchar2_table(276) := ' \ltrrow}\trowd \irow0\irowband-1\ltrrow'||wwv_flow.LF||
'\ts18\trgaph108\trrh309\trleft-108\trftsWidth1\trftsWidthB';
    wwv_flow_imp.g_varchar2_table(277) := '3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tscbandsh1\t';
    wwv_flow_imp.g_varchar2_table(278) := 'scbandsv1\tblrsid16132860\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt'||wwv_flow.LF||
'\';
    wwv_flow_imp.g_varchar2_table(279) := 'clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrs\brdrw10\brdrcf20 \clbrdrr\brdrnone \clcbpat19\cltxlr';
    wwv_flow_imp.g_varchar2_table(280) := 'tb\clftsWidth3\clwWidth4608\clcbpatraw19 \cellx4500\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbr';
    wwv_flow_imp.g_varchar2_table(281) := 'drb\brdrs\brdrw10\brdrcf20 \clbrdrr\brdrtbl '||wwv_flow.LF||
'\clcbpat19\cltxlrtb\clftsWidth3\clwWidth4050\clcbpatra';
    wwv_flow_imp.g_varchar2_table(282) := 'w19 \cellx8550\pard\plain \ltrpar'||wwv_flow.LF||
'\s2\qr \li0\ri0\sb40\keep\keepn\widctlpar\intbl\wrapdefault\aspal';
    wwv_flow_imp.g_varchar2_table(283) := 'pha\aspnum\faauto\outlinelevel1\adjustright\rin0\lin0\pararsid157986\tscfirstrow\tscfirstcol\tscnwce';
    wwv_flow_imp.g_varchar2_table(284) := 'll\yts18 \rtlch\fcs1 \ai\af31503\afs26\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\i\fs26\cf17\lang1033\langfe1033\loch';
    wwv_flow_imp.g_varchar2_table(285) := '\af31502\hich\af31502\dbch\af31501\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31503 \ltrch\fcs0 \';
    wwv_flow_imp.g_varchar2_table(286) := 'insrsid10640845 \hich\af31502\dbch\af31501\loch\f31502 Asset}{\rtlch\fcs1 \af31503 \ltrch\fcs0 '||wwv_flow.LF||
'\in';
    wwv_flow_imp.g_varchar2_table(287) := 'srsid11891781\charrsid11891781 \cell }\pard\plain \ltrpar\qr \li0\ri0\widctlpar\intbl\wrapdefault\as';
    wwv_flow_imp.g_varchar2_table(288) := 'palpha\aspnum\faauto\adjustright\rin0\lin0\pararsid11891781\tscfirstrow\yts18 \rtlch\fcs1 \ai\af3150';
    wwv_flow_imp.g_varchar2_table(289) := '3\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\i\fs26\lang1033\langfe1033\loch\af31502\hich\af31502\dbch\af31501\c';
    wwv_flow_imp.g_varchar2_table(290) := 'grid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid11891781\charrsid11891781 \ce';
    wwv_flow_imp.g_varchar2_table(291) := 'll }\pard\plain \ltrpar\ql \li0\ri0\sa160\sl259\slmult1'||wwv_flow.LF||
'\widctlpar\intbl\wrapdefault\aspalpha\aspnu';
    wwv_flow_imp.g_varchar2_table(292) := 'm\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang103';
    wwv_flow_imp.g_varchar2_table(293) := '3\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid11891781 '||wwv_flow.LF||
'\tro';
    wwv_flow_imp.g_varchar2_table(294) := 'wd \irow0\irowband-1\ltrrow\ts18\trgaph108\trrh309\trleft-108\trftsWidth1\trftsWidthB3\trftsWidthA3\';
    wwv_flow_imp.g_varchar2_table(295) := 'trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tscbandsh1\tscbandsv1\tblrs';
    wwv_flow_imp.g_varchar2_table(296) := 'id16132860\tbllkhdrrows\tbllkhdrcols\tbllknocolband'||wwv_flow.LF||
'\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrtbl';
    wwv_flow_imp.g_varchar2_table(297) := ' \clbrdrl\brdrtbl \clbrdrb\brdrs\brdrw10\brdrcf20 \clbrdrr\brdrnone \clcbpat19\cltxlrtb\clftsWidth3\';
    wwv_flow_imp.g_varchar2_table(298) := 'clwWidth4608\clcbpatraw19 \cellx4500\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb'||wwv_flow.LF||
'\brdrs\brd';
    wwv_flow_imp.g_varchar2_table(299) := 'rw10\brdrcf20 \clbrdrr\brdrtbl \clcbpat19\cltxlrtb\clftsWidth3\clwWidth4050\clcbpatraw19 \cellx8550\';
    wwv_flow_imp.g_varchar2_table(300) := 'row \ltrrow}\trowd \irow1\irowband0\lastrow \ltrrow'||wwv_flow.LF||
'\ts18\trgaph108\trrh309\trleft-108\trftsWidth1\';
    wwv_flow_imp.g_varchar2_table(301) := 'trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\t';
    wwv_flow_imp.g_varchar2_table(302) := 'scbandsh1\tscbandsv1\tblrsid16132860\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \c';
    wwv_flow_imp.g_varchar2_table(303) := 'lvertalt'||wwv_flow.LF||
'\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrs\brdrw10\brdrcf20 \clcbpa';
    wwv_flow_imp.g_varchar2_table(304) := 't19\cltxlrtb\clftsWidth3\clwWidth4608\clcbpatraw19 \cellx4500\clvertalt\clbrdrt\brdrtbl \clbrdrl\brd';
    wwv_flow_imp.g_varchar2_table(305) := 'rtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl '||wwv_flow.LF||
'\clcbpat18\cltxlrtb\clftsWidth3\clwWidth4050\clcbpatraw18 \';
    wwv_flow_imp.g_varchar2_table(306) := 'cellx8550\pard\plain \ltrpar\qr \li0\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustri';
    wwv_flow_imp.g_varchar2_table(307) := 'ght\rin0\lin0\pararsid11891781\tscfirstcol\tscbandhorzodd\yts18 \rtlch\fcs1 '||wwv_flow.LF||
'\ai\af31503\afs22\alan';
    wwv_flow_imp.g_varchar2_table(308) := 'g1025 \ltrch\fcs0 \i\fs26\lang1033\langfe1033\loch\af31502\hich\af31502\dbch\af31501\cgrid\langnp103';
    wwv_flow_imp.g_varchar2_table(309) := '3\langfenp1033 {\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31503 \ltrch\fcs0 \cf9\insrsid11891781\ch';
    wwv_flow_imp.g_varchar2_table(310) := 'arrsid11891781 '||wwv_flow.LF||
'{\*\bkmkstart Text23}\hich\af31502\dbch\af31501\loch\f31502  \hich\af31502\dbch\af3';
    wwv_flow_imp.g_varchar2_table(311) := '1501\loch\f31502 FORMTEXT\hich\af31502\dbch\af31501\loch\f31502  }{\rtlch\fcs1 \af31503 \ltrch\fcs0 ';
    wwv_flow_imp.g_varchar2_table(312) := '\cf9\insrsid11891781\charrsid11891781 {\*\datafield '||wwv_flow.LF||
'8001000000000000065465787432330002462000000000';
    wwv_flow_imp.g_varchar2_table(313) := '000f3c3f7265663a78646f303032333f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\';
    wwv_flow_imp.g_varchar2_table(314) := '*\ffname Text23}{\*\ffdeftext F }{\*\ffstattext <?ref:xdo0023?>}}}}}{\fldrslt {\rtlch\fcs1 \af31503 ';
    wwv_flow_imp.g_varchar2_table(315) := ''||wwv_flow.LF||
'\ltrch\fcs0 \cf9\lang1024\langfe1024\noproof\insrsid11891781\charrsid11891781 \hich\af31502\dbch\a';
    wwv_flow_imp.g_varchar2_table(316) := 'f31501\loch\f31502 F }}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid161328';
    wwv_flow_imp.g_varchar2_table(317) := '60\sftnbj {\*\bkmkend Text23}{\field\flddirty{\*\fldinst '||wwv_flow.LF||
'{\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsi';
    wwv_flow_imp.g_varchar2_table(318) := 'd11891781\charrsid11891781 {\*\bkmkstart Text24}\hich\af31502\dbch\af31501\loch\f31502  \hich\af3150';
    wwv_flow_imp.g_varchar2_table(319) := '2\dbch\af31501\loch\f31502 FORMTEXT\hich\af31502\dbch\af31501\loch\f31502  }{\rtlch\fcs1 \af31503 \l';
    wwv_flow_imp.g_varchar2_table(320) := 'trch\fcs0 '||wwv_flow.LF||
'\insrsid11891781\charrsid11891781 {\*\datafield 8001000000000000065465787432340011504152';
    wwv_flow_imp.g_varchar2_table(321) := '544943554c4152535f415353455400000000000f3c3f7265663a78646f303032343f3e0000000000}{\*\formfield{\ffty';
    wwv_flow_imp.g_varchar2_table(322) := 'pe0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text24}{\*\ffdeftext '||wwv_flow.LF||
'PARTICULARS_ASSET}{\*\ffstattext';
    wwv_flow_imp.g_varchar2_table(323) := ' <?ref:xdo0024?>}}}}}{\fldrslt {\rtlch\fcs1 \af31503 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsi';
    wwv_flow_imp.g_varchar2_table(324) := 'd11891781\charrsid11891781 \hich\af31502\dbch\af31501\loch\f31502 PARTICULARS_ASSET}}}\sectd \ltrsec';
    wwv_flow_imp.g_varchar2_table(325) := 't'||wwv_flow.LF||
'\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid16132860\sftnbj {\rtlch\fcs1 \af31503 \ltr';
    wwv_flow_imp.g_varchar2_table(326) := 'ch\fcs0 \insrsid11891781 {\*\bkmkend Text24}\cell }\pard\plain \ltrpar'||wwv_flow.LF||
'\qr \li0\ri0\widctlpar\intbl';
    wwv_flow_imp.g_varchar2_table(327) := '\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid11891781\tscbandhorzodd\yts18 \rtl';
    wwv_flow_imp.g_varchar2_table(328) := 'ch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langf';
    wwv_flow_imp.g_varchar2_table(329) := 'enp1033 '||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid11891781\charrsid118';
    wwv_flow_imp.g_varchar2_table(330) := '91781 {\*\bkmkstart Text25} FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid11891781\charrsid118';
    wwv_flow_imp.g_varchar2_table(331) := '91781 {\*\datafield '||wwv_flow.LF||
'8001000000000000065465787432350006414d4f554e5400000000000f3c3f7265663a78646f30';
    wwv_flow_imp.g_varchar2_table(332) := '3032353f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text25}{\*\ffde';
    wwv_flow_imp.g_varchar2_table(333) := 'ftext AMOUNT}{\*\ffstattext <?ref:xdo0025?>}}}}}{\fldrslt {\rtlch\fcs1 '||wwv_flow.LF||
'\af31507 \ltrch\fcs0 \lang1';
    wwv_flow_imp.g_varchar2_table(334) := '024\langfe1024\noproof\insrsid11891781\charrsid11891781 AMOUNT}}}\sectd \ltrsect\linex0\endnhere\sec';
    wwv_flow_imp.g_varchar2_table(335) := 'tlinegrid360\sectdefaultcl\sectrsid16132860\sftnbj {\*\bkmkend Text25}{\field\flddirty{\*\fldinst {\';
    wwv_flow_imp.g_varchar2_table(336) := 'rtlch\fcs1 \af31507 '||wwv_flow.LF||
'\ltrch\fcs0 \cf9\insrsid11891781\charrsid11891781 {\*\bkmkstart Text26} FORMTE';
    wwv_flow_imp.g_varchar2_table(337) := 'XT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\insrsid11891781\charrsid11891781 {\*\datafield '||wwv_flow.LF||
'80010000';
    wwv_flow_imp.g_varchar2_table(338) := '00000000065465787432360002204500000000000f3c3f7265663a78646f303032363f3e0000000000}{\*\formfield{\ff';
    wwv_flow_imp.g_varchar2_table(339) := 'type0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text26}{\*\ffdeftext  E}{\*\ffstattext <?ref:xdo0026?';
    wwv_flow_imp.g_varchar2_table(340) := '>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 '||wwv_flow.LF||
'\ltrch\fcs0 \cf9\lang1024\langfe1024\noproof\insrsid11891781';
    wwv_flow_imp.g_varchar2_table(341) := '\charrsid11891781  E}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid1613286';
    wwv_flow_imp.g_varchar2_table(342) := '0\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid11891781 {\*\bkmkend Text26}\cell '||wwv_flow.LF||
'}\pard\plain ';
    wwv_flow_imp.g_varchar2_table(343) := '\ltrpar\ql \li0\ri0\sa160\sl259\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustrig';
    wwv_flow_imp.g_varchar2_table(344) := 'ht\rin0\lin0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid';
    wwv_flow_imp.g_varchar2_table(345) := '\langnp1033\langfenp1033 {\rtlch\fcs1 '||wwv_flow.LF||
'\af31507 \ltrch\fcs0 \insrsid11891781 \trowd \irow1\irowband';
    wwv_flow_imp.g_varchar2_table(346) := '0\lastrow \ltrrow'||wwv_flow.LF||
'\ts18\trgaph108\trrh309\trleft-108\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofi';
    wwv_flow_imp.g_varchar2_table(347) := 't1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tscbandsh1\tscbandsv1\tblrsid161328';
    wwv_flow_imp.g_varchar2_table(348) := '60\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt'||wwv_flow.LF||
'\clbrdrt\brdrtbl \clbrdr';
    wwv_flow_imp.g_varchar2_table(349) := 'l\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrs\brdrw10\brdrcf20 \clcbpat19\cltxlrtb\clftsWidth3\clwWidth4';
    wwv_flow_imp.g_varchar2_table(350) := '608\clcbpatraw19 \cellx4500\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brd';
    wwv_flow_imp.g_varchar2_table(351) := 'rtbl '||wwv_flow.LF||
'\clcbpat18\cltxlrtb\clftsWidth3\clwWidth4050\clcbpatraw18 \cellx8550\row }\pard \ltrpar\ql \l';
    wwv_flow_imp.g_varchar2_table(352) := 'i0\ri0\sa160\sl259\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 ';
    wwv_flow_imp.g_varchar2_table(353) := '{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13067081 '||wwv_flow.LF||
'\par }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsi';
    wwv_flow_imp.g_varchar2_table(354) := 'd11891781 '||wwv_flow.LF||
'\par \ltrrow}\trowd \irow0\irowband-1\ltrrow\ts18\trgaph108\trrh252\trleft-108\tpvpara\t';
    wwv_flow_imp.g_varchar2_table(355) := 'phmrg\tposyout\tdfrmtxtLeft180\tdfrmtxtRight180\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trp';
    wwv_flow_imp.g_varchar2_table(356) := 'addl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3'||wwv_flow.LF||
'\tscbandsh1\tscbandsv1\tblrsid16132860\t';
    wwv_flow_imp.g_varchar2_table(357) := 'bllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrtbl \clbrdrl\brdr';
    wwv_flow_imp.g_varchar2_table(358) := 'tbl \clbrdrb\brdrs\brdrw10\brdrcf20 \clbrdrr\brdrnone \clcbpat19\cltxlrtb\clftsWidth3\clwWidth4608\c';
    wwv_flow_imp.g_varchar2_table(359) := 'lcbpatraw19 '||wwv_flow.LF||
'\cellx4500\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrs\brdrw10\brdrcf20 ';
    wwv_flow_imp.g_varchar2_table(360) := '\clbrdrr\brdrtbl \clcbpat19\cltxlrtb\clftsWidth3\clwWidth4050\clcbpatraw19 \cellx8550\pard\plain \lt';
    wwv_flow_imp.g_varchar2_table(361) := 'rpar'||wwv_flow.LF||
'\s2\qr \li0\ri0\sb40\keep\keepn\widctlpar\intbl\pvpara\phmrg\posyout\dxfrtext180\dfrmtxtx180\d';
    wwv_flow_imp.g_varchar2_table(362) := 'frmtxty0\wraparound\aspalpha\aspnum\faauto\outlinelevel1\adjustright\rin0\lin0\pararsid16132860\tscf';
    wwv_flow_imp.g_varchar2_table(363) := 'irstrow\tscfirstcol\tscnwcell\yts18 \rtlch\fcs1 '||wwv_flow.LF||
'\ai\af31503\afs26\alang1025 \ltrch\fcs0 \i\fs26\cf';
    wwv_flow_imp.g_varchar2_table(364) := '17\lang1033\langfe1033\loch\af31502\hich\af31502\dbch\af31501\cgrid\langnp1033\langfenp1033 {\rtlch\';
    wwv_flow_imp.g_varchar2_table(365) := 'fcs1 \af31503 \ltrch\fcs0 \insrsid16132860 \hich\af31502\dbch\af31501\loch\f31502 Liabilities}{'||wwv_flow.LF||
'\rt';
    wwv_flow_imp.g_varchar2_table(366) := 'lch\fcs1 \af31503 \ltrch\fcs0 \insrsid16132860\charrsid11891781 \cell }\pard\plain \ltrpar'||wwv_flow.LF||
'\qr \li0';
    wwv_flow_imp.g_varchar2_table(367) := '\ri0\widctlpar\intbl\pvpara\phmrg\posyout\dxfrtext180\dfrmtxtx180\dfrmtxty0\wraparound\aspalpha\aspn';
    wwv_flow_imp.g_varchar2_table(368) := 'um\faauto\adjustright\rin0\lin0\pararsid16132860\tscfirstrow\yts18 \rtlch\fcs1 \ai\af31503\afs22\ala';
    wwv_flow_imp.g_varchar2_table(369) := 'ng1025 \ltrch\fcs0 '||wwv_flow.LF||
'\i\fs26\lang1033\langfe1033\loch\af31502\hich\af31502\dbch\af31501\cgrid\langnp';
    wwv_flow_imp.g_varchar2_table(370) := '1033\langfenp1033 {\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid16132860\charrsid11891781 \cell }\pard\p';
    wwv_flow_imp.g_varchar2_table(371) := 'lain \ltrpar\ql \li0\ri0\sa160\sl259\slmult1'||wwv_flow.LF||
'\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\ad';
    wwv_flow_imp.g_varchar2_table(372) := 'justright\rin0\lin0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe103';
    wwv_flow_imp.g_varchar2_table(373) := '3\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid16132860 '||wwv_flow.LF||
'\trowd \irow0\i';
    wwv_flow_imp.g_varchar2_table(374) := 'rowband-1\ltrrow\ts18\trgaph108\trrh252\trleft-108\tpvpara\tphmrg\tposyout\tdfrmtxtLeft180\tdfrmtxtR';
    wwv_flow_imp.g_varchar2_table(375) := 'ight180\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\t';
    wwv_flow_imp.g_varchar2_table(376) := 'rpaddfb3\trpaddfr3'||wwv_flow.LF||
'\tscbandsh1\tscbandsv1\tblrsid16132860\tbllkhdrrows\tbllkhdrcols\tbllknocolband\';
    wwv_flow_imp.g_varchar2_table(377) := 'tblind0\tblindtype3 \clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrs\brdrw10\brdrcf20 \clb';
    wwv_flow_imp.g_varchar2_table(378) := 'rdrr\brdrnone \clcbpat19\cltxlrtb\clftsWidth3\clwWidth4608\clcbpatraw19 '||wwv_flow.LF||
'\cellx4500\clvertalt\clbrd';
    wwv_flow_imp.g_varchar2_table(379) := 'rt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrs\brdrw10\brdrcf20 \clbrdrr\brdrtbl \clcbpat19\cltxlrtb\clf';
    wwv_flow_imp.g_varchar2_table(380) := 'tsWidth3\clwWidth4050\clcbpatraw19 \cellx8550\row \ltrrow}\trowd \irow1\irowband0\ltrrow'||wwv_flow.LF||
'\ts18\trga';
    wwv_flow_imp.g_varchar2_table(381) := 'ph108\trrh252\trleft-108\tpvpara\tphmrg\tposyout\tdfrmtxtLeft180\tdfrmtxtRight180\trftsWidth1\trftsW';
    wwv_flow_imp.g_varchar2_table(382) := 'idthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3'||wwv_flow.LF||
'\tscba';
    wwv_flow_imp.g_varchar2_table(383) := 'ndsh1\tscbandsv1\tblrsid16132860\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clver';
    wwv_flow_imp.g_varchar2_table(384) := 'talt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrs\brdrw10\brdrcf20 \clcbpat19\cl';
    wwv_flow_imp.g_varchar2_table(385) := 'txlrtb\clftsWidth3\clwWidth4608\clcbpatraw19 '||wwv_flow.LF||
'\cellx4500\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl';
    wwv_flow_imp.g_varchar2_table(386) := ' \clbrdrb\brdrtbl \clbrdrr\brdrtbl \clcbpat18\cltxlrtb\clftsWidth3\clwWidth4050\clcbpatraw18 \cellx8';
    wwv_flow_imp.g_varchar2_table(387) := '550\pard\plain \ltrpar'||wwv_flow.LF||
'\qr \li0\ri0\widctlpar\intbl\pvpara\phmrg\posyout\dxfrtext180\dfrmtxtx180\df';
    wwv_flow_imp.g_varchar2_table(388) := 'rmtxty0\wraparound\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid16132860\tscfirstcol\tscband';
    wwv_flow_imp.g_varchar2_table(389) := 'horzodd\yts18 \rtlch\fcs1 \ai\af31503\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\i\fs26\lang1033\langfe1033\loch';
    wwv_flow_imp.g_varchar2_table(390) := '\af31502\hich\af31502\dbch\af31501\cgrid\langnp1033\langfenp1033 {\field\flddirty{\*\fldinst {\rtlch';
    wwv_flow_imp.g_varchar2_table(391) := '\fcs1 \af31503 \ltrch\fcs0 \cf9\insrsid16132860\charrsid11891781 {\*\bkmkstart Text27}'||wwv_flow.LF||
'\hich\af3150';
    wwv_flow_imp.g_varchar2_table(392) := '2\dbch\af31501\loch\f31502  \hich\af31502\dbch\af31501\loch\f31502 FORMTEXT\hich\af31502\dbch\af3150';
    wwv_flow_imp.g_varchar2_table(393) := '1\loch\f31502  }{\rtlch\fcs1 \af31503 \ltrch\fcs0 \cf9\insrsid16132860\charrsid11891781 {\*\datafiel';
    wwv_flow_imp.g_varchar2_table(394) := 'd '||wwv_flow.LF||
'8001000000000000065465787432370002462000000000000f3c3f7265663a78646f303032373f3e0000000000}{\*\f';
    wwv_flow_imp.g_varchar2_table(395) := 'ormfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text27}{\*\ffdeftext F }{\*\ffstattext <?';
    wwv_flow_imp.g_varchar2_table(396) := 'ref:xdo0027?>}}}}}{\fldrslt {\rtlch\fcs1 \af31503 '||wwv_flow.LF||
'\ltrch\fcs0 \cf9\lang1024\langfe1024\noproof\ins';
    wwv_flow_imp.g_varchar2_table(397) := 'rsid16132860\charrsid11891781 \hich\af31502\dbch\af31501\loch\f31502 F }}}\sectd \ltrsect\linex0\end';
    wwv_flow_imp.g_varchar2_table(398) := 'nhere\sectlinegrid360\sectdefaultcl\sectrsid16132860\sftnbj {\*\bkmkend Text27}{\field\flddirty{\*\f';
    wwv_flow_imp.g_varchar2_table(399) := 'ldinst '||wwv_flow.LF||
'{\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid16132860\charrsid11891781 {\*\bkmkstart Text28}\h';
    wwv_flow_imp.g_varchar2_table(400) := 'ich\af31502\dbch\af31501\loch\f31502  \hich\af31502\dbch\af31501\loch\f31502 FORMTEXT\hich\af31502\d';
    wwv_flow_imp.g_varchar2_table(401) := 'bch\af31501\loch\f31502  }{\rtlch\fcs1 \af31503 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid16132860\charrsid11891781 {\*\';
    wwv_flow_imp.g_varchar2_table(402) := 'datafield 800100000000000006546578743238000b504152544943554c41525300000000000f3c3f7265663a78646f3030';
    wwv_flow_imp.g_varchar2_table(403) := '32383f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text28}{\*\ffdeft';
    wwv_flow_imp.g_varchar2_table(404) := 'ext PARTICULARS}'||wwv_flow.LF||
'{\*\ffstattext <?ref:xdo0028?>}}}}}{\fldrslt {\rtlch\fcs1 \af31503 \ltrch\fcs0 \la';
    wwv_flow_imp.g_varchar2_table(405) := 'ng1024\langfe1024\noproof\insrsid16132860\charrsid11891781 \hich\af31502\dbch\af31501\loch\f31502 PA';
    wwv_flow_imp.g_varchar2_table(406) := 'RTICULARS}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid16132860\sftnbj ';
    wwv_flow_imp.g_varchar2_table(407) := '{\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid16132860 {\*\bkmkend Text28}\cell }\pard\plain \ltrpar'||wwv_flow.LF||
'\q';
    wwv_flow_imp.g_varchar2_table(408) := 'r \li0\ri0\widctlpar\intbl\pvpara\phmrg\posyout\dxfrtext180\dfrmtxtx180\dfrmtxty0\wraparound\aspalph';
    wwv_flow_imp.g_varchar2_table(409) := 'a\aspnum\faauto\adjustright\rin0\lin0\pararsid16132860\tscbandhorzodd\yts18 \rtlch\fcs1 \af31507\afs';
    wwv_flow_imp.g_varchar2_table(410) := '22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\field\fl';
    wwv_flow_imp.g_varchar2_table(411) := 'ddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid16132860\charrsid11891781 {\*\bkmkstart ';
    wwv_flow_imp.g_varchar2_table(412) := 'Text29} FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid16132860\charrsid11891781 {\*\datafiel';
    wwv_flow_imp.g_varchar2_table(413) := 'd 8001000000000000065465787432390012414d4f554e545f4c494142494c495449455300000000000f3c3f7265663a7864';
    wwv_flow_imp.g_varchar2_table(414) := '6f303032393f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text29}'||wwv_flow.LF||
'{\';
    wwv_flow_imp.g_varchar2_table(415) := '*\ffdeftext AMOUNT_LIABILITIES}{\*\ffstattext <?ref:xdo0029?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 \l';
    wwv_flow_imp.g_varchar2_table(416) := 'trch\fcs0 \lang1024\langfe1024\noproof\insrsid16132860\charrsid11891781 AMOUNT_LIABILITIES}}}\sectd ';
    wwv_flow_imp.g_varchar2_table(417) := '\ltrsect'||wwv_flow.LF||
'\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid16132860\sftnbj {\*\bkmkend Text29}';
    wwv_flow_imp.g_varchar2_table(418) := '{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\insrsid16132860\charrsid11891781 ';
    wwv_flow_imp.g_varchar2_table(419) := '{\*\bkmkstart Text30} FORMTEXT }{\rtlch\fcs1 \af31507 '||wwv_flow.LF||
'\ltrch\fcs0 \cf9\insrsid16132860\charrsid118';
    wwv_flow_imp.g_varchar2_table(420) := '91781 {\*\datafield 8001000000000000065465787433300002204500000000000f3c3f7265663a78646f303033303f3e';
    wwv_flow_imp.g_varchar2_table(421) := '0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text30}{\*\ffdeftext  E}';
    wwv_flow_imp.g_varchar2_table(422) := ''||wwv_flow.LF||
'{\*\ffstattext <?ref:xdo0030?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\lang1024\langfe';
    wwv_flow_imp.g_varchar2_table(423) := '1024\noproof\insrsid16132860\charrsid11891781  E}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\s';
    wwv_flow_imp.g_varchar2_table(424) := 'ectdefaultcl\sectrsid16132860\sftnbj {\rtlch\fcs1 '||wwv_flow.LF||
'\af31507 \ltrch\fcs0 \insrsid16132860 {\*\bkmken';
    wwv_flow_imp.g_varchar2_table(425) := 'd Text30}\cell }\pard\plain \ltrpar\ql \li0\ri0\sa160\sl259\slmult1\widctlpar\intbl\wrapdefault\aspa';
    wwv_flow_imp.g_varchar2_table(426) := 'lpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\';
    wwv_flow_imp.g_varchar2_table(427) := 'fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid161';
    wwv_flow_imp.g_varchar2_table(428) := '32860 \trowd \irow1\irowband0\ltrrow'||wwv_flow.LF||
'\ts18\trgaph108\trrh252\trleft-108\tpvpara\tphmrg\tposyout\tdf';
    wwv_flow_imp.g_varchar2_table(429) := 'rmtxtLeft180\tdfrmtxtRight180\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108';
    wwv_flow_imp.g_varchar2_table(430) := '\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3'||wwv_flow.LF||
'\tscbandsh1\tscbandsv1\tblrsid16132860\tbllkhdrrows\tbllkh';
    wwv_flow_imp.g_varchar2_table(431) := 'drcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrt';
    wwv_flow_imp.g_varchar2_table(432) := 'bl \clbrdrr\brdrs\brdrw10\brdrcf20 \clcbpat19\cltxlrtb\clftsWidth3\clwWidth4608\clcbpatraw19 '||wwv_flow.LF||
'\cell';
    wwv_flow_imp.g_varchar2_table(433) := 'x4500\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \clcbpat18\cltxlr';
    wwv_flow_imp.g_varchar2_table(434) := 'tb\clftsWidth3\clwWidth4050\clcbpatraw18 \cellx8550\row \ltrrow}\trowd \irow2\irowband1\lastrow \ltr';
    wwv_flow_imp.g_varchar2_table(435) := 'row'||wwv_flow.LF||
'\ts18\trgaph108\trrh252\trleft-108\tpvpara\tphmrg\tposyout\tdfrmtxtLeft180\tdfrmtxtRight180\trf';
    wwv_flow_imp.g_varchar2_table(436) := 'tsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\tr';
    wwv_flow_imp.g_varchar2_table(437) := 'paddfr3'||wwv_flow.LF||
'\tscbandsh1\tscbandsv1\tblrsid16132860\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tbl';
    wwv_flow_imp.g_varchar2_table(438) := 'indtype3 \clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrs\brdrw10\brdrcf2';
    wwv_flow_imp.g_varchar2_table(439) := '0 \clcbpat19\cltxlrtb\clftsWidth3\clwWidth4608\clcbpatraw19 '||wwv_flow.LF||
'\cellx4500\clvertalt\clbrdrt\brdrtbl \';
    wwv_flow_imp.g_varchar2_table(440) := 'clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth4050\clshdrawnil \ce';
    wwv_flow_imp.g_varchar2_table(441) := 'llx8550\pard\plain \ltrpar'||wwv_flow.LF||
'\qr \li0\ri0\widctlpar\intbl\pvpara\phmrg\posyout\dxfrtext180\dfrmtxtx18';
    wwv_flow_imp.g_varchar2_table(442) := '0\dfrmtxty0\wraparound\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid16132860\tscfirstcol\yts';
    wwv_flow_imp.g_varchar2_table(443) := '18 \rtlch\fcs1 \ai\af31503\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\i\fs26\lang1033\langfe1033\loch\af31502\hi';
    wwv_flow_imp.g_varchar2_table(444) := 'ch\af31502\dbch\af31501\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31503 \ltrch\fcs0 \cf9\insrsid';
    wwv_flow_imp.g_varchar2_table(445) := '16132860\charrsid11891781 \cell }\pard\plain \ltrpar'||wwv_flow.LF||
'\qr \li0\ri0\widctlpar\intbl\pvpara\phmrg\posy';
    wwv_flow_imp.g_varchar2_table(446) := 'out\dxfrtext180\dfrmtxtx180\dfrmtxty0\wraparound\aspalpha\aspnum\faauto\adjustright\rin0\lin0\parars';
    wwv_flow_imp.g_varchar2_table(447) := 'id16132860\yts18 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033';
    wwv_flow_imp.g_varchar2_table(448) := '\cgrid\langnp1033\langfenp1033 {\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsi';
    wwv_flow_imp.g_varchar2_table(449) := 'd16132860\charrsid11891781 {\*\bkmkstart Text35} FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\insr';
    wwv_flow_imp.g_varchar2_table(450) := 'sid16132860\charrsid11891781 {\*\datafield 8001000000000000065465787433350018544f54414c5f414d4f554e5';
    wwv_flow_imp.g_varchar2_table(451) := '45f4c494142494c495449455300000000000f3c3f7265663a78646f303033353f3e0000000000}{\*\formfield{\fftype0';
    wwv_flow_imp.g_varchar2_table(452) := '\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text35}'||wwv_flow.LF||
'{\*\ffdeftext TOTAL_AMOUNT_LIABILITIES}{\*\ffstat';
    wwv_flow_imp.g_varchar2_table(453) := 'text <?ref:xdo0035?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 \ltrch\fcs0 \lang1024\langfe1024\noproof\in';
    wwv_flow_imp.g_varchar2_table(454) := 'srsid16132860\charrsid11891781 TOTAL_AMOUNT_LIABILITIES}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\endnhere\sectline';
    wwv_flow_imp.g_varchar2_table(455) := 'grid360\sectdefaultcl\sectrsid16132860\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid16132860\cha';
    wwv_flow_imp.g_varchar2_table(456) := 'rrsid11891781 {\*\bkmkend Text35}\cell }\pard\plain \ltrpar\ql \li0\ri0\sa160\sl259\slmult1'||wwv_flow.LF||
'\widctl';
    wwv_flow_imp.g_varchar2_table(457) := 'par\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af31507\afs22\alang1';
    wwv_flow_imp.g_varchar2_table(458) := '025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31507';
    wwv_flow_imp.g_varchar2_table(459) := ' \ltrch\fcs0 \insrsid16132860 '||wwv_flow.LF||
'\trowd \irow2\irowband1\lastrow \ltrrow\ts18\trgaph108\trrh252\trlef';
    wwv_flow_imp.g_varchar2_table(460) := 't-108\tpvpara\tphmrg\tposyout\tdfrmtxtLeft180\tdfrmtxtRight180\trftsWidth1\trftsWidthB3\trftsWidthA3';
    wwv_flow_imp.g_varchar2_table(461) := '\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3'||wwv_flow.LF||
'\tscbandsh1\tscbandsv1\tb';
    wwv_flow_imp.g_varchar2_table(462) := 'lrsid16132860\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrtb';
    wwv_flow_imp.g_varchar2_table(463) := 'l \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrs\brdrw10\brdrcf20 \clcbpat19\cltxlrtb\clftsWidth3\';
    wwv_flow_imp.g_varchar2_table(464) := 'clwWidth4608\clcbpatraw19 '||wwv_flow.LF||
'\cellx4500\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \';
    wwv_flow_imp.g_varchar2_table(465) := 'clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth4050\clshdrawnil \cellx8550\row }\pard \ltrpar\ql \li0';
    wwv_flow_imp.g_varchar2_table(466) := '\ri0\sa160\sl259\slmult1'||wwv_flow.LF||
'\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 ';
    wwv_flow_imp.g_varchar2_table(467) := '{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid11891781 '||wwv_flow.LF||
'\par '||wwv_flow.LF||
'\par '||wwv_flow.LF||
'\par '||wwv_flow.LF||
'\par \ltrrow}\trowd \irow0';
    wwv_flow_imp.g_varchar2_table(468) := '\irowband-1\ltrrow\ts18\trgaph108\trrh252\trleft-108\tpvpara\tphmrg\tposy3\tdfrmtxtLeft180\tdfrmtxtR';
    wwv_flow_imp.g_varchar2_table(469) := 'ight180\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\t';
    wwv_flow_imp.g_varchar2_table(470) := 'rpaddfb3\trpaddfr3\tscbandsh1'||wwv_flow.LF||
'\tscbandsv1\tblrsid16132860\tbllkhdrrows\tbllkhdrcols\tbllknocolband\';
    wwv_flow_imp.g_varchar2_table(471) := 'tblind0\tblindtype3 \clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrs\brdrw10\brdrcf20 \clb';
    wwv_flow_imp.g_varchar2_table(472) := 'rdrr\brdrnone \clcbpat19\cltxlrtb\clftsWidth3\clwWidth4608\clcbpatraw19 \cellx4500'||wwv_flow.LF||
'\clvertalt\clbrd';
    wwv_flow_imp.g_varchar2_table(473) := 'rt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrs\brdrw10\brdrcf20 \clbrdrr\brdrtbl \clcbpat19\cltxlrtb\clf';
    wwv_flow_imp.g_varchar2_table(474) := 'tsWidth3\clwWidth4050\clcbpatraw19 \cellx8550\pard\plain \ltrpar'||wwv_flow.LF||
'\s2\qr \li0\ri0\sb40\keep\keepn\wi';
    wwv_flow_imp.g_varchar2_table(475) := 'dctlpar\intbl\pvpara\phmrg\posy3\dxfrtext180\dfrmtxtx180\dfrmtxty0\wraparound\aspalpha\aspnum\faauto';
    wwv_flow_imp.g_varchar2_table(476) := '\outlinelevel1\adjustright\rin0\lin0\pararsid16132860\tscfirstrow\tscfirstcol\tscnwcell\yts18 \rtlch';
    wwv_flow_imp.g_varchar2_table(477) := '\fcs1 '||wwv_flow.LF||
'\ai\af31503\afs26\alang1025 \ltrch\fcs0 \i\fs26\cf17\lang1033\langfe1033\loch\af31502\hich\a';
    wwv_flow_imp.g_varchar2_table(478) := 'f31502\dbch\af31501\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid16132860';
    wwv_flow_imp.g_varchar2_table(479) := ' \hich\af31502\dbch\af31501\loch\f31502 Owner'||wwv_flow.LF||
'\loch\af31502\dbch\af31501\hich\f31502 \rquote \loch\';
    wwv_flow_imp.g_varchar2_table(480) := 'f31502 s Equity}{\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid16132860\charrsid11891781 \cell }\pard\pla';
    wwv_flow_imp.g_varchar2_table(481) := 'in \ltrpar'||wwv_flow.LF||
'\qr \li0\ri0\widctlpar\intbl\pvpara\phmrg\posy3\dxfrtext180\dfrmtxtx180\dfrmtxty0\wrapar';
    wwv_flow_imp.g_varchar2_table(482) := 'ound\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid16132860\tscfirstrow\yts18 \rtlch\fcs1 \ai';
    wwv_flow_imp.g_varchar2_table(483) := '\af31503\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\i\fs26\lang1033\langfe1033\loch\af31502\hich\af31502\dbch\af';
    wwv_flow_imp.g_varchar2_table(484) := '31501\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid16132860\charrsid11891';
    wwv_flow_imp.g_varchar2_table(485) := '781 \cell }\pard\plain \ltrpar\ql \li0\ri0\sa160\sl259\slmult1'||wwv_flow.LF||
'\widctlpar\intbl\wrapdefault\aspalph';
    wwv_flow_imp.g_varchar2_table(486) := 'a\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\';
    wwv_flow_imp.g_varchar2_table(487) := 'lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid16132860';
    wwv_flow_imp.g_varchar2_table(488) := ' '||wwv_flow.LF||
'\trowd \irow0\irowband-1\ltrrow\ts18\trgaph108\trrh252\trleft-108\tpvpara\tphmrg\tposy3\tdfrmtxtL';
    wwv_flow_imp.g_varchar2_table(489) := 'eft180\tdfrmtxtRight180\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpad';
    wwv_flow_imp.g_varchar2_table(490) := 'dfl3\trpaddft3\trpaddfb3\trpaddfr3\tscbandsh1'||wwv_flow.LF||
'\tscbandsv1\tblrsid16132860\tbllkhdrrows\tbllkhdrcols';
    wwv_flow_imp.g_varchar2_table(491) := '\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrs\brdrw';
    wwv_flow_imp.g_varchar2_table(492) := '10\brdrcf20 \clbrdrr\brdrnone \clcbpat19\cltxlrtb\clftsWidth3\clwWidth4608\clcbpatraw19 \cellx4500'||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(493) := '\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrs\brdrw10\brdrcf20 \clbrdrr\brdrtbl \clcbpa';
    wwv_flow_imp.g_varchar2_table(494) := 't19\cltxlrtb\clftsWidth3\clwWidth4050\clcbpatraw19 \cellx8550\row \ltrrow}\trowd \irow1\irowband0\lt';
    wwv_flow_imp.g_varchar2_table(495) := 'rrow'||wwv_flow.LF||
'\ts18\trgaph108\trrh252\trleft-108\tpvpara\tphmrg\tposy3\tdfrmtxtLeft180\tdfrmtxtRight180\trft';
    wwv_flow_imp.g_varchar2_table(496) := 'sWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trp';
    wwv_flow_imp.g_varchar2_table(497) := 'addfr3\tscbandsh1'||wwv_flow.LF||
'\tscbandsv1\tblrsid16132860\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tbli';
    wwv_flow_imp.g_varchar2_table(498) := 'ndtype3 \clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrs\brdrw10\brdrcf20';
    wwv_flow_imp.g_varchar2_table(499) := ' \clcbpat19\cltxlrtb\clftsWidth3\clwWidth4608\clcbpatraw19 \cellx4500'||wwv_flow.LF||
'\clvertalt\clbrdrt\brdrtbl \c';
    wwv_flow_imp.g_varchar2_table(500) := 'lbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \clcbpat18\cltxlrtb\clftsWidth3\clwWidth4050\clcbpa';
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
    wwv_flow_imp.g_varchar2_table(501) := 'traw18 \cellx8550\pard\plain \ltrpar'||wwv_flow.LF||
'\qr \li0\ri0\widctlpar\intbl\pvpara\phmrg\posy3\dxfrtext180\df';
    wwv_flow_imp.g_varchar2_table(502) := 'rmtxtx180\dfrmtxty0\wraparound\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid16132860\tscfirs';
    wwv_flow_imp.g_varchar2_table(503) := 'tcol\tscbandhorzodd\yts18 \rtlch\fcs1 \ai\af31503\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\i\fs26\lang1033\lan';
    wwv_flow_imp.g_varchar2_table(504) := 'gfe1033\loch\af31502\hich\af31502\dbch\af31501\cgrid\langnp1033\langfenp1033 {\field\flddirty{\*\fld';
    wwv_flow_imp.g_varchar2_table(505) := 'inst {\rtlch\fcs1 \af31503 \ltrch\fcs0 \cf9\insrsid16132860\charrsid11891781 {\*\bkmkstart Text31}'||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(506) := '\hich\af31502\dbch\af31501\loch\f31502  \hich\af31502\dbch\af31501\loch\f31502 FORMTEXT\hich\af31502';
    wwv_flow_imp.g_varchar2_table(507) := '\dbch\af31501\loch\f31502  }{\rtlch\fcs1 \af31503 \ltrch\fcs0 \cf9\insrsid16132860\charrsid11891781 ';
    wwv_flow_imp.g_varchar2_table(508) := '{\*\datafield '||wwv_flow.LF||
'8001000000000000065465787433310002462000000000000f3c3f7265663a78646f303033313f3e0000';
    wwv_flow_imp.g_varchar2_table(509) := '000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text31}{\*\ffdeftext F }{\*\f';
    wwv_flow_imp.g_varchar2_table(510) := 'fstattext <?ref:xdo0031?>}}}}}{\fldrslt {\rtlch\fcs1 \af31503 '||wwv_flow.LF||
'\ltrch\fcs0 \cf9\lang1024\langfe1024';
    wwv_flow_imp.g_varchar2_table(511) := '\noproof\insrsid16132860\charrsid11891781 \hich\af31502\dbch\af31501\loch\f31502 F }}}\sectd \ltrsec';
    wwv_flow_imp.g_varchar2_table(512) := 't\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid16132860\sftnbj {\*\bkmkend Text31}{\field\f';
    wwv_flow_imp.g_varchar2_table(513) := 'lddirty{\*\fldinst '||wwv_flow.LF||
'{\rtlch\fcs1 \af31503 \ltrch\fcs0 \insrsid16132860\charrsid11891781 {\*\bkmksta';
    wwv_flow_imp.g_varchar2_table(514) := 'rt Text32}\hich\af31502\dbch\af31501\loch\f31502  \hich\af31502\dbch\af31501\loch\f31502 FORMTEXT\hi';
    wwv_flow_imp.g_varchar2_table(515) := 'ch\af31502\dbch\af31501\loch\f31502  }{\rtlch\fcs1 \af31503 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid16132860\charrsid1';
    wwv_flow_imp.g_varchar2_table(516) := '1891781 {\*\datafield 8001000000000000065465787433320018504152544943554c4152535f4f574e45525f45515549';
    wwv_flow_imp.g_varchar2_table(517) := '545900000000000f3c3f7265663a78646f303033323f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\';
    wwv_flow_imp.g_varchar2_table(518) := 'fftypetxt0{\*\ffname Text32}'||wwv_flow.LF||
'{\*\ffdeftext PARTICULARS_OWNER_EQUITY}{\*\ffstattext <?ref:xdo0032?>}';
    wwv_flow_imp.g_varchar2_table(519) := '}}}}{\fldrslt {\rtlch\fcs1 \af31503 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid16132860\charrsi';
    wwv_flow_imp.g_varchar2_table(520) := 'd11891781 \hich\af31502\dbch\af31501\loch\f31502 PARTICULARS_OWNER_EQUITY}}}'||wwv_flow.LF||
'\sectd \ltrsect\linex0';
    wwv_flow_imp.g_varchar2_table(521) := '\endnhere\sectlinegrid360\sectdefaultcl\sectrsid16132860\sftnbj {\rtlch\fcs1 \af31503 \ltrch\fcs0 \i';
    wwv_flow_imp.g_varchar2_table(522) := 'nsrsid16132860 {\*\bkmkend Text32}\cell }\pard\plain \ltrpar'||wwv_flow.LF||
'\qr \li0\ri0\widctlpar\intbl\pvpara\ph';
    wwv_flow_imp.g_varchar2_table(523) := 'mrg\posy3\dxfrtext180\dfrmtxtx180\dfrmtxty0\wraparound\aspalpha\aspnum\faauto\adjustright\rin0\lin0\';
    wwv_flow_imp.g_varchar2_table(524) := 'pararsid16132860\tscbandhorzodd\yts18 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs2';
    wwv_flow_imp.g_varchar2_table(525) := '2\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\field\flddirty{\*\fldinst {\rtlch\fcs1 \af3150';
    wwv_flow_imp.g_varchar2_table(526) := '7 \ltrch\fcs0 \insrsid16132860\charrsid11891781 {\*\bkmkstart Text33} FORMTEXT }{\rtlch\fcs1 \af3150';
    wwv_flow_imp.g_varchar2_table(527) := '7 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid16132860\charrsid11891781 {\*\datafield 800100000000000006546578743333000641';
    wwv_flow_imp.g_varchar2_table(528) := '4d4f554e5400000000000f3c3f7265663a78646f303033333f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffow';
    wwv_flow_imp.g_varchar2_table(529) := 'nstat\fftypetxt0{\*\ffname Text33}{\*\ffdeftext AMOUNT}{\*\ffstattext '||wwv_flow.LF||
'<?ref:xdo0033?>}}}}}{\fldrsl';
    wwv_flow_imp.g_varchar2_table(530) := 't {\rtlch\fcs1 \af31507 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid16132860\charrsid11891781 AM';
    wwv_flow_imp.g_varchar2_table(531) := 'OUNT}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid16132860\sftnbj {\*\bkm';
    wwv_flow_imp.g_varchar2_table(532) := 'kend Text33}'||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\insrsid16132860\cha';
    wwv_flow_imp.g_varchar2_table(533) := 'rrsid11891781 {\*\bkmkstart Text34} FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\insrsid16132860';
    wwv_flow_imp.g_varchar2_table(534) := '\charrsid11891781 {\*\datafield '||wwv_flow.LF||
'8001000000000000065465787433340002204500000000000f3c3f7265663a7864';
    wwv_flow_imp.g_varchar2_table(535) := '6f303033343f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text34}{\*\';
    wwv_flow_imp.g_varchar2_table(536) := 'ffdeftext  E}{\*\ffstattext <?ref:xdo0034?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 '||wwv_flow.LF||
'\ltrch\fcs0 \cf9\l';
    wwv_flow_imp.g_varchar2_table(537) := 'ang1024\langfe1024\noproof\insrsid16132860\charrsid11891781  E}}}\sectd \ltrsect\linex0\endnhere\sec';
    wwv_flow_imp.g_varchar2_table(538) := 'tlinegrid360\sectdefaultcl\sectrsid16132860\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid1613286';
    wwv_flow_imp.g_varchar2_table(539) := '0 {\*\bkmkend Text34}\cell '||wwv_flow.LF||
'}\pard\plain \ltrpar\ql \li0\ri0\sa160\sl259\slmult1\widctlpar\intbl\wr';
    wwv_flow_imp.g_varchar2_table(540) := 'apdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\f';
    wwv_flow_imp.g_varchar2_table(541) := 'cs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 '||wwv_flow.LF||
'\af31507 \ltrch\fc';
    wwv_flow_imp.g_varchar2_table(542) := 's0 \insrsid16132860 \trowd \irow1\irowband0\ltrrow'||wwv_flow.LF||
'\ts18\trgaph108\trrh252\trleft-108\tpvpara\tphmr';
    wwv_flow_imp.g_varchar2_table(543) := 'g\tposy3\tdfrmtxtLeft180\tdfrmtxtRight180\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl10';
    wwv_flow_imp.g_varchar2_table(544) := '8\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tscbandsh1'||wwv_flow.LF||
'\tscbandsv1\tblrsid16132860\tbllkhd';
    wwv_flow_imp.g_varchar2_table(545) := 'rrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \c';
    wwv_flow_imp.g_varchar2_table(546) := 'lbrdrb\brdrtbl \clbrdrr\brdrs\brdrw10\brdrcf20 \clcbpat19\cltxlrtb\clftsWidth3\clwWidth4608\clcbpatr';
    wwv_flow_imp.g_varchar2_table(547) := 'aw19 \cellx4500'||wwv_flow.LF||
'\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \clcb';
    wwv_flow_imp.g_varchar2_table(548) := 'pat18\cltxlrtb\clftsWidth3\clwWidth4050\clcbpatraw18 \cellx8550\row \ltrrow}\trowd \irow2\irowband1\';
    wwv_flow_imp.g_varchar2_table(549) := 'lastrow \ltrrow'||wwv_flow.LF||
'\ts18\trgaph108\trrh252\trleft-108\tpvpara\tphmrg\tposy3\tdfrmtxtLeft180\tdfrmtxtRi';
    wwv_flow_imp.g_varchar2_table(550) := 'ght180\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\tr';
    wwv_flow_imp.g_varchar2_table(551) := 'paddfb3\trpaddfr3\tscbandsh1'||wwv_flow.LF||
'\tscbandsv1\tblrsid16132860\tbllkhdrrows\tbllkhdrcols\tbllknocolband\t';
    wwv_flow_imp.g_varchar2_table(552) := 'blind0\tblindtype3 \clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrs\brdrw';
    wwv_flow_imp.g_varchar2_table(553) := '10\brdrcf20 \clcbpat19\cltxlrtb\clftsWidth3\clwWidth4608\clcbpatraw19 \cellx4500'||wwv_flow.LF||
'\clvertalt\clbrdrt';
    wwv_flow_imp.g_varchar2_table(554) := '\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth4050\clshd';
    wwv_flow_imp.g_varchar2_table(555) := 'rawnil \cellx8550\pard\plain \ltrpar'||wwv_flow.LF||
'\qr \li0\ri0\widctlpar\intbl\pvpara\phmrg\posy3\dxfrtext180\df';
    wwv_flow_imp.g_varchar2_table(556) := 'rmtxtx180\dfrmtxty0\wraparound\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid16132860\tscfirs';
    wwv_flow_imp.g_varchar2_table(557) := 'tcol\yts18 \rtlch\fcs1 \ai\af31503\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\i\fs26\lang1033\langfe1033\loch\af';
    wwv_flow_imp.g_varchar2_table(558) := '31502\hich\af31502\dbch\af31501\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31503 \ltrch\fcs0 \cf9';
    wwv_flow_imp.g_varchar2_table(559) := '\insrsid16132860\charrsid11891781 \cell }\pard\plain \ltrpar'||wwv_flow.LF||
'\qr \li0\ri0\widctlpar\intbl\pvpara\ph';
    wwv_flow_imp.g_varchar2_table(560) := 'mrg\posy3\dxfrtext180\dfrmtxtx180\dfrmtxty0\wraparound\aspalpha\aspnum\faauto\adjustright\rin0\lin0\';
    wwv_flow_imp.g_varchar2_table(561) := 'pararsid16132860\yts18 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\lang';
    wwv_flow_imp.g_varchar2_table(562) := 'fe1033\cgrid\langnp1033\langfenp1033 {\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \';
    wwv_flow_imp.g_varchar2_table(563) := 'insrsid16132860\charrsid11891781 {\*\bkmkstart Text36} FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 ';
    wwv_flow_imp.g_varchar2_table(564) := ''||wwv_flow.LF||
'\insrsid16132860\charrsid11891781 {\*\datafield 8001000000000000065465787433360013544f54414c5f414d4';
    wwv_flow_imp.g_varchar2_table(565) := 'f554e545f45515549545900000000000f3c3f7265663a78646f303033363f3e0000000000}{\*\formfield{\fftype0\ffo';
    wwv_flow_imp.g_varchar2_table(566) := 'wnhelp\ffownstat\fftypetxt0{\*\ffname Text36}'||wwv_flow.LF||
'{\*\ffdeftext TOTAL_AMOUNT_EQUITY}{\*\ffstattext <?re';
    wwv_flow_imp.g_varchar2_table(567) := 'f:xdo0036?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid1613';
    wwv_flow_imp.g_varchar2_table(568) := '2860\charrsid11891781 TOTAL_AMOUNT_EQUITY}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\endnhere\sectlinegrid360\sectde';
    wwv_flow_imp.g_varchar2_table(569) := 'faultcl\sectrsid16132860\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid16132860\charrsid11891781 ';
    wwv_flow_imp.g_varchar2_table(570) := '{\*\bkmkend Text36}\cell }\pard\plain \ltrpar\ql \li0\ri0\sa160\sl259\slmult1'||wwv_flow.LF||
'\widctlpar\intbl\wrap';
    wwv_flow_imp.g_varchar2_table(571) := 'default\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs';
    wwv_flow_imp.g_varchar2_table(572) := '0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \';
    wwv_flow_imp.g_varchar2_table(573) := 'insrsid16132860 '||wwv_flow.LF||
'\trowd \irow2\irowband1\lastrow \ltrrow\ts18\trgaph108\trrh252\trleft-108\tpvpara\';
    wwv_flow_imp.g_varchar2_table(574) := 'tphmrg\tposy3\tdfrmtxtLeft180\tdfrmtxtRight180\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpa';
    wwv_flow_imp.g_varchar2_table(575) := 'ddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tscbandsh1'||wwv_flow.LF||
'\tscbandsv1\tblrsid16132860\tb';
    wwv_flow_imp.g_varchar2_table(576) := 'llkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrt';
    wwv_flow_imp.g_varchar2_table(577) := 'bl \clbrdrb\brdrtbl \clbrdrr\brdrs\brdrw10\brdrcf20 \clcbpat19\cltxlrtb\clftsWidth3\clwWidth4608\clc';
    wwv_flow_imp.g_varchar2_table(578) := 'bpatraw19 \cellx4500'||wwv_flow.LF||
'\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl ';
    wwv_flow_imp.g_varchar2_table(579) := '\cltxlrtb\clftsWidth3\clwWidth4050\clshdrawnil \cellx8550\row }\pard \ltrpar\ql \li0\ri0\sa160\sl259';
    wwv_flow_imp.g_varchar2_table(580) := '\slmult1'||wwv_flow.LF||
'\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 {\rtlch\fcs1 \af';
    wwv_flow_imp.g_varchar2_table(581) := '31507 \ltrch\fcs0 \insrsid13067081 '||wwv_flow.LF||
'\par '||wwv_flow.LF||
'\par '||wwv_flow.LF||
'\par '||wwv_flow.LF||
'\par '||wwv_flow.LF||
'\par \ltrrow}\trowd \irow0\irowband';
    wwv_flow_imp.g_varchar2_table(582) := '-1\lastrow \ltrrow\ts16\trgaph108\trrh268\trleft-108\tpvpara\tphmrg\tposy946\tdfrmtxtLeft180\tdfrmtx';
    wwv_flow_imp.g_varchar2_table(583) := 'tRight180\trftsWidth3\trwWidth10226\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpad';
    wwv_flow_imp.g_varchar2_table(584) := 'dfl3\trpaddft3\trpaddfb3'||wwv_flow.LF||
'\trpaddfr3\tscbandsh1\tscbandsv1\tblrsid16132860\tbllkhdrrows\tbllkhdrcols';
    wwv_flow_imp.g_varchar2_table(585) := '\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \cl';
    wwv_flow_imp.g_varchar2_table(586) := 'brdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth2084\clshdrawnil \cellx1976\clvertalt'||wwv_flow.LF||
'\clbrdrt\brdrtbl ';
    wwv_flow_imp.g_varchar2_table(587) := '\clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth2458\clshdrawnil \c';
    wwv_flow_imp.g_varchar2_table(588) := 'ellx4434\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clft';
    wwv_flow_imp.g_varchar2_table(589) := 'sWidth3\clwWidth3576\clshdrawnil '||wwv_flow.LF||
'\cellx8010\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\br';
    wwv_flow_imp.g_varchar2_table(590) := 'drtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth2108\clshdrawnil \cellx10118\pard\plain \ltrpar';
    wwv_flow_imp.g_varchar2_table(591) := ''||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\intbl\pvpara\phmrg\posy946\dxfrtext180\dfrmtxtx180\dfrmtxty0\wraparound\asp';
    wwv_flow_imp.g_varchar2_table(592) := 'alpha\aspnum\faauto\adjustright\rin0\lin0\pararsid16132860\tscfirstrow\tscfirstcol\yts16 \rtlch\fcs1';
    wwv_flow_imp.g_varchar2_table(593) := ' \ab\af31507\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\b\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langf';
    wwv_flow_imp.g_varchar2_table(594) := 'enp1033 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid16132860 Total Asset\cell }\pard\plain \ltrpar'||wwv_flow.LF||
'\q';
    wwv_flow_imp.g_varchar2_table(595) := 'r \li0\ri0\widctlpar\intbl\pvpara\phmrg\posy946\dxfrtext180\dfrmtxtx180\dfrmtxty0\wraparound\aspalph';
    wwv_flow_imp.g_varchar2_table(596) := 'a\aspnum\faauto\adjustright\rin0\lin0\pararsid16132860\tscfirstrow\yts16 \rtlch\fcs1 \ab\af31507\afs';
    wwv_flow_imp.g_varchar2_table(597) := '22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\b\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\field\';
    wwv_flow_imp.g_varchar2_table(598) := 'flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid16132860\charrsid13067081 {\*\bkmkstar';
    wwv_flow_imp.g_varchar2_table(599) := 't Text16} FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid16132860\charrsid13067081 {\*\datafi';
    wwv_flow_imp.g_varchar2_table(600) := 'eld 8001000000000000065465787431360012544f54414c5f414d4f554e545f415353455400000000000f3c3f7265663a78';
    wwv_flow_imp.g_varchar2_table(601) := '646f303031363f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text16}'||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(602) := '{\*\ffdeftext TOTAL_AMOUNT_ASSET}{\*\ffstattext <?ref:xdo0016?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 ';
    wwv_flow_imp.g_varchar2_table(603) := '\ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid16132860\charrsid13067081 TOTAL_AMOUNT_ASSET}}}\sect';
    wwv_flow_imp.g_varchar2_table(604) := 'd \ltrsect'||wwv_flow.LF||
'\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid16132860\sftnbj {\rtlch\fcs1 \af3';
    wwv_flow_imp.g_varchar2_table(605) := '1507 \ltrch\fcs0 \insrsid16132860 {\*\bkmkend Text16}\cell }\pard\plain \ltrpar'||wwv_flow.LF||
'\ql \li0\ri0\widctl';
    wwv_flow_imp.g_varchar2_table(606) := 'par\intbl\pvpara\phmrg\posy946\dxfrtext180\dfrmtxtx180\dfrmtxty0\wraparound\aspalpha\aspnum\faauto\a';
    wwv_flow_imp.g_varchar2_table(607) := 'djustright\rin0\lin0\pararsid16132860\tscfirstrow\yts16 \rtlch\fcs1 \ab\af31507\afs22\alang1025 \ltr';
    wwv_flow_imp.g_varchar2_table(608) := 'ch\fcs0 '||wwv_flow.LF||
'\b\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \lt';
    wwv_flow_imp.g_varchar2_table(609) := 'rch\fcs0 \insrsid16132860 Total Liabilities & Owner\rquote s Equity\cell }\pard\plain \ltrpar'||wwv_flow.LF||
'\qr \';
    wwv_flow_imp.g_varchar2_table(610) := 'li0\ri0\widctlpar\intbl\pvpara\phmrg\posy946\dxfrtext180\dfrmtxtx180\dfrmtxty0\wraparound\aspalpha\a';
    wwv_flow_imp.g_varchar2_table(611) := 'spnum\faauto\adjustright\rin0\lin0\pararsid16132860\tscfirstrow\yts16 \rtlch\fcs1 \ab\af31507\afs22\';
    wwv_flow_imp.g_varchar2_table(612) := 'alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\b\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\field\fld';
    wwv_flow_imp.g_varchar2_table(613) := 'dirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid16132860\charrsid13067081 {\*\bkmkstart T';
    wwv_flow_imp.g_varchar2_table(614) := 'ext17} FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid16132860\charrsid13067081 {\*\datafield';
    wwv_flow_imp.g_varchar2_table(615) := ' 800100000000000006546578743137000d544f54414c5f424f54485f4c5100000000000f3c3f7265663a78646f303031373';
    wwv_flow_imp.g_varchar2_table(616) := 'f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text17}{\*\ffdeftext ';
    wwv_flow_imp.g_varchar2_table(617) := ''||wwv_flow.LF||
'TOTAL_BOTH_LQ}{\*\ffstattext <?ref:xdo0017?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 \ltrch\fcs0 \lang1';
    wwv_flow_imp.g_varchar2_table(618) := '024\langfe1024\noproof\insrsid16132860\charrsid13067081 TOTAL_BOTH_LQ}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\end';
    wwv_flow_imp.g_varchar2_table(619) := 'nhere\sectlinegrid360\sectdefaultcl\sectrsid16132860\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrs';
    wwv_flow_imp.g_varchar2_table(620) := 'id16132860 {\*\bkmkend Text17}\cell }\pard\plain \ltrpar\ql \li0\ri0\sa160\sl259\slmult1'||wwv_flow.LF||
'\widctlpar';
    wwv_flow_imp.g_varchar2_table(621) := '\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af31507\afs22\alang1025';
    wwv_flow_imp.g_varchar2_table(622) := ' \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \l';
    wwv_flow_imp.g_varchar2_table(623) := 'trch\fcs0 \insrsid16132860 '||wwv_flow.LF||
'\trowd \irow0\irowband-1\lastrow \ltrrow\ts16\trgaph108\trrh268\trleft-';
    wwv_flow_imp.g_varchar2_table(624) := '108\tpvpara\tphmrg\tposy946\tdfrmtxtLeft180\tdfrmtxtRight180\trftsWidth3\trwWidth10226\trftsWidthB3\';
    wwv_flow_imp.g_varchar2_table(625) := 'trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3'||wwv_flow.LF||
'\trpaddfr3\tscbandsh1\t';
    wwv_flow_imp.g_varchar2_table(626) := 'scbandsv1\tblrsid16132860\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\cl';
    wwv_flow_imp.g_varchar2_table(627) := 'brdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth2084\';
    wwv_flow_imp.g_varchar2_table(628) := 'clshdrawnil \cellx1976\clvertalt'||wwv_flow.LF||
'\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtb';
    wwv_flow_imp.g_varchar2_table(629) := 'l \cltxlrtb\clftsWidth3\clwWidth2458\clshdrawnil \cellx4434\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrt';
    wwv_flow_imp.g_varchar2_table(630) := 'bl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth3576\clshdrawnil '||wwv_flow.LF||
'\cellx8010\clv';
    wwv_flow_imp.g_varchar2_table(631) := 'ertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwW';
    wwv_flow_imp.g_varchar2_table(632) := 'idth2108\clshdrawnil \cellx10118\row }\pard \ltrpar\ql \li0\ri0\sa160\sl259\slmult1'||wwv_flow.LF||
'\widctlpar\wrap';
    wwv_flow_imp.g_varchar2_table(633) := 'default\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsi';
    wwv_flow_imp.g_varchar2_table(634) := 'd13067081 '||wwv_flow.LF||
'\par }{\*\themedata 504b030414000600080000002100e9de0fbfff0000001c020000130000005b436f6e';
    wwv_flow_imp.g_varchar2_table(635) := '74656e745f54797065735d2e786d6cac91cb4ec3301045f748fc83e52d4a'||wwv_flow.LF||
'9cb2400825e982c78ec7a27cc0c8992416c9d8';
    wwv_flow_imp.g_varchar2_table(636) := 'b2a755fbf74cd25442a820166c2cd933f79e3be372bd1f07b5c3989ca74aaff2422b24eb1b475da5df374fd9ad'||wwv_flow.LF||
'5689811a';
    wwv_flow_imp.g_varchar2_table(637) := '183c61a50f98f4babebc2837878049899a52a57be670674cb23d8e90721f90a4d2fa3802cb35762680fd800ecd7551dc18eb';
    wwv_flow_imp.g_varchar2_table(638) := '899138e3c943d7e503b6'||wwv_flow.LF||
'b01d583deee5f99824e290b4ba3f364eac4a430883b3c092d4eca8f946c916422ecab927f52ea4';
    wwv_flow_imp.g_varchar2_table(639) := '2b89a1cd59c254f919b0e85e6535d135a8de20f20b8c12c3b0'||wwv_flow.LF||
'0c895fcf6720192de6bf3b9e89ecdbd6596cbcdd8eb28e7c';
    wwv_flow_imp.g_varchar2_table(640) := '365ecc4ec1ff1460f53fe813d3cc7f5b7f020000ffff0300504b030414000600080000002100a5d6'||wwv_flow.LF||
'a7e7c0000000360100';
    wwv_flow_imp.g_varchar2_table(641) := '000b0000005f72656c732f2e72656c73848fcf6ac3300c87ef85bd83d17d51d2c31825762fa590432fa37d00e1287f68221b';
    wwv_flow_imp.g_varchar2_table(642) := 'db1bebdb4f'||wwv_flow.LF||
'c7060abb0884a4eff7a93dfeae8bf9e194e720169aaa06c3e2433fcb68e1763dbf7f82c985a4a725085b7870';
    wwv_flow_imp.g_varchar2_table(643) := '86a37bdbb55fbc50d1a33ccd311ba548b6309512'||wwv_flow.LF||
'0f88d94fbc52ae4264d1c910d24a45db3462247fa791715fd71f989e19';
    wwv_flow_imp.g_varchar2_table(644) := 'e0364cd3f51652d73760ae8fa8c9ffb3c330cc9e4fc17faf2ce545046e37944c69e462'||wwv_flow.LF||
'a1a82fe353bd90a865aad41ed0b5';
    wwv_flow_imp.g_varchar2_table(645) := 'b8f9d6fd010000ffff0300504b0304140006000800000021006b799616830000008a0000001c0000007468656d652f746865';
    wwv_flow_imp.g_varchar2_table(646) := ''||wwv_flow.LF||
'6d652f7468656d654d616e616765722e786d6c0ccc4d0ac3201040e17da17790d93763bb284562b2cbaebbf600439c1a41';
    wwv_flow_imp.g_varchar2_table(647) := 'c7a0d29fdbd7e5e38337cedf14d59b'||wwv_flow.LF||
'4b0d592c9c070d8a65cd2e88b7f07c2ca71ba8da481cc52c6ce1c715e6e97818c9b4';
    wwv_flow_imp.g_varchar2_table(648) := '8d13df49c873517d23d59085adb5dd20d6b52bd521ef2cdd5eb9246a3d8b'||wwv_flow.LF||
'4757e8d3f729e245eb2b260a0238fd010000ff';
    wwv_flow_imp.g_varchar2_table(649) := 'ff0300504b030414000600080000002100b6f4679893070000c9200000160000007468656d652f7468656d652f'||wwv_flow.LF||
'7468656d';
    wwv_flow_imp.g_varchar2_table(650) := '65312e786d6cec59cd8b1bc915bf07f23f347d97f5d5ad8fc1f2a24fcfda33b6b164873dd648a5eef2547789aad28cc56208';
    wwv_flow_imp.g_varchar2_table(651) := 'de532e81c026e49085bd'||wwv_flow.LF||
'ed21842cecc22eb9e48f31d8249b3f22afaa5bdd5552c99e191c3061463074977eefd5afde7bf5';
    wwv_flow_imp.g_varchar2_table(652) := 'de53d5ddcf5e26d4bbc05c1096f6fcfa9d9aefe174ce16248d'||wwv_flow.LF||
'7afeb3d9a4d2f13d2151ba4094a5b8e76fb0f03fbbf7eb5f';
    wwv_flow_imp.g_varchar2_table(653) := 'dd454732c609f6403e1547a8e7c752ae8eaa5531876124eeb0154ee1bb25e30992f0caa3ea82a34b'||wwv_flow.LF||
'd09bd06aa3566b5513';
    wwv_flow_imp.g_varchar2_table(654) := '4452df4b51026a1f2f97648ebd9952e9dfdb2a1f53784da5500373caa74a35b6243476715e5708b11143cabd0b447b3eccb3';
    wwv_flow_imp.g_varchar2_table(655) := '609733fc52'||wwv_flow.LF||
'fa1e4542c2173dbfa6fffceabdbb5574940b517940d6909be8bf5c2e17589c37f49c3c3a2b260d823068f50b';
    wwv_flow_imp.g_varchar2_table(656) := 'fd1a40e53e6edc1eb7c6ad429f06a0f91c569a71'||wwv_flow.LF||
'b175b61bc320c71aa0ecd1a17bd41e35eb16ded0dfdce3dc0fd5c7c26b';
    wwv_flow_imp.g_varchar2_table(657) := '50a63fd8c34f2643b0a285d7a00c1feee1c3417730b2f56b50866fede1dbb5fe28685b'||wwv_flow.LF||
'fa3528a6243ddf43d7c25673b85d';
    wwv_flow_imp.g_varchar2_table(658) := '6d0159327aec8477c360d26ee4ca4b144443115d6a8a254be5a1584bd00bc6270050408a24493db959e1259a43140f112567';
    wwv_flow_imp.g_varchar2_table(659) := ''||wwv_flow.LF||
'9c7827248a21f056286502866b8ddaa4d684ffea13e827ed5174849121ad780113b137a4f87862cec94af6fc07a0d53720';
    wwv_flow_imp.g_varchar2_table(660) := '6f7ffef9cdeb1fdfbcfee9cd575fbd'||wwv_flow.LF||
'79fdf77c6eadca923b466964cafdf2dd1ffef3cd6fbd7ffff0ed2f5fff319b7a172f';
    wwv_flow_imp.g_varchar2_table(661) := '4cfcbbbffdeedd3ffef93ef5b0e2d2146ffff4fdbb1fbf7ffbe7dfffebaf'||wwv_flow.LF||
'5f3bb4f7393a33e1339260e13dc297de5396c0';
    wwv_flow_imp.g_varchar2_table(662) := '021dfcf119bf9ec42c46c494e8a791402952b338f48f656ca11f6d10450edc00db767cce21d5b880f7d72f2cc2'||wwv_flow.LF||
'd398af25';
    wwv_flow_imp.g_varchar2_table(663) := '71687c182716f094313a60dc6985876a2ec3ccb3751ab927e76b13f714a10bd7dc43945a5e1eaf579063894be530c616cd27';
    wwv_flow_imp.g_varchar2_table(664) := '14a5124538c5d253dfb1'||wwv_flow.LF||
'738c1dabfb8210cbaea764ce99604be97d41bc01224e93ccc899154da5d03149c02f1b1741f0b7';
    wwv_flow_imp.g_varchar2_table(665) := '659bd3e7de8051d7aa47f8c246c2de40d4417e86a965c6fb68'||wwv_flow.LF||
'2d51e252394309350d7e8264ec2239ddf0b9891b0b099e8e';
    wwv_flow_imp.g_varchar2_table(666) := '3065de78818570c93ce6b05ec3e90f21cdb8dd7e4a37898de4929cbb749e20c64ce4889d0f6394ac'||wwv_flow.LF||
'5cd829496313fbb938';
    wwv_flow_imp.g_varchar2_table(667) := '871045de13265df05366ef10f50e7e40e941773f27d872f787b3c133c8b026a53240d4376beef0e57dccacf89d6ee8126157';
    wwv_flow_imp.g_varchar2_table(668) := 'aae9f3c44a'||wwv_flow.LF||
'b17d4e9cd131584756689f604cd1255a60ec3dfbdcc160c05696cd4bd20f62c82ac7d815580f901dabea3dc5';
    wwv_flow_imp.g_varchar2_table(669) := '027a25d5dcece7c91322ac909de2881de073bad9'||wwv_flow.LF||
'493c1b9426881fd2fc08bc6eda7c0ca52e7105c0633a3f37818f08f480';
    wwv_flow_imp.g_varchar2_table(670) := '102f4ea33c16a0c308ee835a9fc4c82a60ea5db8e375c32dff5d658fc1be7c61d1b8c2'||wwv_flow.LF||
'be04197c6d1948eca6cc7b6d3343';
    wwv_flow_imp.g_varchar2_table(671) := 'd49aa00c9819822ec3956e41c4727f29a28aab165b3be596f6a62ddd00dd91d5f42424fd6007b4d3fb84ffbbde073a8cb77f';
    wwv_flow_imp.g_varchar2_table(672) := ''||wwv_flow.LF||
'f9c6b10f3e4ebfe3566c25ab6b763a8792c9f14e7f7308b7dbd50c195f904fbfa919a175fa04431dd9cf58b73dcd6d4fe3';
    wwv_flow_imp.g_varchar2_table(673) := 'ffdff73487f6f36d2773a8dfb8ed64'||wwv_flow.LF||
'7ce8306e3b99fc70e5e3743265f3027d8d3af0c80e7af4b14f72f0d46749289dca0d';
    wwv_flow_imp.g_varchar2_table(674) := 'c527421ffc08f83db398c0a092d3279eb838055cc5f0a8ca1c4c60e1228e'||wwv_flow.LF||
'b48cc799fc0d91f134462b381daafb4a492472';
    wwv_flow_imp.g_varchar2_table(675) := 'd591f0564cc0a1911e76ea5678ba4e4ed9223becacd7d5c16656590592e5782d2cc6e1a04a66e856bb3cc02bd4'||wwv_flow.LF||
'6bb6913e';
    wwv_flow_imp.g_varchar2_table(676) := '68dd1250b2d721614c6693683a48b4b783ca48fa58178ce620a157f65158741d2c3a4afdd6557b2c805ae115f8c1edc1cff4';
    wwv_flow_imp.g_varchar2_table(677) := '9e1f06200242701e07cd'||wwv_flow.LF||
'f942f92973f5d6bbda991fd3d3878c69450034d8db08283ddd555c0f2e4fad2e0bb52b78da2261';
    wwv_flow_imp.g_varchar2_table(678) := '849b4d425b46377822869fc17974aad1abd0b8aeafbba54b2d'||wwv_flow.LF||
'7aca147a3e08ad9246bbf33e1637f535c8ede6069a9a9982';
    wwv_flow_imp.g_varchar2_table(679) := 'a6de65cf6f35430899395af5fc251c1ac363b282d811ea3717a211dcbccc25cf36fc4d32cb8a0b39'||wwv_flow.LF||
'4222ce0cae934e960d';
    wwv_flow_imp.g_varchar2_table(680) := '122231f728497abe5a7ee1069aea1ca2b9d51b90103e59725d482b9f1a3970baed64bc5ce2b934dd6e8c284b67af90e1b35c';
    wwv_flow_imp.g_varchar2_table(681) := 'e1fc568bdf'||wwv_flow.LF||
'1cac24d91adc3d8d1797de195df3a708422c6cd795011744c0dd413db3e682c0655891c8caf8db294c79da35';
    wwv_flow_imp.g_varchar2_table(682) := '6fa3740c65e388ae62945714339967709dca0b3a'||wwv_flow.LF||
'faadb081f196af190c6a98242f8467912ab0a651ad6a5a548d8cc3c1aa';
    wwv_flow_imp.g_varchar2_table(683) := 'fb6121653923699635d3ca2aaa6abab39835c3b60cecd8f26645de60b53531e434b3c2'||wwv_flow.LF||
'67a97b37e576b7b96ea74f28aa04';
    wwv_flow_imp.g_varchar2_table(684) := '18bcb09fa3ea5ea12018d4cac92c6a8af17e1a56393b1fb56bc776811fa07695226164fdd656ed8edd8a1ae19c0e066f54f9';
    wwv_flow_imp.g_varchar2_table(685) := ''||wwv_flow.LF||
'416e376a6168b9ed2bb5a5f5adb979b1cdce5e40f2184197bba6526857c2c92e47d0104d754f92a50dd8222f65be35e0c9';
    wwv_flow_imp.g_varchar2_table(686) := '5b73d2f3bfac85fd60d80887955a27'||wwv_flow.LF||
'1c57826650ab74c27eb3d20fc3667d1cd66ba341e31514161927f530bbb19fc00506';
    wwv_flow_imp.g_varchar2_table(687) := 'dde4f7f67a7cefee3ed9ded1dc99b3a4caf4dd7c5513d777f7f5c6e1bb7b'||wwv_flow.LF||
'8f40d2f9b2d598749bdd41abd26df627956034';
    wwv_flow_imp.g_varchar2_table(688) := 'e854bac3d6a0326a0ddba3c9681876ba9357be77a1c141bf390c5ae34ea5551f0e2b41aba6e877ba9576d068f4'||wwv_flow.LF||
'8376bf33';
    wwv_flow_imp.g_varchar2_table(689) := '0efaaff23606569ea58fdc16605ecdebde7f010000ffff0300504b0304140006000800000021000dd1909fb60000001b0100';
    wwv_flow_imp.g_varchar2_table(690) := '00270000007468656d65'||wwv_flow.LF||
'2f7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73848f4d0ac2';
    wwv_flow_imp.g_varchar2_table(691) := '301484f78277086f6fd3ba109126dd88d0add40384e4350d36'||wwv_flow.LF||
'3f2451eced0dae2c082e8761be9969bb979dc9136332de31';
    wwv_flow_imp.g_varchar2_table(692) := '68aa1a083ae995719ac16db8ec8e4052164e89d93b64b060828e6f37ed1567914b284d262452282e'||wwv_flow.LF||
'3198720e274a939cd0';
    wwv_flow_imp.g_varchar2_table(693) := '8a54f980ae38a38f56e422a3a641c8bbd048f7757da0f19b017cc524bd62107bd5001996509affb3fd381a89672f1f165dfe';
    wwv_flow_imp.g_varchar2_table(694) := '514173d985'||wwv_flow.LF||
'0528a2c6cce0239baa4c04ca5bbabac4df000000ffff0300504b01022d0014000600080000002100e9de0fbf';
    wwv_flow_imp.g_varchar2_table(695) := 'ff0000001c020000130000000000000000000000'||wwv_flow.LF||
'0000000000005b436f6e74656e745f54797065735d2e786d6c504b0102';
    wwv_flow_imp.g_varchar2_table(696) := '2d0014000600080000002100a5d6a7e7c0000000360100000b00000000000000000000'||wwv_flow.LF||
'000000300100005f72656c732f2e';
    wwv_flow_imp.g_varchar2_table(697) := '72656c73504b01022d00140006000800000021006b799616830000008a0000001c0000000000000000000000000019020000';
    wwv_flow_imp.g_varchar2_table(698) := ''||wwv_flow.LF||
'7468656d652f7468656d652f7468656d654d616e616765722e786d6c504b01022d0014000600080000002100b6f4679893';
    wwv_flow_imp.g_varchar2_table(699) := '070000c92000001600000000000000'||wwv_flow.LF||
'000000000000d60200007468656d652f7468656d652f7468656d65312e786d6c504b';
    wwv_flow_imp.g_varchar2_table(700) := '01022d00140006000800000021000dd1909fb60000001b01000027000000'||wwv_flow.LF||
'000000000000000000009d0a00007468656d65';
    wwv_flow_imp.g_varchar2_table(701) := '2f7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73504b050600000000050005005d010000';
    wwv_flow_imp.g_varchar2_table(702) := '980b00000000}'||wwv_flow.LF||
'{\*\colorschememapping 3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d2255';
    wwv_flow_imp.g_varchar2_table(703) := '54462d3822207374616e64616c6f6e653d22796573223f3e0d0a3c613a636c724d'||wwv_flow.LF||
'617020786d6c6e733a613d2268747470';
    wwv_flow_imp.g_varchar2_table(704) := '3a2f2f736368656d61732e6f70656e786d6c666f726d6174732e6f72672f64726177696e676d6c2f323030362f6d6169'||wwv_flow.LF||
'6e';
    wwv_flow_imp.g_varchar2_table(705) := '22206267313d226c743122207478313d22646b3122206267323d226c743222207478323d22646b322220616363656e74313d';
    wwv_flow_imp.g_varchar2_table(706) := '22616363656e74312220616363'||wwv_flow.LF||
'656e74323d22616363656e74322220616363656e74333d22616363656e74332220616363';
    wwv_flow_imp.g_varchar2_table(707) := '656e74343d22616363656e74342220616363656e74353d22616363656e74352220616363656e74363d22616363656e743622';
    wwv_flow_imp.g_varchar2_table(708) := '20686c696e6b3d22686c696e6b2220666f6c486c696e6b3d22666f6c486c696e6b222f3e}'||wwv_flow.LF||
'{\*\latentstyles\lsdstima';
    wwv_flow_imp.g_varchar2_table(709) := 'x371\lsdlockeddef0\lsdsemihiddendef0\lsdunhideuseddef0\lsdqformatdef0\lsdprioritydef99{\lsdlockedexc';
    wwv_flow_imp.g_varchar2_table(710) := 'ept \lsdqformat1 \lsdpriority0 \lsdlocked0 Normal;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 1;';
    wwv_flow_imp.g_varchar2_table(711) := ''||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 2;\lsdsemihidden1 \l';
    wwv_flow_imp.g_varchar2_table(712) := 'sdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 3;\lsdsemihidden1 \lsdunhideused1 \lsdq';
    wwv_flow_imp.g_varchar2_table(713) := 'format1 \lsdpriority9 \lsdlocked0 heading 4;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdprior';
    wwv_flow_imp.g_varchar2_table(714) := 'ity9 \lsdlocked0 heading 5;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 he';
    wwv_flow_imp.g_varchar2_table(715) := 'ading 6;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 7;'||wwv_flow.LF||
'\lsdsemih';
    wwv_flow_imp.g_varchar2_table(716) := 'idden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 8;\lsdsemihidden1 \lsdunhideus';
    wwv_flow_imp.g_varchar2_table(717) := 'ed1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 9;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 ind';
    wwv_flow_imp.g_varchar2_table(718) := 'ex 1;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(719) := 'd0 index 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 4;\lsdsemihidden1 \lsdunhideused1 \lsdl';
    wwv_flow_imp.g_varchar2_table(720) := 'ocked0 index 5;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 6;\lsdsemihidden1 \lsdunhideused1';
    wwv_flow_imp.g_varchar2_table(721) := ' \lsdlocked0 index 7;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 8;\lsdsemihidden1 \lsdunhideu';
    wwv_flow_imp.g_varchar2_table(722) := 'sed1 \lsdlocked0 index 9;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 1;\lsdsemi';
    wwv_flow_imp.g_varchar2_table(723) := 'hidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 2;\lsdsemihidden1 \lsdunhideused1 \lsdpriorit';
    wwv_flow_imp.g_varchar2_table(724) := 'y39 \lsdlocked0 toc 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 4;\lsdsemihid';
    wwv_flow_imp.g_varchar2_table(725) := 'den1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 5;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39';
    wwv_flow_imp.g_varchar2_table(726) := ' \lsdlocked0 toc 6;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 7;\lsdsemihidden';
    wwv_flow_imp.g_varchar2_table(727) := '1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 8;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \l';
    wwv_flow_imp.g_varchar2_table(728) := 'sdlocked0 toc 9;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Normal Indent;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhi';
    wwv_flow_imp.g_varchar2_table(729) := 'deused1 \lsdlocked0 footnote text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 annotation text;\lsdse';
    wwv_flow_imp.g_varchar2_table(730) := 'mihidden1 \lsdunhideused1 \lsdlocked0 header;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 footer;'||wwv_flow.LF||
'\l';
    wwv_flow_imp.g_varchar2_table(731) := 'sdsemihidden1 \lsdunhideused1 \lsdlocked0 index heading;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1';
    wwv_flow_imp.g_varchar2_table(732) := ' \lsdpriority35 \lsdlocked0 caption;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 table of figures;'||wwv_flow.LF||
'\';
    wwv_flow_imp.g_varchar2_table(733) := 'lsdsemihidden1 \lsdunhideused1 \lsdlocked0 envelope address;\lsdsemihidden1 \lsdunhideused1 \lsdlock';
    wwv_flow_imp.g_varchar2_table(734) := 'ed0 envelope return;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 footnote reference;\lsdsemihidden1 \';
    wwv_flow_imp.g_varchar2_table(735) := 'lsdunhideused1 \lsdlocked0 annotation reference;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 line n';
    wwv_flow_imp.g_varchar2_table(736) := 'umber;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 page number;\lsdsemihidden1 \lsdunhideused1 \lsdlo';
    wwv_flow_imp.g_varchar2_table(737) := 'cked0 endnote reference;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 endnote text;'||wwv_flow.LF||
'\lsdsemihidden1 \';
    wwv_flow_imp.g_varchar2_table(738) := 'lsdunhideused1 \lsdlocked0 table of authorities;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 macro;\l';
    wwv_flow_imp.g_varchar2_table(739) := 'sdsemihidden1 \lsdunhideused1 \lsdlocked0 toa heading;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Li';
    wwv_flow_imp.g_varchar2_table(740) := 'st;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet;\lsdsemihidden1 \lsdunhideused1 \lsdloc';
    wwv_flow_imp.g_varchar2_table(741) := 'ked0 List Number;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List 2;\lsdsemihidden1 \lsdunhideused1 ';
    wwv_flow_imp.g_varchar2_table(742) := '\lsdlocked0 List 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List 4;\lsdsemihidden1 \lsdunhideus';
    wwv_flow_imp.g_varchar2_table(743) := 'ed1 \lsdlocked0 List 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 2;\lsdsemihidden1 \ls';
    wwv_flow_imp.g_varchar2_table(744) := 'dunhideused1 \lsdlocked0 List Bullet 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 4;\';
    wwv_flow_imp.g_varchar2_table(745) := 'lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(746) := ' List Number 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhid';
    wwv_flow_imp.g_varchar2_table(747) := 'eused1 \lsdlocked0 List Number 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number 5;\lsdqform';
    wwv_flow_imp.g_varchar2_table(748) := 'at1 \lsdpriority10 \lsdlocked0 Title;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Closing;'||wwv_flow.LF||
'\lsdsemih';
    wwv_flow_imp.g_varchar2_table(749) := 'idden1 \lsdunhideused1 \lsdlocked0 Signature;\lsdsemihidden1 \lsdunhideused1 \lsdpriority1 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(750) := 'd0 Default Paragraph Font;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text;\lsdsemihidden1 \lsd';
    wwv_flow_imp.g_varchar2_table(751) := 'unhideused1 \lsdlocked0 Body Text Indent;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue';
    wwv_flow_imp.g_varchar2_table(752) := ';\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue 2;\lsdsemihidden1 \lsdunhideused1 \lsdloc';
    wwv_flow_imp.g_varchar2_table(753) := 'ked0 List Continue 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue 4;'||wwv_flow.LF||
'\lsdsemihidden1 \';
    wwv_flow_imp.g_varchar2_table(754) := 'lsdunhideused1 \lsdlocked0 List Continue 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Message Heade';
    wwv_flow_imp.g_varchar2_table(755) := 'r;\lsdqformat1 \lsdpriority11 \lsdlocked0 Subtitle;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Salut';
    wwv_flow_imp.g_varchar2_table(756) := 'ation;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Date;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(757) := ' Body Text First Indent;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text First Indent 2;\lsdsem';
    wwv_flow_imp.g_varchar2_table(758) := 'ihidden1 \lsdunhideused1 \lsdlocked0 Note Heading;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body';
    wwv_flow_imp.g_varchar2_table(759) := ' Text 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text 3;\lsdsemihidden1 \lsdunhideused1 \lsd';
    wwv_flow_imp.g_varchar2_table(760) := 'locked0 Body Text Indent 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text Indent 3;'||wwv_flow.LF||
'\lsdsemi';
    wwv_flow_imp.g_varchar2_table(761) := 'hidden1 \lsdunhideused1 \lsdlocked0 Block Text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Hyperlink';
    wwv_flow_imp.g_varchar2_table(762) := ';\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 FollowedHyperlink;\lsdqformat1 \lsdpriority22 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(763) := 'd0 Strong;'||wwv_flow.LF||
'\lsdqformat1 \lsdpriority20 \lsdlocked0 Emphasis;\lsdsemihidden1 \lsdunhideused1 \lsdloc';
    wwv_flow_imp.g_varchar2_table(764) := 'ked0 Document Map;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Plain Text;\lsdsemihidden1 \lsdunhideu';
    wwv_flow_imp.g_varchar2_table(765) := 'sed1 \lsdlocked0 E-mail Signature;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Top of Form;\ls';
    wwv_flow_imp.g_varchar2_table(766) := 'dsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Bottom of Form;\lsdsemihidden1 \lsdunhideused1 \lsdloc';
    wwv_flow_imp.g_varchar2_table(767) := 'ked0 Normal (Web);\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Acronym;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunh';
    wwv_flow_imp.g_varchar2_table(768) := 'ideused1 \lsdlocked0 HTML Address;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Cite;\lsdsemihidd';
    wwv_flow_imp.g_varchar2_table(769) := 'en1 \lsdunhideused1 \lsdlocked0 HTML Code;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Definitio';
    wwv_flow_imp.g_varchar2_table(770) := 'n;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Keyboard;\lsdsemihidden1 \lsdunhideused1 \lsdlo';
    wwv_flow_imp.g_varchar2_table(771) := 'cked0 HTML Preformatted;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Sample;\lsdsemihidden1 \lsd';
    wwv_flow_imp.g_varchar2_table(772) := 'unhideused1 \lsdlocked0 HTML Typewriter;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Variable;';
    wwv_flow_imp.g_varchar2_table(773) := '\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Normal Table;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(774) := ' annotation subject;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 No List;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhide';
    wwv_flow_imp.g_varchar2_table(775) := 'used1 \lsdlocked0 Outline List 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Outline List 2;\lsdsemi';
    wwv_flow_imp.g_varchar2_table(776) := 'hidden1 \lsdunhideused1 \lsdlocked0 Outline List 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table';
    wwv_flow_imp.g_varchar2_table(777) := ' Simple 1;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Simple 2;\lsdsemihidden1 \lsdunhideuse';
    wwv_flow_imp.g_varchar2_table(778) := 'd1 \lsdlocked0 Table Simple 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Classic 1;\lsdsemihi';
    wwv_flow_imp.g_varchar2_table(779) := 'dden1 \lsdunhideused1 \lsdlocked0 Table Classic 2;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Tabl';
    wwv_flow_imp.g_varchar2_table(780) := 'e Classic 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Classic 4;\lsdsemihidden1 \lsdunhideus';
    wwv_flow_imp.g_varchar2_table(781) := 'ed1 \lsdlocked0 Table Colorful 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Colorful 2;'||wwv_flow.LF||
'\lsd';
    wwv_flow_imp.g_varchar2_table(782) := 'semihidden1 \lsdunhideused1 \lsdlocked0 Table Colorful 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(783) := ' Table Columns 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 2;\lsdsemihidden1 \lsdunh';
    wwv_flow_imp.g_varchar2_table(784) := 'ideused1 \lsdlocked0 Table Columns 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 4;\';
    wwv_flow_imp.g_varchar2_table(785) := 'lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(786) := 'd0 Table Grid 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 2;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhid';
    wwv_flow_imp.g_varchar2_table(787) := 'eused1 \lsdlocked0 Table Grid 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 4;\lsdsemihid';
    wwv_flow_imp.g_varchar2_table(788) := 'den1 \lsdunhideused1 \lsdlocked0 Table Grid 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid';
    wwv_flow_imp.g_varchar2_table(789) := ' 6;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 7;\lsdsemihidden1 \lsdunhideused1 \lsdlo';
    wwv_flow_imp.g_varchar2_table(790) := 'cked0 Table Grid 8;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 1;\lsdsemihidden1 \lsdunhi';
    wwv_flow_imp.g_varchar2_table(791) := 'deused1 \lsdlocked0 Table List 2;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 3;\lsdsemi';
    wwv_flow_imp.g_varchar2_table(792) := 'hidden1 \lsdunhideused1 \lsdlocked0 Table List 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table L';
    wwv_flow_imp.g_varchar2_table(793) := 'ist 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 6;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \ls';
    wwv_flow_imp.g_varchar2_table(794) := 'dlocked0 Table List 7;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 8;\lsdsemihidden1 \lsdu';
    wwv_flow_imp.g_varchar2_table(795) := 'nhideused1 \lsdlocked0 Table 3D effects 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table 3D effec';
    wwv_flow_imp.g_varchar2_table(796) := 'ts 2;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table 3D effects 3;\lsdsemihidden1 \lsdunhideused';
    wwv_flow_imp.g_varchar2_table(797) := '1 \lsdlocked0 Table Contemporary;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Elegant;\lsdsemih';
    wwv_flow_imp.g_varchar2_table(798) := 'idden1 \lsdunhideused1 \lsdlocked0 Table Professional;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(799) := 'Table Subtle 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Subtle 2;\lsdsemihidden1 \lsdunhide';
    wwv_flow_imp.g_varchar2_table(800) := 'used1 \lsdlocked0 Table Web 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Web 2;'||wwv_flow.LF||
'\lsdsemihidd';
    wwv_flow_imp.g_varchar2_table(801) := 'en1 \lsdunhideused1 \lsdlocked0 Table Web 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Balloon Text';
    wwv_flow_imp.g_varchar2_table(802) := ';\lsdpriority39 \lsdlocked0 Table Grid;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Theme;\lsds';
    wwv_flow_imp.g_varchar2_table(803) := 'emihidden1 \lsdlocked0 Placeholder Text;'||wwv_flow.LF||
'\lsdqformat1 \lsdpriority1 \lsdlocked0 No Spacing;\lsdprio';
    wwv_flow_imp.g_varchar2_table(804) := 'rity60 \lsdlocked0 Light Shading;\lsdpriority61 \lsdlocked0 Light List;\lsdpriority62 \lsdlocked0 Li';
    wwv_flow_imp.g_varchar2_table(805) := 'ght Grid;\lsdpriority63 \lsdlocked0 Medium Shading 1;\lsdpriority64 \lsdlocked0 Medium Shading 2;'||wwv_flow.LF||
'\';
    wwv_flow_imp.g_varchar2_table(806) := 'lsdpriority65 \lsdlocked0 Medium List 1;\lsdpriority66 \lsdlocked0 Medium List 2;\lsdpriority67 \lsd';
    wwv_flow_imp.g_varchar2_table(807) := 'locked0 Medium Grid 1;\lsdpriority68 \lsdlocked0 Medium Grid 2;\lsdpriority69 \lsdlocked0 Medium Gri';
    wwv_flow_imp.g_varchar2_table(808) := 'd 3;\lsdpriority70 \lsdlocked0 Dark List;'||wwv_flow.LF||
'\lsdpriority71 \lsdlocked0 Colorful Shading;\lsdpriority7';
    wwv_flow_imp.g_varchar2_table(809) := '2 \lsdlocked0 Colorful List;\lsdpriority73 \lsdlocked0 Colorful Grid;\lsdpriority60 \lsdlocked0 Ligh';
    wwv_flow_imp.g_varchar2_table(810) := 't Shading Accent 1;\lsdpriority61 \lsdlocked0 Light List Accent 1;'||wwv_flow.LF||
'\lsdpriority62 \lsdlocked0 Light';
    wwv_flow_imp.g_varchar2_table(811) := ' Grid Accent 1;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 1;\lsdpriority64 \lsdlocked0 Mediu';
    wwv_flow_imp.g_varchar2_table(812) := 'm Shading 2 Accent 1;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 1;\lsdsemihidden1 \lsdlocked0 R';
    wwv_flow_imp.g_varchar2_table(813) := 'evision;'||wwv_flow.LF||
'\lsdqformat1 \lsdpriority34 \lsdlocked0 List Paragraph;\lsdqformat1 \lsdpriority29 \lsdloc';
    wwv_flow_imp.g_varchar2_table(814) := 'ked0 Quote;\lsdqformat1 \lsdpriority30 \lsdlocked0 Intense Quote;\lsdpriority66 \lsdlocked0 Medium L';
    wwv_flow_imp.g_varchar2_table(815) := 'ist 2 Accent 1;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 1;'||wwv_flow.LF||
'\lsdpriority68 \lsdlocked0 Medium';
    wwv_flow_imp.g_varchar2_table(816) := ' Grid 2 Accent 1;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 1;\lsdpriority70 \lsdlocked0 Dark L';
    wwv_flow_imp.g_varchar2_table(817) := 'ist Accent 1;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 1;\lsdpriority72 \lsdlocked0 Colorfu';
    wwv_flow_imp.g_varchar2_table(818) := 'l List Accent 1;'||wwv_flow.LF||
'\lsdpriority73 \lsdlocked0 Colorful Grid Accent 1;\lsdpriority60 \lsdlocked0 Light';
    wwv_flow_imp.g_varchar2_table(819) := ' Shading Accent 2;\lsdpriority61 \lsdlocked0 Light List Accent 2;\lsdpriority62 \lsdlocked0 Light Gr';
    wwv_flow_imp.g_varchar2_table(820) := 'id Accent 2;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 2;'||wwv_flow.LF||
'\lsdpriority64 \lsdlocked0 Medium';
    wwv_flow_imp.g_varchar2_table(821) := ' Shading 2 Accent 2;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 2;\lsdpriority66 \lsdlocked0 Med';
    wwv_flow_imp.g_varchar2_table(822) := 'ium List 2 Accent 2;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 2;\lsdpriority68 \lsdlocked0 Med';
    wwv_flow_imp.g_varchar2_table(823) := 'ium Grid 2 Accent 2;'||wwv_flow.LF||
'\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 2;\lsdpriority70 \lsdlocked0 D';
    wwv_flow_imp.g_varchar2_table(824) := 'ark List Accent 2;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 2;\lsdpriority72 \lsdlocked0 Co';
    wwv_flow_imp.g_varchar2_table(825) := 'lorful List Accent 2;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 2;'||wwv_flow.LF||
'\lsdpriority60 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(826) := 'Light Shading Accent 3;\lsdpriority61 \lsdlocked0 Light List Accent 3;\lsdpriority62 \lsdlocked0 Lig';
    wwv_flow_imp.g_varchar2_table(827) := 'ht Grid Accent 3;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 3;\lsdpriority64 \lsdlocked0 Med';
    wwv_flow_imp.g_varchar2_table(828) := 'ium Shading 2 Accent 3;'||wwv_flow.LF||
'\lsdpriority65 \lsdlocked0 Medium List 1 Accent 3;\lsdpriority66 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(829) := '0 Medium List 2 Accent 3;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 3;\lsdpriority68 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(830) := '0 Medium Grid 2 Accent 3;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 3;'||wwv_flow.LF||
'\lsdpriority70 \lsdlock';
    wwv_flow_imp.g_varchar2_table(831) := 'ed0 Dark List Accent 3;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 3;\lsdpriority72 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(832) := 'd0 Colorful List Accent 3;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 3;\lsdpriority60 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(833) := 'd0 Light Shading Accent 4;'||wwv_flow.LF||
'\lsdpriority61 \lsdlocked0 Light List Accent 4;\lsdpriority62 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(834) := '0 Light Grid Accent 4;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 4;\lsdpriority64 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(835) := '0 Medium Shading 2 Accent 4;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 4;'||wwv_flow.LF||
'\lsdpriority66 \lsdl';
    wwv_flow_imp.g_varchar2_table(836) := 'ocked0 Medium List 2 Accent 4;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 4;\lsdpriority68 \lsdl';
    wwv_flow_imp.g_varchar2_table(837) := 'ocked0 Medium Grid 2 Accent 4;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 4;\lsdpriority70 \lsdl';
    wwv_flow_imp.g_varchar2_table(838) := 'ocked0 Dark List Accent 4;'||wwv_flow.LF||
'\lsdpriority71 \lsdlocked0 Colorful Shading Accent 4;\lsdpriority72 \lsd';
    wwv_flow_imp.g_varchar2_table(839) := 'locked0 Colorful List Accent 4;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 4;\lsdpriority60 \lsd';
    wwv_flow_imp.g_varchar2_table(840) := 'locked0 Light Shading Accent 5;\lsdpriority61 \lsdlocked0 Light List Accent 5;'||wwv_flow.LF||
'\lsdpriority62 \lsdl';
    wwv_flow_imp.g_varchar2_table(841) := 'ocked0 Light Grid Accent 5;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 5;\lsdpriority64 \lsdl';
    wwv_flow_imp.g_varchar2_table(842) := 'ocked0 Medium Shading 2 Accent 5;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 5;\lsdpriority66 \l';
    wwv_flow_imp.g_varchar2_table(843) := 'sdlocked0 Medium List 2 Accent 5;'||wwv_flow.LF||
'\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 5;\lsdpriority68 ';
    wwv_flow_imp.g_varchar2_table(844) := '\lsdlocked0 Medium Grid 2 Accent 5;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 5;\lsdpriority70 ';
    wwv_flow_imp.g_varchar2_table(845) := '\lsdlocked0 Dark List Accent 5;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 5;'||wwv_flow.LF||
'\lsdpriority72';
    wwv_flow_imp.g_varchar2_table(846) := ' \lsdlocked0 Colorful List Accent 5;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 5;\lsdpriority60';
    wwv_flow_imp.g_varchar2_table(847) := ' \lsdlocked0 Light Shading Accent 6;\lsdpriority61 \lsdlocked0 Light List Accent 6;\lsdpriority62 \l';
    wwv_flow_imp.g_varchar2_table(848) := 'sdlocked0 Light Grid Accent 6;'||wwv_flow.LF||
'\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 6;\lsdpriority64 ';
    wwv_flow_imp.g_varchar2_table(849) := '\lsdlocked0 Medium Shading 2 Accent 6;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 6;\lsdpriority';
    wwv_flow_imp.g_varchar2_table(850) := '66 \lsdlocked0 Medium List 2 Accent 6;'||wwv_flow.LF||
'\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 6;\lsdpriori';
    wwv_flow_imp.g_varchar2_table(851) := 'ty68 \lsdlocked0 Medium Grid 2 Accent 6;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 6;\lsdpriori';
    wwv_flow_imp.g_varchar2_table(852) := 'ty70 \lsdlocked0 Dark List Accent 6;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 6;'||wwv_flow.LF||
'\lsdprior';
    wwv_flow_imp.g_varchar2_table(853) := 'ity72 \lsdlocked0 Colorful List Accent 6;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 6;\lsdqform';
    wwv_flow_imp.g_varchar2_table(854) := 'at1 \lsdpriority19 \lsdlocked0 Subtle Emphasis;\lsdqformat1 \lsdpriority21 \lsdlocked0 Intense Empha';
    wwv_flow_imp.g_varchar2_table(855) := 'sis;'||wwv_flow.LF||
'\lsdqformat1 \lsdpriority31 \lsdlocked0 Subtle Reference;\lsdqformat1 \lsdpriority32 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(856) := 'd0 Intense Reference;\lsdqformat1 \lsdpriority33 \lsdlocked0 Book Title;\lsdsemihidden1 \lsdunhideus';
    wwv_flow_imp.g_varchar2_table(857) := 'ed1 \lsdpriority37 \lsdlocked0 Bibliography;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdprior';
    wwv_flow_imp.g_varchar2_table(858) := 'ity39 \lsdlocked0 TOC Heading;\lsdpriority41 \lsdlocked0 Plain Table 1;\lsdpriority42 \lsdlocked0 Pl';
    wwv_flow_imp.g_varchar2_table(859) := 'ain Table 2;\lsdpriority43 \lsdlocked0 Plain Table 3;\lsdpriority44 \lsdlocked0 Plain Table 4;'||wwv_flow.LF||
'\lsd';
    wwv_flow_imp.g_varchar2_table(860) := 'priority45 \lsdlocked0 Plain Table 5;\lsdpriority40 \lsdlocked0 Grid Table Light;\lsdpriority46 \lsd';
    wwv_flow_imp.g_varchar2_table(861) := 'locked0 Grid Table 1 Light;\lsdpriority47 \lsdlocked0 Grid Table 2;\lsdpriority48 \lsdlocked0 Grid T';
    wwv_flow_imp.g_varchar2_table(862) := 'able 3;\lsdpriority49 \lsdlocked0 Grid Table 4;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 Grid Table 5 Dark;\lsdpr';
    wwv_flow_imp.g_varchar2_table(863) := 'iority51 \lsdlocked0 Grid Table 6 Colorful;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful;\lsdprio';
    wwv_flow_imp.g_varchar2_table(864) := 'rity46 \lsdlocked0 Grid Table 1 Light Accent 1;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 1;'||wwv_flow.LF||
'\l';
    wwv_flow_imp.g_varchar2_table(865) := 'sdpriority48 \lsdlocked0 Grid Table 3 Accent 1;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 1;\lsd';
    wwv_flow_imp.g_varchar2_table(866) := 'priority50 \lsdlocked0 Grid Table 5 Dark Accent 1;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful A';
    wwv_flow_imp.g_varchar2_table(867) := 'ccent 1;'||wwv_flow.LF||
'\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 1;\lsdpriority46 \lsdlocked0 Grid ';
    wwv_flow_imp.g_varchar2_table(868) := 'Table 1 Light Accent 2;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 2;\lsdpriority48 \lsdlocked0 G';
    wwv_flow_imp.g_varchar2_table(869) := 'rid Table 3 Accent 2;'||wwv_flow.LF||
'\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 2;\lsdpriority50 \lsdlocked0 G';
    wwv_flow_imp.g_varchar2_table(870) := 'rid Table 5 Dark Accent 2;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 2;\lsdpriority52 \';
    wwv_flow_imp.g_varchar2_table(871) := 'lsdlocked0 Grid Table 7 Colorful Accent 2;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 3;\';
    wwv_flow_imp.g_varchar2_table(872) := 'lsdpriority47 \lsdlocked0 Grid Table 2 Accent 3;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 3;\ls';
    wwv_flow_imp.g_varchar2_table(873) := 'dpriority49 \lsdlocked0 Grid Table 4 Accent 3;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent ';
    wwv_flow_imp.g_varchar2_table(874) := '3;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 3;\lsdpriority52 \lsdlocked0 Grid Table 7 ';
    wwv_flow_imp.g_varchar2_table(875) := 'Colorful Accent 3;\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 4;'||wwv_flow.LF||
'\lsdpriority47 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(876) := '0 Grid Table 2 Accent 4;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 4;\lsdpriority49 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(877) := 'Grid Table 4 Accent 4;\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 4;'||wwv_flow.LF||
'\lsdpriority51 \lsdloc';
    wwv_flow_imp.g_varchar2_table(878) := 'ked0 Grid Table 6 Colorful Accent 4;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 4;\lsdpr';
    wwv_flow_imp.g_varchar2_table(879) := 'iority46 \lsdlocked0 Grid Table 1 Light Accent 5;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 5;'||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(880) := '\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 5;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 5;\l';
    wwv_flow_imp.g_varchar2_table(881) := 'sdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 5;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful';
    wwv_flow_imp.g_varchar2_table(882) := ' Accent 5;'||wwv_flow.LF||
'\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 5;\lsdpriority46 \lsdlocked0 Gri';
    wwv_flow_imp.g_varchar2_table(883) := 'd Table 1 Light Accent 6;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 6;\lsdpriority48 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(884) := ' Grid Table 3 Accent 6;'||wwv_flow.LF||
'\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 6;\lsdpriority50 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(885) := ' Grid Table 5 Dark Accent 6;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 6;\lsdpriority52';
    wwv_flow_imp.g_varchar2_table(886) := ' \lsdlocked0 Grid Table 7 Colorful Accent 6;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 List Table 1 Light;\lsdprio';
    wwv_flow_imp.g_varchar2_table(887) := 'rity47 \lsdlocked0 List Table 2;\lsdpriority48 \lsdlocked0 List Table 3;\lsdpriority49 \lsdlocked0 L';
    wwv_flow_imp.g_varchar2_table(888) := 'ist Table 4;\lsdpriority50 \lsdlocked0 List Table 5 Dark;'||wwv_flow.LF||
'\lsdpriority51 \lsdlocked0 List Table 6 C';
    wwv_flow_imp.g_varchar2_table(889) := 'olorful;\lsdpriority52 \lsdlocked0 List Table 7 Colorful;\lsdpriority46 \lsdlocked0 List Table 1 Lig';
    wwv_flow_imp.g_varchar2_table(890) := 'ht Accent 1;\lsdpriority47 \lsdlocked0 List Table 2 Accent 1;\lsdpriority48 \lsdlocked0 List Table 3';
    wwv_flow_imp.g_varchar2_table(891) := ' Accent 1;'||wwv_flow.LF||
'\lsdpriority49 \lsdlocked0 List Table 4 Accent 1;\lsdpriority50 \lsdlocked0 List Table 5';
    wwv_flow_imp.g_varchar2_table(892) := ' Dark Accent 1;\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 1;\lsdpriority52 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(893) := 'List Table 7 Colorful Accent 1;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 2;\lsdpriority';
    wwv_flow_imp.g_varchar2_table(894) := '47 \lsdlocked0 List Table 2 Accent 2;\lsdpriority48 \lsdlocked0 List Table 3 Accent 2;\lsdpriority49';
    wwv_flow_imp.g_varchar2_table(895) := ' \lsdlocked0 List Table 4 Accent 2;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 2;\lsdprior';
    wwv_flow_imp.g_varchar2_table(896) := 'ity51 \lsdlocked0 List Table 6 Colorful Accent 2;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Ac';
    wwv_flow_imp.g_varchar2_table(897) := 'cent 2;\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 3;'||wwv_flow.LF||
'\lsdpriority47 \lsdlocked0 List Tabl';
    wwv_flow_imp.g_varchar2_table(898) := 'e 2 Accent 3;\lsdpriority48 \lsdlocked0 List Table 3 Accent 3;\lsdpriority49 \lsdlocked0 List Table ';
    wwv_flow_imp.g_varchar2_table(899) := '4 Accent 3;\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 3;'||wwv_flow.LF||
'\lsdpriority51 \lsdlocked0 List T';
    wwv_flow_imp.g_varchar2_table(900) := 'able 6 Colorful Accent 3;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 3;\lsdpriority46 \l';
    wwv_flow_imp.g_varchar2_table(901) := 'sdlocked0 List Table 1 Light Accent 4;\lsdpriority47 \lsdlocked0 List Table 2 Accent 4;'||wwv_flow.LF||
'\lsdpriorit';
    wwv_flow_imp.g_varchar2_table(902) := 'y48 \lsdlocked0 List Table 3 Accent 4;\lsdpriority49 \lsdlocked0 List Table 4 Accent 4;\lsdpriority5';
    wwv_flow_imp.g_varchar2_table(903) := '0 \lsdlocked0 List Table 5 Dark Accent 4;\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 4;';
    wwv_flow_imp.g_varchar2_table(904) := ''||wwv_flow.LF||
'\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 4;\lsdpriority46 \lsdlocked0 List Table 1 L';
    wwv_flow_imp.g_varchar2_table(905) := 'ight Accent 5;\lsdpriority47 \lsdlocked0 List Table 2 Accent 5;\lsdpriority48 \lsdlocked0 List Table';
    wwv_flow_imp.g_varchar2_table(906) := ' 3 Accent 5;'||wwv_flow.LF||
'\lsdpriority49 \lsdlocked0 List Table 4 Accent 5;\lsdpriority50 \lsdlocked0 List Table';
    wwv_flow_imp.g_varchar2_table(907) := ' 5 Dark Accent 5;\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 5;\lsdpriority52 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(908) := '0 List Table 7 Colorful Accent 5;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 6;\lsdpriori';
    wwv_flow_imp.g_varchar2_table(909) := 'ty47 \lsdlocked0 List Table 2 Accent 6;\lsdpriority48 \lsdlocked0 List Table 3 Accent 6;\lsdpriority';
    wwv_flow_imp.g_varchar2_table(910) := '49 \lsdlocked0 List Table 4 Accent 6;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 6;\lsdpri';
    wwv_flow_imp.g_varchar2_table(911) := 'ority51 \lsdlocked0 List Table 6 Colorful Accent 6;\lsdpriority52 \lsdlocked0 List Table 7 Colorful ';
    wwv_flow_imp.g_varchar2_table(912) := 'Accent 6;}}{\*\datastore 010500000200000018000000'||wwv_flow.LF||
'4d73786d6c322e534158584d4c5265616465722e362e30000';
    wwv_flow_imp.g_varchar2_table(913) := '00000000000000000060000'||wwv_flow.LF||
'd0cf11e0a1b11ae1000000000000000000000000000000003e000300feff090006000000000';
    wwv_flow_imp.g_varchar2_table(914) := '000000000000001000000010000000000000000100000feffffff00000000feffffff0000000000000000fffffffffffffff';
    wwv_flow_imp.g_varchar2_table(915) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(916) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(917) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(918) := 'fffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(919) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(920) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffff';
    wwv_flow_imp.g_varchar2_table(921) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(922) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(923) := 'fffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffdfffffffefffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(924) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(925) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffff';
    wwv_flow_imp.g_varchar2_table(926) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(927) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(928) := 'fffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(929) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(930) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(931) := 'f'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(932) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(933) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffff52006f006f0';
    wwv_flow_imp.g_varchar2_table(934) := '07400200045006e0074007200790000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(935) := '0000000000000000016000500ffffffffffffffffffffffff0c6ad98892f1d411a65f0040963251e50000000000000000000';
    wwv_flow_imp.g_varchar2_table(936) := '0000030e7'||wwv_flow.LF||
'c0a39893d801feffffff000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(937) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000fffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(938) := 'fffffff00000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(939) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(940) := '00000000000000000000000000000000000000000ffffffffffffffffffffffff00000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(941) := '00000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(942) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000f';
    wwv_flow_imp.g_varchar2_table(943) := 'fffffffffffffffffffffff000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(944) := '0000000000000000000000105000000000000}}';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_report_layout(
 p_id=>wwv_flow_imp.id(30571778573879384467)
,p_report_layout_name=>'Balance_sheet'
,p_report_layout_type=>'RTF_FILE'
,p_varchar2_table=>wwv_flow_imp.g_varchar2_table
);
null;
wwv_flow_imp.component_end;
end;
/
