prompt --application/shared_components/reports/report_layouts/ledger_report_parameter
begin
--   Manifest
--     REPORT LAYOUT: Ledger_Report_parameter
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
    wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
    wwv_flow_imp.g_varchar2_table(1) := '{\rtf1\adeflang1025\ansi\ansicpg1252\uc1\adeff31507\deff0\stshfdbch31506\stshfloch31506\stshfhich315';
    wwv_flow_imp.g_varchar2_table(2) := '06\stshfbi31507\deflang1033\deflangfe1033\themelang1033\themelangfe0\themelangcs0{\fonttbl{\f0\fbidi';
    wwv_flow_imp.g_varchar2_table(3) := ' \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\f0\fbidi \froman\fcharset';
    wwv_flow_imp.g_varchar2_table(4) := '0\fprq2{\*\panose 02020603050405020304}Times New Roman;}'||wwv_flow.LF||
'{\f39\fbidi \fswiss\fcharset0\fprq2{\*\pan';
    wwv_flow_imp.g_varchar2_table(5) := 'ose 020f0502020204030204}Calibri;}{\flomajor\f31500\fbidi \froman\fcharset0\fprq2{\*\panose 02020603';
    wwv_flow_imp.g_varchar2_table(6) := '050405020304}Times New Roman;}'||wwv_flow.LF||
'{\fdbmajor\f31501\fbidi \froman\fcharset0\fprq2{\*\panose 0202060305';
    wwv_flow_imp.g_varchar2_table(7) := '0405020304}Times New Roman;}{\fhimajor\f31502\fbidi \fswiss\fcharset0\fprq2{\*\panose 020f0302020204';
    wwv_flow_imp.g_varchar2_table(8) := '030204}Calibri Light;}'||wwv_flow.LF||
'{\fbimajor\f31503\fbidi \froman\fcharset0\fprq2{\*\panose 020206030504050203';
    wwv_flow_imp.g_varchar2_table(9) := '04}Times New Roman;}{\flominor\f31504\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}T';
    wwv_flow_imp.g_varchar2_table(10) := 'imes New Roman;}'||wwv_flow.LF||
'{\fdbminor\f31505\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Tim';
    wwv_flow_imp.g_varchar2_table(11) := 'es New Roman;}{\fhiminor\f31506\fbidi \fswiss\fcharset0\fprq2{\*\panose 020f0502020204030204}Calibri';
    wwv_flow_imp.g_varchar2_table(12) := ';}'||wwv_flow.LF||
'{\fbiminor\f31507\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}';
    wwv_flow_imp.g_varchar2_table(13) := '{\f41\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\f42\fbidi \froman\fcharset204\fprq2 Time';
    wwv_flow_imp.g_varchar2_table(14) := 's New Roman Cyr;}'||wwv_flow.LF||
'{\f44\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\f45\fbidi \froman\';
    wwv_flow_imp.g_varchar2_table(15) := 'fcharset162\fprq2 Times New Roman Tur;}{\f46\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew';
    wwv_flow_imp.g_varchar2_table(16) := ');}{\f47\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\f48\fbidi \froman\fcharset186';
    wwv_flow_imp.g_varchar2_table(17) := '\fprq2 Times New Roman Baltic;}{\f49\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{';
    wwv_flow_imp.g_varchar2_table(18) := '\f41\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\f42\fbidi \froman\fcharset204\fprq2 Times';
    wwv_flow_imp.g_varchar2_table(19) := ' New Roman Cyr;}'||wwv_flow.LF||
'{\f44\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\f45\fbidi \froman\f';
    wwv_flow_imp.g_varchar2_table(20) := 'charset162\fprq2 Times New Roman Tur;}{\f46\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew)';
    wwv_flow_imp.g_varchar2_table(21) := ';}{\f47\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\f48\fbidi \froman\fcharset186\';
    wwv_flow_imp.g_varchar2_table(22) := 'fprq2 Times New Roman Baltic;}{\f49\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\';
    wwv_flow_imp.g_varchar2_table(23) := 'f431\fbidi \fswiss\fcharset238\fprq2 Calibri CE;}{\f432\fbidi \fswiss\fcharset204\fprq2 Calibri Cyr;';
    wwv_flow_imp.g_varchar2_table(24) := '}'||wwv_flow.LF||
'{\f434\fbidi \fswiss\fcharset161\fprq2 Calibri Greek;}{\f435\fbidi \fswiss\fcharset162\fprq2 Cali';
    wwv_flow_imp.g_varchar2_table(25) := 'bri Tur;}{\f436\fbidi \fswiss\fcharset177\fprq2 Calibri (Hebrew);}{\f437\fbidi \fswiss\fcharset178\f';
    wwv_flow_imp.g_varchar2_table(26) := 'prq2 Calibri (Arabic);}'||wwv_flow.LF||
'{\f438\fbidi \fswiss\fcharset186\fprq2 Calibri Baltic;}{\f439\fbidi \fswiss';
    wwv_flow_imp.g_varchar2_table(27) := '\fcharset163\fprq2 Calibri (Vietnamese);}{\flomajor\f31508\fbidi \froman\fcharset238\fprq2 Times New';
    wwv_flow_imp.g_varchar2_table(28) := ' Roman CE;}'||wwv_flow.LF||
'{\flomajor\f31509\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\flomajor\f3151';
    wwv_flow_imp.g_varchar2_table(29) := '1\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\flomajor\f31512\fbidi \froman\fcharset162';
    wwv_flow_imp.g_varchar2_table(30) := '\fprq2 Times New Roman Tur;}'||wwv_flow.LF||
'{\flomajor\f31513\fbidi \froman\fcharset177\fprq2 Times New Roman (Heb';
    wwv_flow_imp.g_varchar2_table(31) := 'rew);}{\flomajor\f31514\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\flomajor\f31515\';
    wwv_flow_imp.g_varchar2_table(32) := 'fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}'||wwv_flow.LF||
'{\flomajor\f31516\fbidi \froman\fcharset16';
    wwv_flow_imp.g_varchar2_table(33) := '3\fprq2 Times New Roman (Vietnamese);}{\fdbmajor\f31518\fbidi \froman\fcharset238\fprq2 Times New Ro';
    wwv_flow_imp.g_varchar2_table(34) := 'man CE;}{\fdbmajor\f31519\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\fdbmajor\f31521\f';
    wwv_flow_imp.g_varchar2_table(35) := 'bidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\fdbmajor\f31522\fbidi \froman\fcharset162\fp';
    wwv_flow_imp.g_varchar2_table(36) := 'rq2 Times New Roman Tur;}{\fdbmajor\f31523\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);';
    wwv_flow_imp.g_varchar2_table(37) := '}'||wwv_flow.LF||
'{\fdbmajor\f31524\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\fdbmajor\f31525\fbi';
    wwv_flow_imp.g_varchar2_table(38) := 'di \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fdbmajor\f31526\fbidi \froman\fcharset163\fpr';
    wwv_flow_imp.g_varchar2_table(39) := 'q2 Times New Roman (Vietnamese);}'||wwv_flow.LF||
'{\fhimajor\f31528\fbidi \fswiss\fcharset238\fprq2 Calibri Light C';
    wwv_flow_imp.g_varchar2_table(40) := 'E;}{\fhimajor\f31529\fbidi \fswiss\fcharset204\fprq2 Calibri Light Cyr;}{\fhimajor\f31531\fbidi \fsw';
    wwv_flow_imp.g_varchar2_table(41) := 'iss\fcharset161\fprq2 Calibri Light Greek;}'||wwv_flow.LF||
'{\fhimajor\f31532\fbidi \fswiss\fcharset162\fprq2 Calib';
    wwv_flow_imp.g_varchar2_table(42) := 'ri Light Tur;}{\fhimajor\f31533\fbidi \fswiss\fcharset177\fprq2 Calibri Light (Hebrew);}{\fhimajor\f';
    wwv_flow_imp.g_varchar2_table(43) := '31534\fbidi \fswiss\fcharset178\fprq2 Calibri Light (Arabic);}'||wwv_flow.LF||
'{\fhimajor\f31535\fbidi \fswiss\fcha';
    wwv_flow_imp.g_varchar2_table(44) := 'rset186\fprq2 Calibri Light Baltic;}{\fhimajor\f31536\fbidi \fswiss\fcharset163\fprq2 Calibri Light ';
    wwv_flow_imp.g_varchar2_table(45) := '(Vietnamese);}{\fbimajor\f31538\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}'||wwv_flow.LF||
'{\fbimajor\f31';
    wwv_flow_imp.g_varchar2_table(46) := '539\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\fbimajor\f31541\fbidi \froman\fcharset161';
    wwv_flow_imp.g_varchar2_table(47) := '\fprq2 Times New Roman Greek;}{\fbimajor\f31542\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;';
    wwv_flow_imp.g_varchar2_table(48) := '}'||wwv_flow.LF||
'{\fbimajor\f31543\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\fbimajor\f31544\fbi';
    wwv_flow_imp.g_varchar2_table(49) := 'di \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\fbimajor\f31545\fbidi \froman\fcharset186\f';
    wwv_flow_imp.g_varchar2_table(50) := 'prq2 Times New Roman Baltic;}'||wwv_flow.LF||
'{\fbimajor\f31546\fbidi \froman\fcharset163\fprq2 Times New Roman (Vi';
    wwv_flow_imp.g_varchar2_table(51) := 'etnamese);}{\flominor\f31548\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\flominor\f31549\f';
    wwv_flow_imp.g_varchar2_table(52) := 'bidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\flominor\f31551\fbidi \froman\fcharset161\fp';
    wwv_flow_imp.g_varchar2_table(53) := 'rq2 Times New Roman Greek;}{\flominor\f31552\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\';
    wwv_flow_imp.g_varchar2_table(54) := 'flominor\f31553\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}'||wwv_flow.LF||
'{\flominor\f31554\fbidi ';
    wwv_flow_imp.g_varchar2_table(55) := '\froman\fcharset178\fprq2 Times New Roman (Arabic);}{\flominor\f31555\fbidi \froman\fcharset186\fprq';
    wwv_flow_imp.g_varchar2_table(56) := '2 Times New Roman Baltic;}{\flominor\f31556\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnam';
    wwv_flow_imp.g_varchar2_table(57) := 'ese);}'||wwv_flow.LF||
'{\fdbminor\f31558\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\fdbminor\f31559\fbid';
    wwv_flow_imp.g_varchar2_table(58) := 'i \froman\fcharset204\fprq2 Times New Roman Cyr;}{\fdbminor\f31561\fbidi \froman\fcharset161\fprq2 T';
    wwv_flow_imp.g_varchar2_table(59) := 'imes New Roman Greek;}'||wwv_flow.LF||
'{\fdbminor\f31562\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\fdb';
    wwv_flow_imp.g_varchar2_table(60) := 'minor\f31563\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\fdbminor\f31564\fbidi \from';
    wwv_flow_imp.g_varchar2_table(61) := 'an\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\fdbminor\f31565\fbidi \froman\fcharset186\fprq2 T';
    wwv_flow_imp.g_varchar2_table(62) := 'imes New Roman Baltic;}{\fdbminor\f31566\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese';
    wwv_flow_imp.g_varchar2_table(63) := ');}{\fhiminor\f31568\fbidi \fswiss\fcharset238\fprq2 Calibri CE;}'||wwv_flow.LF||
'{\fhiminor\f31569\fbidi \fswiss\f';
    wwv_flow_imp.g_varchar2_table(64) := 'charset204\fprq2 Calibri Cyr;}{\fhiminor\f31571\fbidi \fswiss\fcharset161\fprq2 Calibri Greek;}{\fhi';
    wwv_flow_imp.g_varchar2_table(65) := 'minor\f31572\fbidi \fswiss\fcharset162\fprq2 Calibri Tur;}'||wwv_flow.LF||
'{\fhiminor\f31573\fbidi \fswiss\fcharset';
    wwv_flow_imp.g_varchar2_table(66) := '177\fprq2 Calibri (Hebrew);}{\fhiminor\f31574\fbidi \fswiss\fcharset178\fprq2 Calibri (Arabic);}{\fh';
    wwv_flow_imp.g_varchar2_table(67) := 'iminor\f31575\fbidi \fswiss\fcharset186\fprq2 Calibri Baltic;}'||wwv_flow.LF||
'{\fhiminor\f31576\fbidi \fswiss\fcha';
    wwv_flow_imp.g_varchar2_table(68) := 'rset163\fprq2 Calibri (Vietnamese);}{\fbiminor\f31578\fbidi \froman\fcharset238\fprq2 Times New Roma';
    wwv_flow_imp.g_varchar2_table(69) := 'n CE;}{\fbiminor\f31579\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\fbiminor\f31581\fbi';
    wwv_flow_imp.g_varchar2_table(70) := 'di \froman\fcharset161\fprq2 Times New Roman Greek;}{\fbiminor\f31582\fbidi \froman\fcharset162\fprq';
    wwv_flow_imp.g_varchar2_table(71) := '2 Times New Roman Tur;}{\fbiminor\f31583\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}';
    wwv_flow_imp.g_varchar2_table(72) := ''||wwv_flow.LF||
'{\fbiminor\f31584\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\fbiminor\f31585\fbidi';
    wwv_flow_imp.g_varchar2_table(73) := ' \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fbiminor\f31586\fbidi \froman\fcharset163\fprq2';
    wwv_flow_imp.g_varchar2_table(74) := ' Times New Roman (Vietnamese);}}'||wwv_flow.LF||
'{\colortbl;\red0\green0\blue0;\red0\green0\blue255;\red0\green255\';
    wwv_flow_imp.g_varchar2_table(75) := 'blue255;\red0\green255\blue0;\red255\green0\blue255;\red255\green0\blue0;\red255\green255\blue0;\red';
    wwv_flow_imp.g_varchar2_table(76) := '255\green255\blue255;\red0\green0\blue128;\red0\green128\blue128;\red0\green128\blue0;'||wwv_flow.LF||
'\red128\gree';
    wwv_flow_imp.g_varchar2_table(77) := 'n0\blue128;\red128\green0\blue0;\red128\green128\blue0;\red128\green128\blue128;\red192\green192\blu';
    wwv_flow_imp.g_varchar2_table(78) := 'e192;\red231\green243\blue253;}{\*\defchp \f31506\fs22 }{\*\defpap \ql \li0\ri0\sa160\sl259\slmult1';
    wwv_flow_imp.g_varchar2_table(79) := ''||wwv_flow.LF||
'\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 }\noqfpromote {\styleshee';
    wwv_flow_imp.g_varchar2_table(80) := 't{\ql \li0\ri0\sa160\sl259\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin';
    wwv_flow_imp.g_varchar2_table(81) := '0\itap0 \rtlch\fcs1 \af31507\afs22\alang1025 '||wwv_flow.LF||
'\ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\la';
    wwv_flow_imp.g_varchar2_table(82) := 'ngnp1033\langfenp1033 \snext0 \sqformat \spriority0 Normal;}{\*\cs10 \additive \ssemihidden \sunhide';
    wwv_flow_imp.g_varchar2_table(83) := 'used \spriority1 Default Paragraph Font;}{\*'||wwv_flow.LF||
'\ts11\tsrowd\trftsWidthB3\trpaddl108\trpaddr108\trpadd';
    wwv_flow_imp.g_varchar2_table(84) := 'fl3\trpaddft3\trpaddfb3\trpaddfr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbr';
    wwv_flow_imp.g_varchar2_table(85) := 'drdgl\tsbrdrdgr\tsbrdrh\tsbrdrv \ql \li0\ri0\sa160\sl259\slmult1'||wwv_flow.LF||
'\widctlpar\wrapdefault\aspalpha\as';
    wwv_flow_imp.g_varchar2_table(86) := 'pnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs2';
    wwv_flow_imp.g_varchar2_table(87) := '2\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \snext11 \ssemihidden \sunhideused Normal Table;';
    wwv_flow_imp.g_varchar2_table(88) := '}{\*\ts15\tsrowd'||wwv_flow.LF||
'\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdr';
    wwv_flow_imp.g_varchar2_table(89) := 's\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidthB3\trpaddl108\trpaddr108\trpadd';
    wwv_flow_imp.g_varchar2_table(90) := 'fl3\trpaddft3\trpaddfb3\trpaddfr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbr';
    wwv_flow_imp.g_varchar2_table(91) := 'drdgl\tsbrdrdgr\tsbrdrh\tsbrdrv '||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustri';
    wwv_flow_imp.g_varchar2_table(92) := 'ght\rin0\lin0\itap0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe103';
    wwv_flow_imp.g_varchar2_table(93) := '3\cgrid\langnp1033\langfenp1033 \sbasedon11 \snext15 \spriority39 \styrsid4068380 '||wwv_flow.LF||
'Table Grid;}}{\*';
    wwv_flow_imp.g_varchar2_table(94) := '\rsidtbl \rsid2632095\rsid4068380}{\mmathPr\mmathFont34\mbrkBin0\mbrkBinSub0\msmallFrac0\mdispDef1\m';
    wwv_flow_imp.g_varchar2_table(95) := 'lMargin0\mrMargin0\mdefJc1\mwrapIndent1440\mintLim0\mnaryLim1}{\info{\author Bappy}{\operator Bappy}';
    wwv_flow_imp.g_varchar2_table(96) := '{\creatim\yr2022\mo5\dy26\min17}'||wwv_flow.LF||
'{\revtim\yr2022\mo5\dy26\min18}{\version1}{\edmins1}{\nofpages1}{\';
    wwv_flow_imp.g_varchar2_table(97) := 'nofwords27}{\nofchars158}{\nofcharsws184}{\vern87}}{\*\xmlnstbl {\xmlns1 http://schemas.microsoft.co';
    wwv_flow_imp.g_varchar2_table(98) := 'm/office/word/2003/wordml}}'||wwv_flow.LF||
'\paperw12240\paperh15840\margl1440\margr1440\margt1440\margb1440\gutter';
    wwv_flow_imp.g_varchar2_table(99) := '0\ltrsect '||wwv_flow.LF||
'\widowctrl\ftnbj\aenddoc\trackmoves0\trackformatting1\donotembedsysfont1\relyonvml1\dono';
    wwv_flow_imp.g_varchar2_table(100) := 'tembedlingdata0\grfdocevents0\validatexml1\showplaceholdtext0\ignoremixedcontent0\saveinvalidxml0\sh';
    wwv_flow_imp.g_varchar2_table(101) := 'owxmlerrors1\noxlattoyen'||wwv_flow.LF||
'\expshrtn\noultrlspc\dntblnsbdb\nospaceforul\formshade\horzdoc\dgmargin\dg';
    wwv_flow_imp.g_varchar2_table(102) := 'hspace180\dgvspace180\dghorigin1440\dgvorigin1440\dghshow1\dgvshow1'||wwv_flow.LF||
'\jexpand\viewkind1\viewscale100';
    wwv_flow_imp.g_varchar2_table(103) := '\pgbrdrhead\pgbrdrfoot\splytwnine\ftnlytwnine\htmautsp\nolnhtadjtbl\useltbaln\alntblind\lytcalctblwd';
    wwv_flow_imp.g_varchar2_table(104) := '\lyttblrtgr\lnbrkrule\nobrkwrptbl\snaptogridincell\allowfieldendsel\wrppunct'||wwv_flow.LF||
'\asianbrkrule\rsidroot';
    wwv_flow_imp.g_varchar2_table(105) := '4068380\newtblstyruls\nogrowautofit\usenormstyforlist\noindnmbrts\felnbrelev\nocxsptable\indrlswelev';
    wwv_flow_imp.g_varchar2_table(106) := 'en\noafcnsttbl\afelev\utinl\hwelev\spltpgpar\notcvasp\notbrkcnstfrctbl\notvatxbx\krnprsnet\cachedcol';
    wwv_flow_imp.g_varchar2_table(107) := 'bal \nouicompat \fet0'||wwv_flow.LF||
'{\*\wgrffmtfilter 2450}\nofeaturethrottle1\ilfomacatclnup0{\*\docvar {xdo0001';
    wwv_flow_imp.g_varchar2_table(108) := '}{PD9mb3ItZWFjaDpST1c/Pg==}}{\*\docvar {xdo0002}{PD9EQVRFX09GX1RSQU5TQUNUSU9OPz4=}}{\*\docvar {xdo00';
    wwv_flow_imp.g_varchar2_table(109) := '03}{PD9OQVJSQVRJT04/Pg==}}{\*\docvar {xdo0004}{PD9ERUJJVD8+}}'||wwv_flow.LF||
'{\*\docvar {xdo0005}{PD9DUkVESVQ/Pg==';
    wwv_flow_imp.g_varchar2_table(110) := '}}{\*\docvar {xdo0006}{PD9lbmQgZm9yLWVhY2g/Pg==}}\ltrpar \sectd \ltrsect\linex0\endnhere\sectlinegri';
    wwv_flow_imp.g_varchar2_table(111) := 'd360\sectdefaultcl\sftnbj {\*\pnseclvl1\pnucrm\pnstart1\pnindent720\pnhang {\pntxta .}}{\*\pnseclvl2';
    wwv_flow_imp.g_varchar2_table(112) := ''||wwv_flow.LF||
'\pnucltr\pnstart1\pnindent720\pnhang {\pntxta .}}{\*\pnseclvl3\pndec\pnstart1\pnindent720\pnhang {';
    wwv_flow_imp.g_varchar2_table(113) := '\pntxta .}}{\*\pnseclvl4\pnlcltr\pnstart1\pnindent720\pnhang {\pntxta )}}{\*\pnseclvl5\pndec\pnstart';
    wwv_flow_imp.g_varchar2_table(114) := '1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnseclvl6'||wwv_flow.LF||
'\pnlcltr\pnstart1\pnindent720\pnhang {\pn';
    wwv_flow_imp.g_varchar2_table(115) := 'txtb (}{\pntxta )}}{\*\pnseclvl7\pnlcrm\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnsec';
    wwv_flow_imp.g_varchar2_table(116) := 'lvl8\pnlcltr\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnseclvl9\pnlcrm\pnstart1\pninde';
    wwv_flow_imp.g_varchar2_table(117) := 'nt720\pnhang '||wwv_flow.LF||
'{\pntxtb (}{\pntxta )}}\pard\plain \ltrpar\qc \li0\ri0\sa160\sl259\slmult1\widctlpar\';
    wwv_flow_imp.g_varchar2_table(118) := 'wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid4068380 \rtlch\fcs1 \af31507\';
    wwv_flow_imp.g_varchar2_table(119) := 'afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch';
    wwv_flow_imp.g_varchar2_table(120) := '\fcs1 \af31507 \ltrch\fcs0 \b\fs32\insrsid4068380\charrsid4068380 Ledger'||wwv_flow.LF||
'\par \ltrrow}\trowd \irow0';
    wwv_flow_imp.g_varchar2_table(121) := '\irowband0\ltrrow\ts15\trgaph108\trleft-108\trhdr\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbr';
    wwv_flow_imp.g_varchar2_table(122) := 'drb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth';
    wwv_flow_imp.g_varchar2_table(123) := '1\trftsWidthB3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid40683';
    wwv_flow_imp.g_varchar2_table(124) := '80\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrs\brdrw10 \cl';
    wwv_flow_imp.g_varchar2_table(125) := 'brdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\';
    wwv_flow_imp.g_varchar2_table(126) := 'clwWidth2337\clcbpatraw17 \cellx2392\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb';
    wwv_flow_imp.g_varchar2_table(127) := '\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth2337\clcbpatraw17 '||wwv_flow.LF||
'\c';
    wwv_flow_imp.g_varchar2_table(128) := 'ellx4729\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdr';
    wwv_flow_imp.g_varchar2_table(129) := 's\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth2338\clcbpatraw17 \cellx7067\clvertalt\clbrdrt\brd';
    wwv_flow_imp.g_varchar2_table(130) := 'rs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrt';
    wwv_flow_imp.g_varchar2_table(131) := 'b\clftsWidth3\clwWidth2338\clcbpatraw17 \cellx9405\pard\plain \ltrpar\ql \li0\ri0\widctlpar\intbl\wr';
    wwv_flow_imp.g_varchar2_table(132) := 'apdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\yts15 \rtlch\fcs1 \af31507\afs22\alang1025 '||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(133) := '\ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \lt';
    wwv_flow_imp.g_varchar2_table(134) := 'rch\fcs0 \b\insrsid4068380 DATE_OF_TRANSACTION}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid4068380\cha';
    wwv_flow_imp.g_varchar2_table(135) := 'rrsid4068380 \cell }{\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\b\insrsid4068380 NARRATION}{\rtlch\fcs1 \af';
    wwv_flow_imp.g_varchar2_table(136) := '31507 \ltrch\fcs0 \insrsid4068380\charrsid4068380 \cell }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \b\insrsi';
    wwv_flow_imp.g_varchar2_table(137) := 'd4068380 DEBIT}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid4068380\charrsid4068380 \cell }{\rtlch\fcs1';
    wwv_flow_imp.g_varchar2_table(138) := ' \af31507 '||wwv_flow.LF||
'\ltrch\fcs0 \b\insrsid4068380 CREDIT}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid4068380\c';
    wwv_flow_imp.g_varchar2_table(139) := 'harrsid4068380 \cell }\pard\plain \ltrpar\ql \li0\ri0\sa160\sl259\slmult1\widctlpar\intbl\wrapdefaul';
    wwv_flow_imp.g_varchar2_table(140) := 't\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 '||wwv_flow.LF||
'\af31507\afs22\alang1025 \ltrch\fcs0 \f';
    wwv_flow_imp.g_varchar2_table(141) := '31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insr';
    wwv_flow_imp.g_varchar2_table(142) := 'sid4068380 \trowd \irow0\irowband0\ltrrow\ts15\trgaph108\trleft-108\trhdr\trbrdrt\brdrs\brdrw10 \trb';
    wwv_flow_imp.g_varchar2_table(143) := 'rdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\b';
    wwv_flow_imp.g_varchar2_table(144) := 'rdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpadd';
    wwv_flow_imp.g_varchar2_table(145) := 'fb3\trpaddfr3\tblrsid4068380\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt';
    wwv_flow_imp.g_varchar2_table(146) := '\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrr\brdrs\brdrw10 \clcbp';
    wwv_flow_imp.g_varchar2_table(147) := 'at17\cltxlrtb\clftsWidth3\clwWidth2337\clcbpatraw17 \cellx2392\clvertalt\clbrdrt\brdrs\brdrw10 \clbr';
    wwv_flow_imp.g_varchar2_table(148) := 'drl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwW';
    wwv_flow_imp.g_varchar2_table(149) := 'idth2337\clcbpatraw17 '||wwv_flow.LF||
'\cellx4729\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\b';
    wwv_flow_imp.g_varchar2_table(150) := 'rdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth2338\clcbpatraw17 \cellx';
    wwv_flow_imp.g_varchar2_table(151) := '7067\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrr\brdrs\';
    wwv_flow_imp.g_varchar2_table(152) := 'brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth2338\clcbpatraw17 \cellx9405\row \ltrrow}\trowd \iro';
    wwv_flow_imp.g_varchar2_table(153) := 'w1\irowband1\lastrow \ltrrow\ts15\trgaph108\trleft-108\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 ';
    wwv_flow_imp.g_varchar2_table(154) := '\trbrdrb\brdrs\brdrw10 '||wwv_flow.LF||
'\trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 \trfts';
    wwv_flow_imp.g_varchar2_table(155) := 'Width1\trftsWidthB3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid';
    wwv_flow_imp.g_varchar2_table(156) := '4068380\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt'||wwv_flow.LF||
'\clbrdrt\brdrs\brdr';
    wwv_flow_imp.g_varchar2_table(157) := 'w10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWi';
    wwv_flow_imp.g_varchar2_table(158) := 'dth2337\clshdrawnil \cellx2392\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs';
    wwv_flow_imp.g_varchar2_table(159) := '\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth2337\clshdrawnil \cellx4729\clvertal';
    wwv_flow_imp.g_varchar2_table(160) := 't\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlr';
    wwv_flow_imp.g_varchar2_table(161) := 'tb\clftsWidth3\clwWidth2338\clshdrawnil \cellx7067\clvertalt\clbrdrt\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrl\brdrs\';
    wwv_flow_imp.g_varchar2_table(162) := 'brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth2338\clshdrawnil';
    wwv_flow_imp.g_varchar2_table(163) := ' \cellx9405\pard\plain \ltrpar\ql \li0\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjust';
    wwv_flow_imp.g_varchar2_table(164) := 'right\rin0\lin0\pararsid4068380\yts15 '||wwv_flow.LF||
'\rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs2';
    wwv_flow_imp.g_varchar2_table(165) := '2\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\field\flddirty{\*\fldinst {\rtlch\fcs1 \af3150';
    wwv_flow_imp.g_varchar2_table(166) := '7 \ltrch\fcs0 \cf9\insrsid4068380\charrsid4068380 {\*\bkmkstart Text1} FORMTEXT }{\rtlch\fcs1 '||wwv_flow.LF||
'\af3';
    wwv_flow_imp.g_varchar2_table(167) := '1507 \ltrch\fcs0 \cf9\insrsid4068380\charrsid4068380 {\*\datafield 800100000000000005546578743100024';
    wwv_flow_imp.g_varchar2_table(168) := '62000000000000f3c3f7265663a78646f303030313f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\f';
    wwv_flow_imp.g_varchar2_table(169) := 'ftypetxt0{\*\ffname Text1}{\*\ffdeftext F }'||wwv_flow.LF||
'{\*\ffstattext <?ref:xdo0001?>}}}}}{\fldrslt {\rtlch\fc';
    wwv_flow_imp.g_varchar2_table(170) := 's1 \af31507 \ltrch\fcs0 \cf9\lang1024\langfe1024\noproof\insrsid4068380\charrsid4068380 F }}}\sectd ';
    wwv_flow_imp.g_varchar2_table(171) := '\ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\*\bkmkend Text1}'||wwv_flow.LF||
'{\field\flddirty{\';
    wwv_flow_imp.g_varchar2_table(172) := '*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid4068380\charrsid4068380 {\*\bkmkstart Text2} FOR';
    wwv_flow_imp.g_varchar2_table(173) := 'MTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid4068380\charrsid4068380 {\*\datafield '||wwv_flow.LF||
'80010000000';
    wwv_flow_imp.g_varchar2_table(174) := '000000554657874320013444154455f4f465f5452414e53414354494f4e00000000000f3c3f7265663a78646f303030323f3';
    wwv_flow_imp.g_varchar2_table(175) := 'e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text2}{\*\ffdeftext DATE';
    wwv_flow_imp.g_varchar2_table(176) := '_OF_TRANSACTION}{\*\ffstattext '||wwv_flow.LF||
'<?ref:xdo0002?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 \ltrch\fcs0 \la';
    wwv_flow_imp.g_varchar2_table(177) := 'ng1024\langfe1024\noproof\insrsid4068380\charrsid4068380 DATE_OF_TRANSACTION}}}\sectd \ltrsect\linex';
    wwv_flow_imp.g_varchar2_table(178) := '0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid4068380 ';
    wwv_flow_imp.g_varchar2_table(179) := '{\*\bkmkend Text2}\cell }\pard \ltrpar\ql \li0\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faaut';
    wwv_flow_imp.g_varchar2_table(180) := 'o\adjustright\rin0\lin0\yts15 {\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid';
    wwv_flow_imp.g_varchar2_table(181) := '4068380\charrsid4068380 '||wwv_flow.LF||
'{\*\bkmkstart Text3} FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid4';
    wwv_flow_imp.g_varchar2_table(182) := '068380\charrsid4068380 {\*\datafield 800100000000000005546578743300094e4152524154494f4e00000000000f3';
    wwv_flow_imp.g_varchar2_table(183) := 'c3f7265663a78646f303030333f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\f';
    wwv_flow_imp.g_varchar2_table(184) := 'fname Text3}{\*\ffdeftext NARRATION}{\*\ffstattext <?ref:xdo0003?>}}}}}{\fldrslt {\rtlch\fcs1 \af315';
    wwv_flow_imp.g_varchar2_table(185) := '07 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid4068380\charrsid4068380 NARRATION}}}'||wwv_flow.LF||
'\sectd \ltr';
    wwv_flow_imp.g_varchar2_table(186) := 'sect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid';
    wwv_flow_imp.g_varchar2_table(187) := '4068380 {\*\bkmkend Text3}\cell }{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insr';
    wwv_flow_imp.g_varchar2_table(188) := 'sid4068380\charrsid4068380 '||wwv_flow.LF||
'{\*\bkmkstart Text4} FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrs';
    wwv_flow_imp.g_varchar2_table(189) := 'id4068380\charrsid4068380 {\*\datafield 80010000000000000554657874340005444542495400000000000f3c3f72';
    wwv_flow_imp.g_varchar2_table(190) := '65663a78646f303030343f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname';
    wwv_flow_imp.g_varchar2_table(191) := ' Text4}{\*\ffdeftext DEBIT}{\*\ffstattext <?ref:xdo0004?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 \ltrch';
    wwv_flow_imp.g_varchar2_table(192) := '\fcs0 \lang1024\langfe1024\noproof\insrsid4068380\charrsid4068380 DEBIT}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\e';
    wwv_flow_imp.g_varchar2_table(193) := 'ndnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid4068380 {\*\b';
    wwv_flow_imp.g_varchar2_table(194) := 'kmkend Text4}\cell }\pard \ltrpar\ql \li0\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adj';
    wwv_flow_imp.g_varchar2_table(195) := 'ustright\rin0\lin0\pararsid4068380\yts15 '||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\';
    wwv_flow_imp.g_varchar2_table(196) := 'fcs0 \insrsid4068380\charrsid4068380 {\*\bkmkstart Text5} FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs';
    wwv_flow_imp.g_varchar2_table(197) := '0 \insrsid4068380\charrsid4068380 {\*\datafield '||wwv_flow.LF||
'80010000000000000554657874350006435245444954000000';
    wwv_flow_imp.g_varchar2_table(198) := '00000f3c3f7265663a78646f303030353f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0';
    wwv_flow_imp.g_varchar2_table(199) := '{\*\ffname Text5}{\*\ffdeftext CREDIT}{\*\ffstattext <?ref:xdo0005?>}}}}}{\fldrslt {\rtlch\fcs1 \af3';
    wwv_flow_imp.g_varchar2_table(200) := '1507 '||wwv_flow.LF||
'\ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid4068380\charrsid4068380 CREDIT}}}\sectd \ltrs';
    wwv_flow_imp.g_varchar2_table(201) := 'ect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\*\bkmkend Text5}{\field\flddirty{\*\fldin';
    wwv_flow_imp.g_varchar2_table(202) := 'st {\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\cf9\insrsid4068380\charrsid4068380 {\*\bkmkstart Text6} FORM';
    wwv_flow_imp.g_varchar2_table(203) := 'TEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\insrsid4068380\charrsid4068380 {\*\datafield 8001000000';
    wwv_flow_imp.g_varchar2_table(204) := '0000000554657874360002204500000000000f3c3f7265663a78646f303030363f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\ffty';
    wwv_flow_imp.g_varchar2_table(205) := 'pe0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text6}{\*\ffdeftext  E}{\*\ffstattext <?ref:xdo0006?>}}';
    wwv_flow_imp.g_varchar2_table(206) := '}}}{\fldrslt {\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\lang1024\langfe1024\noproof\insrsid4068380\charr';
    wwv_flow_imp.g_varchar2_table(207) := 'sid4068380  E}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 ';
    wwv_flow_imp.g_varchar2_table(208) := '\af31507 \ltrch\fcs0 \insrsid4068380 {\*\bkmkend Text6}\cell }\pard\plain \ltrpar\ql \li0\ri0\sa160\';
    wwv_flow_imp.g_varchar2_table(209) := 'sl259\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 '||wwv_flow.LF||
'\rtlch\fcs1';
    wwv_flow_imp.g_varchar2_table(210) := ' \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033';
    wwv_flow_imp.g_varchar2_table(211) := ' {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid4068380 \trowd \irow1\irowband1\lastrow \ltrrow\ts15\trga';
    wwv_flow_imp.g_varchar2_table(212) := 'ph108\trleft-108\trbrdrt\brdrs\brdrw10 '||wwv_flow.LF||
'\trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdr';
    wwv_flow_imp.g_varchar2_table(213) := 's\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trautofit1\trpad';
    wwv_flow_imp.g_varchar2_table(214) := 'dl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid4068380\tbllkhdrrows\tbllkhdrcols\tb';
    wwv_flow_imp.g_varchar2_table(215) := 'llknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\br';
    wwv_flow_imp.g_varchar2_table(216) := 'drs\brdrw10 '||wwv_flow.LF||
'\clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth2337\clshdrawnil \cellx2392\clver';
    wwv_flow_imp.g_varchar2_table(217) := 'talt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clt';
    wwv_flow_imp.g_varchar2_table(218) := 'xlrtb\clftsWidth3\clwWidth2337\clshdrawnil \cellx4729\clvertalt'||wwv_flow.LF||
'\clbrdrt\brdrs\brdrw10 \clbrdrl\brd';
    wwv_flow_imp.g_varchar2_table(219) := 'rs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth2338\clshdraw';
    wwv_flow_imp.g_varchar2_table(220) := 'nil \cellx7067\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdr';
    wwv_flow_imp.g_varchar2_table(221) := 'r\brdrs\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth2338\clshdrawnil \cellx9405\row }\pard \ltrpar\ql \l';
    wwv_flow_imp.g_varchar2_table(222) := 'i0\ri0\sa160\sl259\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 ';
    wwv_flow_imp.g_varchar2_table(223) := '{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid2632095 '||wwv_flow.LF||
'\par }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid';
    wwv_flow_imp.g_varchar2_table(224) := '4068380 '||wwv_flow.LF||
'\par }{\*\themedata 504b030414000600080000002100e9de0fbfff0000001c020000130000005b436f6e74';
    wwv_flow_imp.g_varchar2_table(225) := '656e745f54797065735d2e786d6cac91cb4ec3301045f748fc83e52d4a'||wwv_flow.LF||
'9cb2400825e982c78ec7a27cc0c8992416c9d8b2';
    wwv_flow_imp.g_varchar2_table(226) := 'a755fbf74cd25442a820166c2cd933f79e3be372bd1f07b5c3989ca74aaff2422b24eb1b475da5df374fd9ad'||wwv_flow.LF||
'5689811a18';
    wwv_flow_imp.g_varchar2_table(227) := '3c61a50f98f4babebc2837878049899a52a57be670674cb23d8e90721f90a4d2fa3802cb35762680fd800ecd7551dc18eb89';
    wwv_flow_imp.g_varchar2_table(228) := '9138e3c943d7e503b6'||wwv_flow.LF||
'b01d583deee5f99824e290b4ba3f364eac4a430883b3c092d4eca8f946c916422ecab927f52ea42b';
    wwv_flow_imp.g_varchar2_table(229) := '89a1cd59c254f919b0e85e6535d135a8de20f20b8c12c3b0'||wwv_flow.LF||
'0c895fcf6720192de6bf3b9e89ecdbd6596cbcdd8eb28e7c36';
    wwv_flow_imp.g_varchar2_table(230) := '5ecc4ec1ff1460f53fe813d3cc7f5b7f020000ffff0300504b030414000600080000002100a5d6'||wwv_flow.LF||
'a7e7c000000036010000';
    wwv_flow_imp.g_varchar2_table(231) := '0b0000005f72656c732f2e72656c73848fcf6ac3300c87ef85bd83d17d51d2c31825762fa590432fa37d00e1287f68221bdb';
    wwv_flow_imp.g_varchar2_table(232) := '1bebdb4f'||wwv_flow.LF||
'c7060abb0884a4eff7a93dfeae8bf9e194e720169aaa06c3e2433fcb68e1763dbf7f82c985a4a725085b787086';
    wwv_flow_imp.g_varchar2_table(233) := 'a37bdbb55fbc50d1a33ccd311ba548b6309512'||wwv_flow.LF||
'0f88d94fbc52ae4264d1c910d24a45db3462247fa791715fd71f989e19e0';
    wwv_flow_imp.g_varchar2_table(234) := '364cd3f51652d73760ae8fa8c9ffb3c330cc9e4fc17faf2ce545046e37944c69e462'||wwv_flow.LF||
'a1a82fe353bd90a865aad41ed0b5b8';
    wwv_flow_imp.g_varchar2_table(235) := 'f9d6fd010000ffff0300504b0304140006000800000021006b799616830000008a0000001c0000007468656d652f746865'||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(236) := '6d652f7468656d654d616e616765722e786d6c0ccc4d0ac3201040e17da17790d93763bb284562b2cbaebbf600439c1a41c7';
    wwv_flow_imp.g_varchar2_table(237) := 'a0d29fdbd7e5e38337cedf14d59b'||wwv_flow.LF||
'4b0d592c9c070d8a65cd2e88b7f07c2ca71ba8da481cc52c6ce1c715e6e97818c9b48d';
    wwv_flow_imp.g_varchar2_table(238) := '13df49c873517d23d59085adb5dd20d6b52bd521ef2cdd5eb9246a3d8b'||wwv_flow.LF||
'4757e8d3f729e245eb2b260a0238fd010000ffff';
    wwv_flow_imp.g_varchar2_table(239) := '0300504b030414000600080000002100b6f4679893070000c9200000160000007468656d652f7468656d652f'||wwv_flow.LF||
'7468656d65';
    wwv_flow_imp.g_varchar2_table(240) := '312e786d6cec59cd8b1bc915bf07f23f347d97f5d5ad8fc1f2a24fcfda33b6b164873dd648a5eef2547789aad28cc56208de';
    wwv_flow_imp.g_varchar2_table(241) := '532e81c026e49085bd'||wwv_flow.LF||
'ed21842cecc22eb9e48f31d8249b3f22afaa5bdd5552c99e191c3061463074977eefd5afde7bf5de';
    wwv_flow_imp.g_varchar2_table(242) := '53d5ddcf5e26d4bbc05c1096f6fcfa9d9aefe174ce16248d'||wwv_flow.LF||
'7afeb3d9a4d2f13d2151ba4094a5b8e76fb0f03fbbf7eb5fdd';
    wwv_flow_imp.g_varchar2_table(243) := '454732c609f6403e1547a8e7c752ae8eaa5531876124eeb0154ee1bb25e30992f0caa3ea82a34b'||wwv_flow.LF||
'd09bd06aa3566b551344';
    wwv_flow_imp.g_varchar2_table(244) := '52df4b51026a1f2f97648ebd9952e9dfdb2a1f53784da5500373caa74a35b6243476715e5708b11143cabd0b447b3eccb360';
    wwv_flow_imp.g_varchar2_table(245) := '9733fc52'||wwv_flow.LF||
'fa1e4542c2173dbfa6fffceabdbb5574940b517940d6909be8bf5c2e17589c37f49c3c3a2b260d823068f50bfd';
    wwv_flow_imp.g_varchar2_table(246) := '1a40e53e6edc1eb7c6ad429f06a0f91c569a71'||wwv_flow.LF||
'b175b61bc320c71aa0ecd1a17bd41e35eb16ded0dfdce3dc0fd5c7c26b50';
    wwv_flow_imp.g_varchar2_table(247) := 'a63fd8c34f2643b0a285d7a00c1feee1c3417730b2f56b50866fede1dbb5fe28685b'||wwv_flow.LF||
'fa3528a6243ddf43d7c25673b85d6d';
    wwv_flow_imp.g_varchar2_table(248) := '0159327aec8477c360d26ee4ca4b144443115d6a8a254be5a1584bd00bc6270050408a24493db959e1259a43140f112567'||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(249) := '9c7827248a21f056286502866b8ddaa4d684ffea13e827ed5174849121ad780113b137a4f87862cec94af6fc07a0d537206f';
    wwv_flow_imp.g_varchar2_table(250) := '7ffef9cdeb1fdfbcfee9cd575fbd'||wwv_flow.LF||
'79fdf77c6eadca923b466964cafdf2dd1ffef3cd6fbd7ffff0ed2f5fff319b7a172f4c';
    wwv_flow_imp.g_varchar2_table(251) := 'fcbbbffdeedd3ffef93ef5b0e2d2146ffff4fdbb1fbf7ffbe7dfffebaf'||wwv_flow.LF||
'5f3bb4f7393a33e1339260e13dc297de5396c002';
    wwv_flow_imp.g_varchar2_table(252) := '1dfcf119bf9ec42c46c494e8a791402952b338f48f656ca11f6d10450edc00db767cce21d5b880f7d72f2cc2'||wwv_flow.LF||
'd398af2571';
    wwv_flow_imp.g_varchar2_table(253) := '687c182716f094313a60dc6985876a2ec3ccb3751ab927e76b13f714a10bd7dc43945a5e1eaf579063894be530c616cd2714';
    wwv_flow_imp.g_varchar2_table(254) := 'a5124538c5d253dfb1'||wwv_flow.LF||
'738c1dabfb8210cbaea764ce99604be97d41bc01224e93ccc899154da5d03149c02f1b1741f0b765';
    wwv_flow_imp.g_varchar2_table(255) := '9bd3e7de8051d7aa47f8c246c2de40d4417e86a965c6fb68'||wwv_flow.LF||
'2d51e252394309350d7e8264ec2239ddf0b9891b0b099e8e30';
    wwv_flow_imp.g_varchar2_table(256) := '65de78818570c93ce6b05ec3e90f21cdb8dd7e4a37898de4929cbb749e20c64ce4889d0f6394ac'||wwv_flow.LF||
'5cd829496313fbb93887';
    wwv_flow_imp.g_varchar2_table(257) := '1045de13265df05366ef10f50e7e40e941773f27d872f787b3c133c8b026a53240d4376beef0e57dccacf89d6ee8126157aa';
    wwv_flow_imp.g_varchar2_table(258) := 'e9f3c44a'||wwv_flow.LF||
'b17d4e9cd131584756689f604cd1255a60ec3dfbdcc160c05696cd4bd20f62c82ac7d815580f901dabea3dc502';
    wwv_flow_imp.g_varchar2_table(259) := '7a25d5dcece7c91322ac909de2881de073bad9'||wwv_flow.LF||
'493c1b9426881fd2fc08bc6eda7c0ca52e7105c0633a3f37818f08f48010';
    wwv_flow_imp.g_varchar2_table(260) := '2f4ea33c16a0c308ee835a9fc4c82a60ea5db8e375c32dff5d658fc1be7c61d1b8c2'||wwv_flow.LF||
'be04197c6d1948eca6cc7b6d3343d4';
    wwv_flow_imp.g_varchar2_table(261) := '9aa00c9819822ec3956e41c4727f29a28aab165b3be596f6a62ddd00dd91d5f42424fd6007b4d3fb84ffbbde073a8cb77f'||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(262) := 'f9c6b10f3e4ebfe3566c25ab6b763a8792c9f14e7f7308b7dbd50c195f904fbfa919a175fa04431dd9cf58b73dcd6d4fe3ff';
    wwv_flow_imp.g_varchar2_table(263) := 'dff73487f6f36d2773a8dfb8ed64'||wwv_flow.LF||
'7ce8306e3b99fc70e5e3743265f3027d8d3af0c80e7af4b14f72f0d46749289dca0dc5';
    wwv_flow_imp.g_varchar2_table(264) := '27421ffc08f83db398c0a092d3279eb838055cc5f0a8ca1c4c60e1228e'||wwv_flow.LF||
'b48cc799fc0d91f134462b381daafb4a492472d5';
    wwv_flow_imp.g_varchar2_table(265) := '91f0564cc0a1911e76ea5678ba4e4ed9223becacd7d5c16656590592e5782d2cc6e1a04a66e856bb3cc02bd4'||wwv_flow.LF||
'6bb6913e68';
    wwv_flow_imp.g_varchar2_table(266) := 'dd1250b2d721614c6693683a48b4b783ca48fa58178ce620a157f65158741d2c3a4afdd6557b2c805ae115f8c1edc1cff49e';
    wwv_flow_imp.g_varchar2_table(267) := '1f06200242701e07cd'||wwv_flow.LF||
'f942f92973f5d6bbda991fd3d3878c69450034d8db08283ddd555c0f2e4fad2e0bb52b78da226184';
    wwv_flow_imp.g_varchar2_table(268) := '9b4d425b46377822869fc17974aad1abd0b8aeafbba54b2d'||wwv_flow.LF||
'7aca147a3e08ad9246bbf33e1637f535c8ede6069a9a9982a6';
    wwv_flow_imp.g_varchar2_table(269) := 'de65cf6f35430899395af5fc251c1ac363b282d811ea3717a211dcbccc25cf36fc4d32cb8a0b39'||wwv_flow.LF||
'4222ce0cae934e960d12';
    wwv_flow_imp.g_varchar2_table(270) := '2231f728497abe5a7ee1069aea1ca2b9d51b90103e59725d482b9f1a3970baed64bc5ce2b934dd6e8c284b67af90e1b35ce1';
    wwv_flow_imp.g_varchar2_table(271) := 'fc568bdf'||wwv_flow.LF||
'1cac24d91adc3d8d1797de195df3a708422c6cd795011744c0dd413db3e682c0655891c8caf8db294c79da356f';
    wwv_flow_imp.g_varchar2_table(272) := 'a3740c65e388ae62945714339967709dca0b3a'||wwv_flow.LF||
'faadb081f196af190c6a98242f8467912ab0a651ad6a5a548d8cc3c1aafb';
    wwv_flow_imp.g_varchar2_table(273) := '6121653923699635d3ca2aaa6abab39835c3b60cecd8f26645de60b53531e434b3c2'||wwv_flow.LF||
'67a97b37e576b7b96ea74f28aa0418';
    wwv_flow_imp.g_varchar2_table(274) := 'bcb09fa3ea5ea12018d4cac92c6a8af17e1a56393b1fb56bc776811fa07695226164fdd656ed8edd8a1ae19c0e066f54f9'||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(275) := '416e376a6168b9ed2bb5a5f5adb979b1cdce5e40f2184197bba6526857c2c92e47d0104d754f92a50dd8222f65be35e0c95b';
    wwv_flow_imp.g_varchar2_table(276) := '73d2f3bfac85fd60d80887955a27'||wwv_flow.LF||
'1c57826650ab74c27eb3d20fc3667d1cd66ba341e31514161927f530bbb19fc00506dd';
    wwv_flow_imp.g_varchar2_table(277) := 'e4f7f67a7cefee3ed9ded1dc99b3a4caf4dd7c5513d777f7f5c6e1bb7b'||wwv_flow.LF||
'8f40d2f9b2d598749bdd41abd26df627956034e8';
    wwv_flow_imp.g_varchar2_table(278) := '54bac3d6a0326a0ddba3c9681876ba9357be77a1c141bf390c5ae34ea5551f0e2b41aba6e877ba9576d068f4'||wwv_flow.LF||
'8376bf330e';
    wwv_flow_imp.g_varchar2_table(279) := 'faaff23606569ea58fdc16605ecdebde7f010000ffff0300504b0304140006000800000021000dd1909fb60000001b010000';
    wwv_flow_imp.g_varchar2_table(280) := '270000007468656d65'||wwv_flow.LF||
'2f7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73848f4d0ac230';
    wwv_flow_imp.g_varchar2_table(281) := '1484f78277086f6fd3ba109126dd88d0add40384e4350d36'||wwv_flow.LF||
'3f2451eced0dae2c082e8761be9969bb979dc9136332de3168';
    wwv_flow_imp.g_varchar2_table(282) := 'aa1a083ae995719ac16db8ec8e4052164e89d93b64b060828e6f37ed1567914b284d262452282e'||wwv_flow.LF||
'3198720e274a939cd08a';
    wwv_flow_imp.g_varchar2_table(283) := '54f980ae38a38f56e422a3a641c8bbd048f7757da0f19b017cc524bd62107bd5001996509affb3fd381a89672f1f165dfe51';
    wwv_flow_imp.g_varchar2_table(284) := '4173d985'||wwv_flow.LF||
'0528a2c6cce0239baa4c04ca5bbabac4df000000ffff0300504b01022d0014000600080000002100e9de0fbfff';
    wwv_flow_imp.g_varchar2_table(285) := '0000001c020000130000000000000000000000'||wwv_flow.LF||
'0000000000005b436f6e74656e745f54797065735d2e786d6c504b01022d';
    wwv_flow_imp.g_varchar2_table(286) := '0014000600080000002100a5d6a7e7c0000000360100000b00000000000000000000'||wwv_flow.LF||
'000000300100005f72656c732f2e72';
    wwv_flow_imp.g_varchar2_table(287) := '656c73504b01022d00140006000800000021006b799616830000008a0000001c0000000000000000000000000019020000'||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(288) := '7468656d652f7468656d652f7468656d654d616e616765722e786d6c504b01022d0014000600080000002100b6f467989307';
    wwv_flow_imp.g_varchar2_table(289) := '0000c92000001600000000000000'||wwv_flow.LF||
'000000000000d60200007468656d652f7468656d652f7468656d65312e786d6c504b01';
    wwv_flow_imp.g_varchar2_table(290) := '022d00140006000800000021000dd1909fb60000001b01000027000000'||wwv_flow.LF||
'000000000000000000009d0a00007468656d652f';
    wwv_flow_imp.g_varchar2_table(291) := '7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73504b050600000000050005005d01000098';
    wwv_flow_imp.g_varchar2_table(292) := '0b00000000}'||wwv_flow.LF||
'{\*\colorschememapping 3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554';
    wwv_flow_imp.g_varchar2_table(293) := '462d3822207374616e64616c6f6e653d22796573223f3e0d0a3c613a636c724d'||wwv_flow.LF||
'617020786d6c6e733a613d22687474703a';
    wwv_flow_imp.g_varchar2_table(294) := '2f2f736368656d61732e6f70656e786d6c666f726d6174732e6f72672f64726177696e676d6c2f323030362f6d6169'||wwv_flow.LF||
'6e22';
    wwv_flow_imp.g_varchar2_table(295) := '206267313d226c743122207478313d22646b3122206267323d226c743222207478323d22646b322220616363656e74313d22';
    wwv_flow_imp.g_varchar2_table(296) := '616363656e74312220616363'||wwv_flow.LF||
'656e74323d22616363656e74322220616363656e74333d22616363656e7433222061636365';
    wwv_flow_imp.g_varchar2_table(297) := '6e74343d22616363656e74342220616363656e74353d22616363656e74352220616363656e74363d22616363656e74362220';
    wwv_flow_imp.g_varchar2_table(298) := '686c696e6b3d22686c696e6b2220666f6c486c696e6b3d22666f6c486c696e6b222f3e}'||wwv_flow.LF||
'{\*\latentstyles\lsdstimax3';
    wwv_flow_imp.g_varchar2_table(299) := '71\lsdlockeddef0\lsdsemihiddendef0\lsdunhideuseddef0\lsdqformatdef0\lsdprioritydef99{\lsdlockedexcep';
    wwv_flow_imp.g_varchar2_table(300) := 't \lsdqformat1 \lsdpriority0 \lsdlocked0 Normal;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 1;'||wwv_flow.LF||
'\';
    wwv_flow_imp.g_varchar2_table(301) := 'lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 2;\lsdsemihidden1 \lsd';
    wwv_flow_imp.g_varchar2_table(302) := 'unhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 3;\lsdsemihidden1 \lsdunhideused1 \lsdqfo';
    wwv_flow_imp.g_varchar2_table(303) := 'rmat1 \lsdpriority9 \lsdlocked0 heading 4;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriorit';
    wwv_flow_imp.g_varchar2_table(304) := 'y9 \lsdlocked0 heading 5;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 head';
    wwv_flow_imp.g_varchar2_table(305) := 'ing 6;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 7;'||wwv_flow.LF||
'\lsdsemihid';
    wwv_flow_imp.g_varchar2_table(306) := 'den1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 8;\lsdsemihidden1 \lsdunhideused';
    wwv_flow_imp.g_varchar2_table(307) := '1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 9;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index';
    wwv_flow_imp.g_varchar2_table(308) := ' 1;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(309) := ' index 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 4;\lsdsemihidden1 \lsdunhideused1 \lsdloc';
    wwv_flow_imp.g_varchar2_table(310) := 'ked0 index 5;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 6;\lsdsemihidden1 \lsdunhideused1 \';
    wwv_flow_imp.g_varchar2_table(311) := 'lsdlocked0 index 7;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 8;\lsdsemihidden1 \lsdunhideuse';
    wwv_flow_imp.g_varchar2_table(312) := 'd1 \lsdlocked0 index 9;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 1;\lsdsemihi';
    wwv_flow_imp.g_varchar2_table(313) := 'dden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 2;\lsdsemihidden1 \lsdunhideused1 \lsdpriority3';
    wwv_flow_imp.g_varchar2_table(314) := '9 \lsdlocked0 toc 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 4;\lsdsemihidde';
    wwv_flow_imp.g_varchar2_table(315) := 'n1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 5;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \';
    wwv_flow_imp.g_varchar2_table(316) := 'lsdlocked0 toc 6;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 7;\lsdsemihidden1 ';
    wwv_flow_imp.g_varchar2_table(317) := '\lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 8;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsd';
    wwv_flow_imp.g_varchar2_table(318) := 'locked0 toc 9;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Normal Indent;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhide';
    wwv_flow_imp.g_varchar2_table(319) := 'used1 \lsdlocked0 footnote text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 annotation text;\lsdsemi';
    wwv_flow_imp.g_varchar2_table(320) := 'hidden1 \lsdunhideused1 \lsdlocked0 header;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 footer;'||wwv_flow.LF||
'\lsd';
    wwv_flow_imp.g_varchar2_table(321) := 'semihidden1 \lsdunhideused1 \lsdlocked0 index heading;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \';
    wwv_flow_imp.g_varchar2_table(322) := 'lsdpriority35 \lsdlocked0 caption;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 table of figures;'||wwv_flow.LF||
'\ls';
    wwv_flow_imp.g_varchar2_table(323) := 'dsemihidden1 \lsdunhideused1 \lsdlocked0 envelope address;\lsdsemihidden1 \lsdunhideused1 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(324) := '0 envelope return;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 footnote reference;\lsdsemihidden1 \ls';
    wwv_flow_imp.g_varchar2_table(325) := 'dunhideused1 \lsdlocked0 annotation reference;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 line num';
    wwv_flow_imp.g_varchar2_table(326) := 'ber;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 page number;\lsdsemihidden1 \lsdunhideused1 \lsdlock';
    wwv_flow_imp.g_varchar2_table(327) := 'ed0 endnote reference;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 endnote text;'||wwv_flow.LF||
'\lsdsemihidden1 \ls';
    wwv_flow_imp.g_varchar2_table(328) := 'dunhideused1 \lsdlocked0 table of authorities;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 macro;\lsd';
    wwv_flow_imp.g_varchar2_table(329) := 'semihidden1 \lsdunhideused1 \lsdlocked0 toa heading;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List';
    wwv_flow_imp.g_varchar2_table(330) := ';'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet;\lsdsemihidden1 \lsdunhideused1 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(331) := 'd0 List Number;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List 2;\lsdsemihidden1 \lsdunhideused1 \l';
    wwv_flow_imp.g_varchar2_table(332) := 'sdlocked0 List 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List 4;\lsdsemihidden1 \lsdunhideused';
    wwv_flow_imp.g_varchar2_table(333) := '1 \lsdlocked0 List 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 2;\lsdsemihidden1 \lsdu';
    wwv_flow_imp.g_varchar2_table(334) := 'nhideused1 \lsdlocked0 List Bullet 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 4;\ls';
    wwv_flow_imp.g_varchar2_table(335) := 'dsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 L';
    wwv_flow_imp.g_varchar2_table(336) := 'ist Number 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideu';
    wwv_flow_imp.g_varchar2_table(337) := 'sed1 \lsdlocked0 List Number 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number 5;\lsdqformat';
    wwv_flow_imp.g_varchar2_table(338) := '1 \lsdpriority10 \lsdlocked0 Title;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Closing;'||wwv_flow.LF||
'\lsdsemihid';
    wwv_flow_imp.g_varchar2_table(339) := 'den1 \lsdunhideused1 \lsdlocked0 Signature;\lsdsemihidden1 \lsdunhideused1 \lsdpriority1 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(340) := ' Default Paragraph Font;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text;\lsdsemihidden1 \lsdun';
    wwv_flow_imp.g_varchar2_table(341) := 'hideused1 \lsdlocked0 Body Text Indent;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue;\';
    wwv_flow_imp.g_varchar2_table(342) := 'lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(343) := 'd0 List Continue 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue 4;'||wwv_flow.LF||
'\lsdsemihidden1 \ls';
    wwv_flow_imp.g_varchar2_table(344) := 'dunhideused1 \lsdlocked0 List Continue 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Message Header;';
    wwv_flow_imp.g_varchar2_table(345) := '\lsdqformat1 \lsdpriority11 \lsdlocked0 Subtitle;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Salutat';
    wwv_flow_imp.g_varchar2_table(346) := 'ion;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Date;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 B';
    wwv_flow_imp.g_varchar2_table(347) := 'ody Text First Indent;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text First Indent 2;\lsdsemih';
    wwv_flow_imp.g_varchar2_table(348) := 'idden1 \lsdunhideused1 \lsdlocked0 Note Heading;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body T';
    wwv_flow_imp.g_varchar2_table(349) := 'ext 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text 3;\lsdsemihidden1 \lsdunhideused1 \lsdlo';
    wwv_flow_imp.g_varchar2_table(350) := 'cked0 Body Text Indent 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text Indent 3;'||wwv_flow.LF||
'\lsdsemihi';
    wwv_flow_imp.g_varchar2_table(351) := 'dden1 \lsdunhideused1 \lsdlocked0 Block Text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Hyperlink;\';
    wwv_flow_imp.g_varchar2_table(352) := 'lsdsemihidden1 \lsdunhideused1 \lsdlocked0 FollowedHyperlink;\lsdqformat1 \lsdpriority22 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(353) := ' Strong;'||wwv_flow.LF||
'\lsdqformat1 \lsdpriority20 \lsdlocked0 Emphasis;\lsdsemihidden1 \lsdunhideused1 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(354) := 'd0 Document Map;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Plain Text;\lsdsemihidden1 \lsdunhideuse';
    wwv_flow_imp.g_varchar2_table(355) := 'd1 \lsdlocked0 E-mail Signature;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Top of Form;\lsds';
    wwv_flow_imp.g_varchar2_table(356) := 'emihidden1 \lsdunhideused1 \lsdlocked0 HTML Bottom of Form;\lsdsemihidden1 \lsdunhideused1 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(357) := 'd0 Normal (Web);\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Acronym;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhid';
    wwv_flow_imp.g_varchar2_table(358) := 'eused1 \lsdlocked0 HTML Address;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Cite;\lsdsemihidden';
    wwv_flow_imp.g_varchar2_table(359) := '1 \lsdunhideused1 \lsdlocked0 HTML Code;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Definition;';
    wwv_flow_imp.g_varchar2_table(360) := ''||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Keyboard;\lsdsemihidden1 \lsdunhideused1 \lsdlock';
    wwv_flow_imp.g_varchar2_table(361) := 'ed0 HTML Preformatted;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Sample;\lsdsemihidden1 \lsdun';
    wwv_flow_imp.g_varchar2_table(362) := 'hideused1 \lsdlocked0 HTML Typewriter;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Variable;\l';
    wwv_flow_imp.g_varchar2_table(363) := 'sdsemihidden1 \lsdunhideused1 \lsdlocked0 Normal Table;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 a';
    wwv_flow_imp.g_varchar2_table(364) := 'nnotation subject;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 No List;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideus';
    wwv_flow_imp.g_varchar2_table(365) := 'ed1 \lsdlocked0 Outline List 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Outline List 2;\lsdsemihi';
    wwv_flow_imp.g_varchar2_table(366) := 'dden1 \lsdunhideused1 \lsdlocked0 Outline List 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table S';
    wwv_flow_imp.g_varchar2_table(367) := 'imple 1;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Simple 2;\lsdsemihidden1 \lsdunhideused1';
    wwv_flow_imp.g_varchar2_table(368) := ' \lsdlocked0 Table Simple 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Classic 1;\lsdsemihidd';
    wwv_flow_imp.g_varchar2_table(369) := 'en1 \lsdunhideused1 \lsdlocked0 Table Classic 2;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table ';
    wwv_flow_imp.g_varchar2_table(370) := 'Classic 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Classic 4;\lsdsemihidden1 \lsdunhideused';
    wwv_flow_imp.g_varchar2_table(371) := '1 \lsdlocked0 Table Colorful 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Colorful 2;'||wwv_flow.LF||
'\lsdse';
    wwv_flow_imp.g_varchar2_table(372) := 'mihidden1 \lsdunhideused1 \lsdlocked0 Table Colorful 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 T';
    wwv_flow_imp.g_varchar2_table(373) := 'able Columns 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 2;\lsdsemihidden1 \lsdunhid';
    wwv_flow_imp.g_varchar2_table(374) := 'eused1 \lsdlocked0 Table Columns 3;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 4;\ls';
    wwv_flow_imp.g_varchar2_table(375) := 'dsemihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(376) := ' Table Grid 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 2;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideu';
    wwv_flow_imp.g_varchar2_table(377) := 'sed1 \lsdlocked0 Table Grid 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 4;\lsdsemihidde';
    wwv_flow_imp.g_varchar2_table(378) := 'n1 \lsdunhideused1 \lsdlocked0 Table Grid 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 6';
    wwv_flow_imp.g_varchar2_table(379) := ';'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 7;\lsdsemihidden1 \lsdunhideused1 \lsdlock';
    wwv_flow_imp.g_varchar2_table(380) := 'ed0 Table Grid 8;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 1;\lsdsemihidden1 \lsdunhide';
    wwv_flow_imp.g_varchar2_table(381) := 'used1 \lsdlocked0 Table List 2;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 3;\lsdsemihi';
    wwv_flow_imp.g_varchar2_table(382) := 'dden1 \lsdunhideused1 \lsdlocked0 Table List 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Lis';
    wwv_flow_imp.g_varchar2_table(383) := 't 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 6;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdl';
    wwv_flow_imp.g_varchar2_table(384) := 'ocked0 Table List 7;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 8;\lsdsemihidden1 \lsdunh';
    wwv_flow_imp.g_varchar2_table(385) := 'ideused1 \lsdlocked0 Table 3D effects 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table 3D effects';
    wwv_flow_imp.g_varchar2_table(386) := ' 2;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table 3D effects 3;\lsdsemihidden1 \lsdunhideused1 ';
    wwv_flow_imp.g_varchar2_table(387) := '\lsdlocked0 Table Contemporary;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Elegant;\lsdsemihid';
    wwv_flow_imp.g_varchar2_table(388) := 'den1 \lsdunhideused1 \lsdlocked0 Table Professional;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Ta';
    wwv_flow_imp.g_varchar2_table(389) := 'ble Subtle 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Subtle 2;\lsdsemihidden1 \lsdunhideus';
    wwv_flow_imp.g_varchar2_table(390) := 'ed1 \lsdlocked0 Table Web 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Web 2;'||wwv_flow.LF||
'\lsdsemihidden';
    wwv_flow_imp.g_varchar2_table(391) := '1 \lsdunhideused1 \lsdlocked0 Table Web 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Balloon Text;\';
    wwv_flow_imp.g_varchar2_table(392) := 'lsdpriority39 \lsdlocked0 Table Grid;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Theme;\lsdsem';
    wwv_flow_imp.g_varchar2_table(393) := 'ihidden1 \lsdlocked0 Placeholder Text;'||wwv_flow.LF||
'\lsdqformat1 \lsdpriority1 \lsdlocked0 No Spacing;\lsdpriori';
    wwv_flow_imp.g_varchar2_table(394) := 'ty60 \lsdlocked0 Light Shading;\lsdpriority61 \lsdlocked0 Light List;\lsdpriority62 \lsdlocked0 Ligh';
    wwv_flow_imp.g_varchar2_table(395) := 't Grid;\lsdpriority63 \lsdlocked0 Medium Shading 1;\lsdpriority64 \lsdlocked0 Medium Shading 2;'||wwv_flow.LF||
'\ls';
    wwv_flow_imp.g_varchar2_table(396) := 'dpriority65 \lsdlocked0 Medium List 1;\lsdpriority66 \lsdlocked0 Medium List 2;\lsdpriority67 \lsdlo';
    wwv_flow_imp.g_varchar2_table(397) := 'cked0 Medium Grid 1;\lsdpriority68 \lsdlocked0 Medium Grid 2;\lsdpriority69 \lsdlocked0 Medium Grid ';
    wwv_flow_imp.g_varchar2_table(398) := '3;\lsdpriority70 \lsdlocked0 Dark List;'||wwv_flow.LF||
'\lsdpriority71 \lsdlocked0 Colorful Shading;\lsdpriority72 ';
    wwv_flow_imp.g_varchar2_table(399) := '\lsdlocked0 Colorful List;\lsdpriority73 \lsdlocked0 Colorful Grid;\lsdpriority60 \lsdlocked0 Light ';
    wwv_flow_imp.g_varchar2_table(400) := 'Shading Accent 1;\lsdpriority61 \lsdlocked0 Light List Accent 1;'||wwv_flow.LF||
'\lsdpriority62 \lsdlocked0 Light G';
    wwv_flow_imp.g_varchar2_table(401) := 'rid Accent 1;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 1;\lsdpriority64 \lsdlocked0 Medium ';
    wwv_flow_imp.g_varchar2_table(402) := 'Shading 2 Accent 1;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 1;\lsdsemihidden1 \lsdlocked0 Rev';
    wwv_flow_imp.g_varchar2_table(403) := 'ision;'||wwv_flow.LF||
'\lsdqformat1 \lsdpriority34 \lsdlocked0 List Paragraph;\lsdqformat1 \lsdpriority29 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(404) := 'd0 Quote;\lsdqformat1 \lsdpriority30 \lsdlocked0 Intense Quote;\lsdpriority66 \lsdlocked0 Medium Lis';
    wwv_flow_imp.g_varchar2_table(405) := 't 2 Accent 1;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 1;'||wwv_flow.LF||
'\lsdpriority68 \lsdlocked0 Medium G';
    wwv_flow_imp.g_varchar2_table(406) := 'rid 2 Accent 1;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 1;\lsdpriority70 \lsdlocked0 Dark Lis';
    wwv_flow_imp.g_varchar2_table(407) := 't Accent 1;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 1;\lsdpriority72 \lsdlocked0 Colorful ';
    wwv_flow_imp.g_varchar2_table(408) := 'List Accent 1;'||wwv_flow.LF||
'\lsdpriority73 \lsdlocked0 Colorful Grid Accent 1;\lsdpriority60 \lsdlocked0 Light S';
    wwv_flow_imp.g_varchar2_table(409) := 'hading Accent 2;\lsdpriority61 \lsdlocked0 Light List Accent 2;\lsdpriority62 \lsdlocked0 Light Grid';
    wwv_flow_imp.g_varchar2_table(410) := ' Accent 2;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 2;'||wwv_flow.LF||
'\lsdpriority64 \lsdlocked0 Medium S';
    wwv_flow_imp.g_varchar2_table(411) := 'hading 2 Accent 2;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 2;\lsdpriority66 \lsdlocked0 Mediu';
    wwv_flow_imp.g_varchar2_table(412) := 'm List 2 Accent 2;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 2;\lsdpriority68 \lsdlocked0 Mediu';
    wwv_flow_imp.g_varchar2_table(413) := 'm Grid 2 Accent 2;'||wwv_flow.LF||
'\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 2;\lsdpriority70 \lsdlocked0 Dar';
    wwv_flow_imp.g_varchar2_table(414) := 'k List Accent 2;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 2;\lsdpriority72 \lsdlocked0 Colo';
    wwv_flow_imp.g_varchar2_table(415) := 'rful List Accent 2;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 2;'||wwv_flow.LF||
'\lsdpriority60 \lsdlocked0 Li';
    wwv_flow_imp.g_varchar2_table(416) := 'ght Shading Accent 3;\lsdpriority61 \lsdlocked0 Light List Accent 3;\lsdpriority62 \lsdlocked0 Light';
    wwv_flow_imp.g_varchar2_table(417) := ' Grid Accent 3;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 3;\lsdpriority64 \lsdlocked0 Mediu';
    wwv_flow_imp.g_varchar2_table(418) := 'm Shading 2 Accent 3;'||wwv_flow.LF||
'\lsdpriority65 \lsdlocked0 Medium List 1 Accent 3;\lsdpriority66 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(419) := 'Medium List 2 Accent 3;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 3;\lsdpriority68 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(420) := 'Medium Grid 2 Accent 3;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 3;'||wwv_flow.LF||
'\lsdpriority70 \lsdlocked';
    wwv_flow_imp.g_varchar2_table(421) := '0 Dark List Accent 3;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 3;\lsdpriority72 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(422) := ' Colorful List Accent 3;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 3;\lsdpriority60 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(423) := ' Light Shading Accent 4;'||wwv_flow.LF||
'\lsdpriority61 \lsdlocked0 Light List Accent 4;\lsdpriority62 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(424) := 'Light Grid Accent 4;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 4;\lsdpriority64 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(425) := 'Medium Shading 2 Accent 4;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 4;'||wwv_flow.LF||
'\lsdpriority66 \lsdloc';
    wwv_flow_imp.g_varchar2_table(426) := 'ked0 Medium List 2 Accent 4;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 4;\lsdpriority68 \lsdloc';
    wwv_flow_imp.g_varchar2_table(427) := 'ked0 Medium Grid 2 Accent 4;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 4;\lsdpriority70 \lsdloc';
    wwv_flow_imp.g_varchar2_table(428) := 'ked0 Dark List Accent 4;'||wwv_flow.LF||
'\lsdpriority71 \lsdlocked0 Colorful Shading Accent 4;\lsdpriority72 \lsdlo';
    wwv_flow_imp.g_varchar2_table(429) := 'cked0 Colorful List Accent 4;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 4;\lsdpriority60 \lsdlo';
    wwv_flow_imp.g_varchar2_table(430) := 'cked0 Light Shading Accent 5;\lsdpriority61 \lsdlocked0 Light List Accent 5;'||wwv_flow.LF||
'\lsdpriority62 \lsdloc';
    wwv_flow_imp.g_varchar2_table(431) := 'ked0 Light Grid Accent 5;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 5;\lsdpriority64 \lsdloc';
    wwv_flow_imp.g_varchar2_table(432) := 'ked0 Medium Shading 2 Accent 5;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 5;\lsdpriority66 \lsd';
    wwv_flow_imp.g_varchar2_table(433) := 'locked0 Medium List 2 Accent 5;'||wwv_flow.LF||
'\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 5;\lsdpriority68 \l';
    wwv_flow_imp.g_varchar2_table(434) := 'sdlocked0 Medium Grid 2 Accent 5;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 5;\lsdpriority70 \l';
    wwv_flow_imp.g_varchar2_table(435) := 'sdlocked0 Dark List Accent 5;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 5;'||wwv_flow.LF||
'\lsdpriority72 \';
    wwv_flow_imp.g_varchar2_table(436) := 'lsdlocked0 Colorful List Accent 5;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 5;\lsdpriority60 \';
    wwv_flow_imp.g_varchar2_table(437) := 'lsdlocked0 Light Shading Accent 6;\lsdpriority61 \lsdlocked0 Light List Accent 6;\lsdpriority62 \lsd';
    wwv_flow_imp.g_varchar2_table(438) := 'locked0 Light Grid Accent 6;'||wwv_flow.LF||
'\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 6;\lsdpriority64 \l';
    wwv_flow_imp.g_varchar2_table(439) := 'sdlocked0 Medium Shading 2 Accent 6;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 6;\lsdpriority66';
    wwv_flow_imp.g_varchar2_table(440) := ' \lsdlocked0 Medium List 2 Accent 6;'||wwv_flow.LF||
'\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 6;\lsdpriority';
    wwv_flow_imp.g_varchar2_table(441) := '68 \lsdlocked0 Medium Grid 2 Accent 6;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 6;\lsdpriority';
    wwv_flow_imp.g_varchar2_table(442) := '70 \lsdlocked0 Dark List Accent 6;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 6;'||wwv_flow.LF||
'\lsdpriorit';
    wwv_flow_imp.g_varchar2_table(443) := 'y72 \lsdlocked0 Colorful List Accent 6;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 6;\lsdqformat';
    wwv_flow_imp.g_varchar2_table(444) := '1 \lsdpriority19 \lsdlocked0 Subtle Emphasis;\lsdqformat1 \lsdpriority21 \lsdlocked0 Intense Emphasi';
    wwv_flow_imp.g_varchar2_table(445) := 's;'||wwv_flow.LF||
'\lsdqformat1 \lsdpriority31 \lsdlocked0 Subtle Reference;\lsdqformat1 \lsdpriority32 \lsdlocked0';
    wwv_flow_imp.g_varchar2_table(446) := ' Intense Reference;\lsdqformat1 \lsdpriority33 \lsdlocked0 Book Title;\lsdsemihidden1 \lsdunhideused';
    wwv_flow_imp.g_varchar2_table(447) := '1 \lsdpriority37 \lsdlocked0 Bibliography;'||wwv_flow.LF||
'\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriorit';
    wwv_flow_imp.g_varchar2_table(448) := 'y39 \lsdlocked0 TOC Heading;\lsdpriority41 \lsdlocked0 Plain Table 1;\lsdpriority42 \lsdlocked0 Plai';
    wwv_flow_imp.g_varchar2_table(449) := 'n Table 2;\lsdpriority43 \lsdlocked0 Plain Table 3;\lsdpriority44 \lsdlocked0 Plain Table 4;'||wwv_flow.LF||
'\lsdpr';
    wwv_flow_imp.g_varchar2_table(450) := 'iority45 \lsdlocked0 Plain Table 5;\lsdpriority40 \lsdlocked0 Grid Table Light;\lsdpriority46 \lsdlo';
    wwv_flow_imp.g_varchar2_table(451) := 'cked0 Grid Table 1 Light;\lsdpriority47 \lsdlocked0 Grid Table 2;\lsdpriority48 \lsdlocked0 Grid Tab';
    wwv_flow_imp.g_varchar2_table(452) := 'le 3;\lsdpriority49 \lsdlocked0 Grid Table 4;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 Grid Table 5 Dark;\lsdprio';
    wwv_flow_imp.g_varchar2_table(453) := 'rity51 \lsdlocked0 Grid Table 6 Colorful;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful;\lsdpriori';
    wwv_flow_imp.g_varchar2_table(454) := 'ty46 \lsdlocked0 Grid Table 1 Light Accent 1;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 1;'||wwv_flow.LF||
'\lsd';
    wwv_flow_imp.g_varchar2_table(455) := 'priority48 \lsdlocked0 Grid Table 3 Accent 1;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 1;\lsdpr';
    wwv_flow_imp.g_varchar2_table(456) := 'iority50 \lsdlocked0 Grid Table 5 Dark Accent 1;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Acc';
    wwv_flow_imp.g_varchar2_table(457) := 'ent 1;'||wwv_flow.LF||
'\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 1;\lsdpriority46 \lsdlocked0 Grid Ta';
    wwv_flow_imp.g_varchar2_table(458) := 'ble 1 Light Accent 2;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 2;\lsdpriority48 \lsdlocked0 Gri';
    wwv_flow_imp.g_varchar2_table(459) := 'd Table 3 Accent 2;'||wwv_flow.LF||
'\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 2;\lsdpriority50 \lsdlocked0 Gri';
    wwv_flow_imp.g_varchar2_table(460) := 'd Table 5 Dark Accent 2;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 2;\lsdpriority52 \ls';
    wwv_flow_imp.g_varchar2_table(461) := 'dlocked0 Grid Table 7 Colorful Accent 2;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 3;\ls';
    wwv_flow_imp.g_varchar2_table(462) := 'dpriority47 \lsdlocked0 Grid Table 2 Accent 3;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 3;\lsdp';
    wwv_flow_imp.g_varchar2_table(463) := 'riority49 \lsdlocked0 Grid Table 4 Accent 3;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 3;';
    wwv_flow_imp.g_varchar2_table(464) := '\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 3;\lsdpriority52 \lsdlocked0 Grid Table 7 Co';
    wwv_flow_imp.g_varchar2_table(465) := 'lorful Accent 3;\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 4;'||wwv_flow.LF||
'\lsdpriority47 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(466) := 'Grid Table 2 Accent 4;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 4;\lsdpriority49 \lsdlocked0 Gr';
    wwv_flow_imp.g_varchar2_table(467) := 'id Table 4 Accent 4;\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 4;'||wwv_flow.LF||
'\lsdpriority51 \lsdlocke';
    wwv_flow_imp.g_varchar2_table(468) := 'd0 Grid Table 6 Colorful Accent 4;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 4;\lsdprio';
    wwv_flow_imp.g_varchar2_table(469) := 'rity46 \lsdlocked0 Grid Table 1 Light Accent 5;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 5;'||wwv_flow.LF||
'\l';
    wwv_flow_imp.g_varchar2_table(470) := 'sdpriority48 \lsdlocked0 Grid Table 3 Accent 5;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 5;\lsd';
    wwv_flow_imp.g_varchar2_table(471) := 'priority50 \lsdlocked0 Grid Table 5 Dark Accent 5;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful A';
    wwv_flow_imp.g_varchar2_table(472) := 'ccent 5;'||wwv_flow.LF||
'\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 5;\lsdpriority46 \lsdlocked0 Grid ';
    wwv_flow_imp.g_varchar2_table(473) := 'Table 1 Light Accent 6;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 6;\lsdpriority48 \lsdlocked0 G';
    wwv_flow_imp.g_varchar2_table(474) := 'rid Table 3 Accent 6;'||wwv_flow.LF||
'\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 6;\lsdpriority50 \lsdlocked0 G';
    wwv_flow_imp.g_varchar2_table(475) := 'rid Table 5 Dark Accent 6;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 6;\lsdpriority52 \';
    wwv_flow_imp.g_varchar2_table(476) := 'lsdlocked0 Grid Table 7 Colorful Accent 6;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 List Table 1 Light;\lsdpriori';
    wwv_flow_imp.g_varchar2_table(477) := 'ty47 \lsdlocked0 List Table 2;\lsdpriority48 \lsdlocked0 List Table 3;\lsdpriority49 \lsdlocked0 Lis';
    wwv_flow_imp.g_varchar2_table(478) := 't Table 4;\lsdpriority50 \lsdlocked0 List Table 5 Dark;'||wwv_flow.LF||
'\lsdpriority51 \lsdlocked0 List Table 6 Col';
    wwv_flow_imp.g_varchar2_table(479) := 'orful;\lsdpriority52 \lsdlocked0 List Table 7 Colorful;\lsdpriority46 \lsdlocked0 List Table 1 Light';
    wwv_flow_imp.g_varchar2_table(480) := ' Accent 1;\lsdpriority47 \lsdlocked0 List Table 2 Accent 1;\lsdpriority48 \lsdlocked0 List Table 3 A';
    wwv_flow_imp.g_varchar2_table(481) := 'ccent 1;'||wwv_flow.LF||
'\lsdpriority49 \lsdlocked0 List Table 4 Accent 1;\lsdpriority50 \lsdlocked0 List Table 5 D';
    wwv_flow_imp.g_varchar2_table(482) := 'ark Accent 1;\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 1;\lsdpriority52 \lsdlocked0 Li';
    wwv_flow_imp.g_varchar2_table(483) := 'st Table 7 Colorful Accent 1;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 2;\lsdpriority47';
    wwv_flow_imp.g_varchar2_table(484) := ' \lsdlocked0 List Table 2 Accent 2;\lsdpriority48 \lsdlocked0 List Table 3 Accent 2;\lsdpriority49 \';
    wwv_flow_imp.g_varchar2_table(485) := 'lsdlocked0 List Table 4 Accent 2;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 2;\lsdpriorit';
    wwv_flow_imp.g_varchar2_table(486) := 'y51 \lsdlocked0 List Table 6 Colorful Accent 2;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Acce';
    wwv_flow_imp.g_varchar2_table(487) := 'nt 2;\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 3;'||wwv_flow.LF||
'\lsdpriority47 \lsdlocked0 List Table ';
    wwv_flow_imp.g_varchar2_table(488) := '2 Accent 3;\lsdpriority48 \lsdlocked0 List Table 3 Accent 3;\lsdpriority49 \lsdlocked0 List Table 4 ';
    wwv_flow_imp.g_varchar2_table(489) := 'Accent 3;\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 3;'||wwv_flow.LF||
'\lsdpriority51 \lsdlocked0 List Tab';
    wwv_flow_imp.g_varchar2_table(490) := 'le 6 Colorful Accent 3;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 3;\lsdpriority46 \lsd';
    wwv_flow_imp.g_varchar2_table(491) := 'locked0 List Table 1 Light Accent 4;\lsdpriority47 \lsdlocked0 List Table 2 Accent 4;'||wwv_flow.LF||
'\lsdpriority4';
    wwv_flow_imp.g_varchar2_table(492) := '8 \lsdlocked0 List Table 3 Accent 4;\lsdpriority49 \lsdlocked0 List Table 4 Accent 4;\lsdpriority50 ';
    wwv_flow_imp.g_varchar2_table(493) := '\lsdlocked0 List Table 5 Dark Accent 4;\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 4;'||wwv_flow.LF||
'\';
    wwv_flow_imp.g_varchar2_table(494) := 'lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 4;\lsdpriority46 \lsdlocked0 List Table 1 Lig';
    wwv_flow_imp.g_varchar2_table(495) := 'ht Accent 5;\lsdpriority47 \lsdlocked0 List Table 2 Accent 5;\lsdpriority48 \lsdlocked0 List Table 3';
    wwv_flow_imp.g_varchar2_table(496) := ' Accent 5;'||wwv_flow.LF||
'\lsdpriority49 \lsdlocked0 List Table 4 Accent 5;\lsdpriority50 \lsdlocked0 List Table 5';
    wwv_flow_imp.g_varchar2_table(497) := ' Dark Accent 5;\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 5;\lsdpriority52 \lsdlocked0 ';
    wwv_flow_imp.g_varchar2_table(498) := 'List Table 7 Colorful Accent 5;'||wwv_flow.LF||
'\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 6;\lsdpriority';
    wwv_flow_imp.g_varchar2_table(499) := '47 \lsdlocked0 List Table 2 Accent 6;\lsdpriority48 \lsdlocked0 List Table 3 Accent 6;\lsdpriority49';
    wwv_flow_imp.g_varchar2_table(500) := ' \lsdlocked0 List Table 4 Accent 6;'||wwv_flow.LF||
'\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 6;\lsdprior';
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
    wwv_flow_imp.g_varchar2_table(501) := 'ity51 \lsdlocked0 List Table 6 Colorful Accent 6;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Ac';
    wwv_flow_imp.g_varchar2_table(502) := 'cent 6;}}{\*\datastore 010500000200000018000000'||wwv_flow.LF||
'4d73786d6c322e534158584d4c5265616465722e362e3000000';
    wwv_flow_imp.g_varchar2_table(503) := '000000000000000060000'||wwv_flow.LF||
'd0cf11e0a1b11ae1000000000000000000000000000000003e000300feff09000600000000000';
    wwv_flow_imp.g_varchar2_table(504) := '0000000000001000000010000000000000000100000feffffff00000000feffffff0000000000000000fffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(505) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(506) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(507) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(508) := 'fffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(509) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(510) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffff';
    wwv_flow_imp.g_varchar2_table(511) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(512) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(513) := 'fffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffdfffffffefffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(514) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(515) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffff';
    wwv_flow_imp.g_varchar2_table(516) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(517) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(518) := 'fffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(519) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(520) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(521) := ''||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(522) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(523) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffff52006f006f007';
    wwv_flow_imp.g_varchar2_table(524) := '400200045006e007400720079000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(525) := '00000000000000016000500ffffffffffffffffffffffff0c6ad98892f1d411a65f0040963251e5000000000000000000000';
    wwv_flow_imp.g_varchar2_table(526) := '000c05c'||wwv_flow.LF||
'd8ca6370d801feffffff00000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(527) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000fffffffffffffffffff';
    wwv_flow_imp.g_varchar2_table(528) := 'fffff00000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(529) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(530) := '000000000000000000000000000000000000000ffffffffffffffffffffffff0000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(531) := '000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(532) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000fff';
    wwv_flow_imp.g_varchar2_table(533) := 'fffffffffffffffffffff000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000';
    wwv_flow_imp.g_varchar2_table(534) := '00000000000000000000105000000000000}}';
wwv_flow_imp_shared.create_report_layout(
 p_id=>wwv_flow_imp.id(16079703843172284899)
,p_report_layout_name=>'Ledger_Report_parameter'
,p_report_layout_type=>'RTF_FILE'
,p_varchar2_table=>wwv_flow_imp.g_varchar2_table
);
wwv_flow_imp.component_end;
end;
/
