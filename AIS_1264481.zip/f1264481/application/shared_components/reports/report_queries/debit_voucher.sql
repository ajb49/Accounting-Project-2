prompt --application/shared_components/reports/report_queries/debit_voucher
begin
--   Manifest
--     WEB SERVICE: Debit_Voucher
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_shared_query(
 p_id=>wwv_flow_imp.id(16057297008281005890)
,p_name=>'Debit_Voucher'
,p_query_text=>'select date_of_transaction, particulars, debit amount from transaction_tables where dv_id is not null and debit > 0;'
,p_report_layout_id=>wwv_flow_imp.id(16060106655281051983)
,p_format=>'PDF'
,p_output_file_name=>'Debit_Voucher'
,p_content_disposition=>'INLINE'
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(16060113934092053555)
,p_shared_query_id=>wwv_flow_imp.id(16057297008281005890)
,p_sql_statement=>'select date_of_transaction, particulars, debit amount from transaction_tables where dv_id is not null and debit > 0;'
);
wwv_flow_imp.component_end;
end;
/
