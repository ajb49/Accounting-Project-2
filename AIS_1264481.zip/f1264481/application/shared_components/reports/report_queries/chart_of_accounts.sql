prompt --application/shared_components/reports/report_queries/chart_of_accounts
begin
--   Manifest
--     WEB SERVICE: chart_of_accounts
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_shared_query(
 p_id=>wwv_flow_imp.id(1392985443775822269)
,p_name=>'chart_of_accounts'
,p_query_text=>'SELECT acc_id, particulars, accounts_head FROM ACCOUNTS_VIEW;'
,p_report_layout_id=>wwv_flow_imp.id(1393527803466260046)
,p_format=>'PDF'
,p_output_file_name=>'chart_of_accounts'
,p_content_disposition=>'INLINE'
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(1402235946495310480)
,p_shared_query_id=>wwv_flow_imp.id(1392985443775822269)
,p_sql_statement=>'SELECT acc_id, particulars, accounts_head FROM ACCOUNTS_VIEW;'
);
wwv_flow_imp.component_end;
end;
/
