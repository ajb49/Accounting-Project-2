prompt --application/shared_components/reports/report_queries/credit_voucher
begin
--   Manifest
--     WEB SERVICE: Credit_Voucher
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_shared_query(
 p_id=>wwv_flow_imp.id(16062283144778893459)
,p_name=>'Credit_Voucher'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select date_of_transaction, particulars, credit amount from transaction_tables where cv_id is not null and credit > 0;',
''))
,p_report_layout_id=>wwv_flow_imp.id(16062678741962912037)
,p_format=>'PDF'
,p_output_file_name=>'Credit_Voucher'
,p_content_disposition=>'INLINE'
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(16062681566685913500)
,p_shared_query_id=>wwv_flow_imp.id(16062283144778893459)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select date_of_transaction, particulars, credit amount from transaction_tables where cv_id is not null and credit > 0;',
''))
);
wwv_flow_imp.component_end;
end;
/
