prompt --application/shared_components/reports/report_queries/company_info
begin
--   Manifest
--     WEB SERVICE: COMPANY_INFO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_shared_query(
 p_id=>wwv_flow_imp.id(1409301430926131536)
,p_name=>'COMPANY_INFO'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select COMPANY_ID,',
'       COMPANY_NAME,',
'       ADDRESS,',
'       PHONE,',
'       FAX,',
'       EMAIL',
'  from COMPANY_DETAILS'))
,p_report_layout_id=>wwv_flow_imp.id(1410090043887221280)
,p_format=>'PDF'
,p_output_file_name=>'COMPANY_INFO'
,p_content_disposition=>'INLINE'
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(1410380498920607334)
,p_shared_query_id=>wwv_flow_imp.id(1409301430926131536)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select COMPANY_NAME,',
'       ADDRESS,',
'       PHONE,',
'       FAX,',
'       EMAIL',
'  from COMPANY_DETAILS'))
);
wwv_flow_imp.component_end;
end;
/
