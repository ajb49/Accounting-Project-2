prompt --application/shared_components/reports/report_queries/balance_sheet
begin
--   Manifest
--     WEB SERVICE: Balance_sheet
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_shared_query(
 p_id=>wwv_flow_imp.id(8419867310470899869)
,p_name=>'Balance_sheet'
,p_query_text=>'SELECT * FROM company_details'
,p_report_layout_id=>wwv_flow_imp.id(30571778573879384467)
,p_format=>'PDF'
,p_output_file_name=>'Balance_sheet'
,p_content_disposition=>'INLINE'
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(30571947670955607691)
,p_shared_query_id=>wwv_flow_imp.id(8419867310470899869)
,p_sql_statement=>'SELECT * FROM company_details where company_id = 101'
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(30571947838757607691)
,p_shared_query_id=>wwv_flow_imp.id(8419867310470899869)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(particulars,''N/A'') particulars_asset, nvl(balanced,0) amount from current_asset_pro',
'union',
'select nvl(particulars,''N/A''), nvl(balanced,0) from fixed_asset_pro',
'union',
'select nvl(particulars,''N/A''), nvl(balanced,0) from contra_asset_pro;'))
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(30571948062957607691)
,p_shared_query_id=>wwv_flow_imp.id(8419867310470899869)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sum(nvl(amount,0)) Total_amount_asset from (select nvl(particulars,''N/A'') particulars, nvl(balanced,0) amount from current_asset_pro',
'union',
'select nvl(particulars,''N/A''), nvl(balanced,0) from fixed_asset_pro',
'union',
'select nvl(particulars,''N/A''), nvl(balanced,0) from contra_asset_pro);'))
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(30571948227772607691)
,p_shared_query_id=>wwv_flow_imp.id(8419867310470899869)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(particulars,''N/A'') particulars, nvl(balanced,0) amount_liabilities from current_liabilities_pro',
'union',
'select nvl(particulars,''N/A''), nvl(balanced,0) from fixed_liabilities_pro',
'union',
'select nvl(particulars,''N/A''), nvl(balanced,0) from contra_liabilities_pro;'))
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(30571948491469607691)
,p_shared_query_id=>wwv_flow_imp.id(8419867310470899869)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sum(nvl(amount,0)) Total_amount_Liabilities from (select nvl(particulars,''N/A'') particulars, nvl(balanced,0) amount from current_liabilities_pro',
'union',
'select nvl(particulars,''N/A''), nvl(balanced,0) from fixed_liabilities_pro',
'union',
'select nvl(particulars,''N/A''), nvl(balanced,0) from contra_liabilities_pro);'))
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(30571948686871607692)
,p_shared_query_id=>wwv_flow_imp.id(8419867310470899869)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(particulars,''N/A'') particulars_owner_equity, nvl(balanced,0) amount from owner_equity_pro',
'union',
'select nvl(particulars,''N/A''), nvl(balanced,0) from contra_equity_pro',
'union',
'select nvl(description,''N/A''), nvl(net_amount,0) from inc_state;',
''))
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(30571948846775607692)
,p_shared_query_id=>wwv_flow_imp.id(8419867310470899869)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sum(nvl(amount,0)) Total_amount_equity from (select nvl(particulars,''N/A'') particulars, nvl(balanced,0) amount from owner_equity_pro',
'union',
'select nvl(particulars,''N/A''), nvl(balanced,0) from contra_equity_pro',
'union',
'select nvl(description,''N/A''), nvl(net_amount,0) from inc_state);'))
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(30571949043327607692)
,p_shared_query_id=>wwv_flow_imp.id(8419867310470899869)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select abs(sum(total)) total_both_LQ from (',
'select sum(amount) total from (',
'select  balanced amount from current_liabilities_pro',
'UNION',
'select balanced amount from fixed_liabilities_pro',
'UNION',
'select  balanced amount from contra_liabilities_pro)',
'union',
'select sum(amount) total_equity from (',
'select balanced amount from owner_equity_pro',
'UNION',
'select balanced from contra_equity_pro',
'UNION',
'select net_amount from inc_state));'))
);
wwv_flow_imp.component_end;
end;
/
