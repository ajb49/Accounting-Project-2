prompt --application/shared_components/reports/report_queries/ledger
begin
--   Manifest
--     WEB SERVICE: Ledger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_shared_query(
 p_id=>wwv_flow_imp.id(16079046729045468318)
,p_name=>'Ledger'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select date_of_transaction, narration, debit, credit ',
'from ledger_pro ',
'where (particulars = :P8_PARTICULARS OR :P8_PARTICULARS is null);'))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_imp.id(16079703843172284899)
,p_format=>'PDF'
,p_output_file_name=>'Ledger'
,p_content_disposition=>'INLINE'
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(16079789344587507770)
,p_shared_query_id=>wwv_flow_imp.id(16079046729045468318)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select date_of_transaction, narration, debit, credit ',
'from ledger_pro ',
'where (particulars = :P8_PARTICULARS OR :P8_PARTICULARS is null);'))
);
wwv_flow_imp.component_end;
end;
/
