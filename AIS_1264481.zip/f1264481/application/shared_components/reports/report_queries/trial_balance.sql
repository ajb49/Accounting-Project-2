prompt --application/shared_components/reports/report_queries/trial_balance
begin
--   Manifest
--     WEB SERVICE: Trial_balance
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_shared_query(
 p_id=>wwv_flow_imp.id(16224637849786896044)
,p_name=>'Trial_balance'
,p_query_text=>'select particulars, debit,credit from trial_balance_pro;'
,p_report_layout_id=>wwv_flow_imp.id(16225359072720949511)
,p_format=>'PDF'
,p_output_file_name=>'Trial_balance'
,p_content_disposition=>'INLINE'
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(16225307376703729770)
,p_shared_query_id=>wwv_flow_imp.id(16224637849786896044)
,p_sql_statement=>'select particulars, debit,credit from trial_balance_pro;'
);
wwv_flow_imp.component_end;
end;
/
