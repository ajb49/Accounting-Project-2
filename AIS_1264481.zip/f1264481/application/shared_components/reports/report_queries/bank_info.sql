prompt --application/shared_components/reports/report_queries/bank_info
begin
--   Manifest
--     WEB SERVICE: bank_info
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_shared_query(
 p_id=>wwv_flow_imp.id(1406472642328416509)
,p_name=>'bank_info'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bn.bank_name,',
'br.BRANCH_CODE,',
'       br.BRANCH_NAME,',
'       br.DISTRICT_CODE,',
'       br.BRANCH_ADDRESS,',
'       br.PHONE_NUMBER,',
'       br.EMAIL',
'  from BRANCH_INFORMATION br, bank_information bn',
'  where br.bank_code=bn.bank_code'))
,p_report_layout_id=>wwv_flow_imp.id(1408438845162077044)
,p_format=>'PDF'
,p_output_file_name=>'bank_info'
,p_content_disposition=>'INLINE'
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(1408383101618463712)
,p_shared_query_id=>wwv_flow_imp.id(1406472642328416509)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bn.bank_name,',
'br.BRANCH_CODE,',
'       br.BRANCH_NAME,',
'       br.DISTRICT_CODE,',
'       br.BRANCH_ADDRESS,',
'       br.PHONE_NUMBER,',
'       br.EMAIL',
'  from BRANCH_INFORMATION br, bank_information bn',
'  where br.bank_code=bn.bank_code'))
);
wwv_flow_imp.component_end;
end;
/
