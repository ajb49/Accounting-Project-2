prompt --application/shared_components/security/authentications/free_access
begin
--   Manifest
--     AUTHENTICATION: Free_access
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(55594426411435798310)
,p_name=>'Free_access'
,p_scheme_type=>'NATIVE_DAD'
,p_attribute_01=>'nobody'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
