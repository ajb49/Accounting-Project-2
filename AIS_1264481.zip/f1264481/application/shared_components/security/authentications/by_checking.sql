prompt --application/shared_components/security/authentications/by_checking
begin
--   Manifest
--     AUTHENTICATION: By_Checking
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(21700395240152075971)
,p_name=>'By_Checking'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'USER_CATCH'
,p_attribute_05=>'N'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
