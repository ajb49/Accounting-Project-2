prompt --application/shared_components/navigation/lists/journal_voucher_entry
begin
--   Manifest
--     LIST: Journal Voucher Entry
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(30218670986776953709)
,p_name=>'Journal Voucher Entry'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(30218672358173953712)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Basic Information'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(30218676614595953714)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Journal Posting'
,p_list_item_link_target=>'f?p=&APP_ID.:56:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
