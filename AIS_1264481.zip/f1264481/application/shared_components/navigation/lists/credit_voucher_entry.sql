prompt --application/shared_components/navigation/lists/credit_voucher_entry
begin
--   Manifest
--     LIST: Credit Voucher Entry
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(30212464688619710175)
,p_name=>'Credit Voucher Entry'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(30212466069553710178)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Basic Information'
,p_list_item_link_target=>'f?p=&APP_ID.:53:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(30212470316077710180)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Journal Posting'
,p_list_item_link_target=>'f?p=&APP_ID.:54:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
