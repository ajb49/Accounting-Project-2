prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(55594628267229176511)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55594824376247176597)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55697289410632783413)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Setup'
,p_list_item_icon=>'fa-edit'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55697444310794179746)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Chart of Account'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clipboard-list'
,p_parent_list_item_id=>wwv_flow_imp.id(55697289410632783413)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55697781138443804385)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Bank'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-university'
,p_parent_list_item_id=>wwv_flow_imp.id(55697289410632783413)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55697964276853194178)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Company'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-building-o'
,p_parent_list_item_id=>wwv_flow_imp.id(55697289410632783413)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55697323195452789352)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Transaction (Posting)'
,p_list_item_icon=>'fa-exchange'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(30453770166942154263)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>'Credit Voucher Entry'
,p_list_item_link_target=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-circle-arrow-in-sw'
,p_parent_list_item_id=>wwv_flow_imp.id(55697323195452789352)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(30453691116082937415)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'Debit Voucher Entry'
,p_list_item_link_target=>'f?p=&APP_ID.:44:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-circle-arrow-out-nw'
,p_parent_list_item_id=>wwv_flow_imp.id(55697323195452789352)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(30453976800330944541)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'Journal Voucher Entry'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tags'
,p_parent_list_item_id=>wwv_flow_imp.id(55697323195452789352)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(30465515058104588663)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>'Outright Entries'
,p_list_item_link_target=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-flag-pennant-o'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :global_user_role in (1000) then --1000 id is for administration',
'RETURN TRUE;',
'ELSE',
'RETURN FALSE;',
'END IF;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(55697323195452789352)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(21894601768532337802)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'User Authentication'
,p_list_item_icon=>'fa-user-wrench'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :global_user_role in (1000) then --1000 id is for administration',
'RETURN TRUE;',
'ELSE',
'RETURN FALSE;',
'END IF;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(21894777220475343041)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Users'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-man'
,p_parent_list_item_id=>wwv_flow_imp.id(21894601768532337802)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(21896832520731409220)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Roles'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-pointer'
,p_parent_list_item_id=>wwv_flow_imp.id(21894601768532337802)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(21899908385142517240)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Rights_of_Users'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-user-check'
,p_parent_list_item_id=>wwv_flow_imp.id(21894601768532337802)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'30'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29796353071961938832)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Accounts Section'
,p_list_item_icon=>'fa-server-search'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29796405855532944625)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Ledger'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clipboard-list'
,p_parent_list_item_id=>wwv_flow_imp.id(29796353071961938832)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29796691258320733553)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Trial Balance'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tasks'
,p_parent_list_item_id=>wwv_flow_imp.id(29796353071961938832)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29796911082606741595)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Income Statement'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badges'
,p_parent_list_item_id=>wwv_flow_imp.id(29796353071961938832)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29797018681194747530)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'Financial Statement'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-forms'
,p_parent_list_item_id=>wwv_flow_imp.id(29796353071961938832)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(30461012214103427709)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>'Journal Statement'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-media-list'
,p_parent_list_item_id=>wwv_flow_imp.id(29796353071961938832)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29797361225087755576)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Analysis'
,p_list_item_icon=>'fa-polar-chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29797857509017984911)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'Ratio'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-percent'
,p_parent_list_item_id=>wwv_flow_imp.id(29797361225087755576)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
