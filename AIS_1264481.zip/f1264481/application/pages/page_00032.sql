prompt --application/pages/page_00032
begin
--   Manifest
--     PAGE: 00032
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_page.create_page(
 p_id=>32
,p_user_interface_id=>wwv_flow_imp.id(55594815867856176587)
,p_name=>'Step 1'
,p_alias=>'STEP-12'
,p_page_mode=>'MODAL'
,p_step_title=>'Journal Voucher'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(55594657473878176524)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'700'
,p_dialog_width=>'900'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220807100107'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30218671883218953711)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(30218670986776953709)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(55594786989667176574)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30218671988980953711)
,p_plug_name=>'Step 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30212506625443715834)
,p_plug_name=>'Journal'
,p_parent_plug_id=>wwv_flow_imp.id(30218671988980953711)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'JOURNAL_TABLES'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30218672089594953711)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594666903234176528)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(30218673593815953713)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(30218672089594953711)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(55594791148058176576)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(30218673895457953713)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(30218672089594953711)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(55594791218143176576)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(30218675452558953714)
,p_branch_action=>'f?p=&APP_ID.:56:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(30218673895457953713)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30212506865934715836)
,p_name=>'P32_JV_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_source_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT GREATEST((SELECT MAX(dv_id) FROM debit_tables),  ',
'              (SELECT MAX(cv_id) FROM credit_tables), ',
'              (SELECT MAX(jv_id) FROM journal_tables)) + 1 ',
'              FROM dual;'))
,p_item_default_type=>'SQL_QUERY'
,p_source=>'JV_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30212506977315715837)
,p_name=>'P32_DATE_OF_TRANSACTION'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_source_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_default=>'SELECT CURRENT_TIMESTAMP FROM DUAL;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'<b>Date Of Transaction</b>'
,p_source=>'DATE_OF_TRANSACTION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30212507096330715838)
,p_name=>'P32_NARRATION'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_source_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_prompt=>'<b>Narration</b>'
,p_source=>'NARRATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>50
,p_cMaxlength=>255
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30212507125681715839)
,p_name=>'P32_VOUCHER_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_source_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_default=>'jr'
,p_source=>'VOUCHER_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30212507229285715840)
,p_name=>'P32_VOUCHER_NO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_source_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_default=>'select max(voucher_no)+1 from journal_tables;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Voucher No'
,p_source=>'VOUCHER_NO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30212507305881715841)
,p_name=>'P32_USER_ID'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_source_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_default=>'select user from dual;'
,p_item_default_type=>'SQL_QUERY'
,p_source=>'USER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30212507420653715842)
,p_name=>'P32_PAYMENT_MODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_source_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_prompt=>'<b>Payment Mode</b>'
,p_source=>'PAYMENT_MODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Credit;Credit'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30212507519964715843)
,p_name=>'P32_JOB_ID'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_source_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_default=>'FI_ACCOUNT'
,p_source=>'JOB_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30212507654168715844)
,p_name=>'P32_SUPPLIER_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_source_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_prompt=>'Supplier Name'
,p_source=>'SUPPLIER_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>70
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30212507735539715845)
,p_name=>'P32_PHONE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_source_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_prompt=>'Phone'
,p_source=>'PHONE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30212507822265715846)
,p_name=>'P32_ADDRESS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_source_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_prompt=>'Address'
,p_source=>'ADDRESS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>500
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30212507965125715847)
,p_name=>'P32_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_item_source_plug_id=>wwv_flow_imp.id(30212506625443715834)
,p_prompt=>'Email'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30218673935685953713)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(30218673593815953713)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30218674797791953713)
,p_event_id=>wwv_flow_imp.id(30218673935685953713)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(30212508054444715848)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PK_ROW_ADD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    NEW_PK            VARCHAR2 (30) :=  NULL;',
'BEGIN',
'',
' SELECT GREATEST((SELECT MAX(dv_id) FROM debit_tables),  ',
'              (SELECT MAX(cv_id) FROM credit_tables), ',
'              (SELECT MAX(jv_id) FROM journal_tables))  voucher_sequence ',
'INTO NEW_PK ',
'              FROM dual; ',
'    ',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 1;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ',
'    :P32_JV_ID := NEW_PK;',
'',
'INSERT INTO journal_tables(jv_id,date_of_transaction,narration,voucher_type,voucher_no,user_id,payment_mode,supplier_name,phone,address,email,job_id)',
'									VALUES (NEW_PK,:P32_DATE_OF_TRANSACTION,:P32_NARRATION,:P32_VOUCHER_TYPE,:P32_VOUCHER_NO,USER,:P32_PAYMENT_MODE,:P32_SUPPLIER_NAME,:P32_PHONE,:P32_ADDRESS,',
'									:P32_EMAIL,''FI_ACCOUNT'');',
'',
'',
'EXCEPTION',
' WHEN OTHERS THEN',
'   HTP.P(SQLERRM);',
'END;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(30218673895457953713)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(30212506783278715835)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(30212506625443715834)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Step 1'
);
wwv_flow_imp.component_end;
end;
/
