prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_imp.id(55594815867856176587)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'AIS'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//reloading the chat classic report in 1 sec',
'setInterval (" jQuery (''#seco'').trigger (''apexrefresh'');", 1000);',
'//reloading the chat classic report in 10 sec',
'setInterval (" jQuery (''#bb'').trigger (''apexrefresh'');", 10000);',
'//reloading the chat classic report in 10 sec',
'setInterval (" jQuery (''#ar'').trigger (''apexrefresh'');", 10000);',
'//reloading the chat classic report in 10 sec',
'setInterval (" jQuery (''#ap'').trigger (''apexrefresh'');", 10000);',
'//reloading the chat classic report in 10 sec',
'setInterval (" jQuery (''#r'').trigger (''apexrefresh'');", 10000);',
'//reloading the chat classic report in 10 sec',
'setInterval (" jQuery (''#e'').trigger (''apexrefresh'');", 10000);',
'//reloading the chat classic report in 10 sec',
'setInterval (" jQuery (''#ratio'').trigger (''apexrefresh'');", 10000);'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*to hide loading circle*/',
'.u-Processing {',
'   display:none !important;',
'}',
''))
,p_page_css_classes=>'b_sheet3'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220810064842'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21700414831188080234)
,p_plug_name=>'UserName'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :global_user_role in (1000) then --1000 id is for administration',
'RETURN TRUE;',
'ELSE',
'RETURN FALSE;',
'END IF;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30452045185276072333)
,p_plug_name=>'Ratio Analysis'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(30452045268778072334)
,p_name=>'Gross Profit Margin'
,p_region_name=>'ratio'
,p_parent_plug_id=>wwv_flow_imp.id(30452045185276072333)
,p_template=>wwv_flow_imp.id(55594664177883176527)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--circular:t-BadgeList--fixed'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ratio_gross(:P1_COMPANY_ID) Gross_profit_mergin, ',
'RATIO_NET(:P1_COMPANY_ID) net_profit_mergin,',
'ratio_cash(:P1_COMPANY_ID) cash_ratio,',
'ratio_current(:P1_COMPANY_ID) current_ratio',
'from dual;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P1_COMPANY_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(55594738178605176554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30452046237960072344)
,p_query_column_id=>1
,p_column_alias=>'GROSS_PROFIT_MERGIN'
,p_column_display_sequence=>10
,p_column_heading=>'Gross Profit Mergin'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17::'
,p_column_linktext=>'#GROSS_PROFIT_MERGIN#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30452046366952072345)
,p_query_column_id=>2
,p_column_alias=>'NET_PROFIT_MERGIN'
,p_column_display_sequence=>20
,p_column_heading=>'Net Profit Mergin'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17::'
,p_column_linktext=>'#NET_PROFIT_MERGIN#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30452046471732072346)
,p_query_column_id=>3
,p_column_alias=>'CASH_RATIO'
,p_column_display_sequence=>30
,p_column_heading=>'Cash Ratio'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17::'
,p_column_linktext=>'#CASH_RATIO#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30452046592489072347)
,p_query_column_id=>4
,p_column_alias=>'CURRENT_RATIO'
,p_column_display_sequence=>40
,p_column_heading=>'Current Ratio'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17::'
,p_column_linktext=>'#CURRENT_RATIO#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30508810230636487921)
,p_plug_name=>'Daily Income'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(55594718533205176547)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct date_of_transaction, to_char(tt.date_of_transaction,''DD-Mon-YY'') as "Date", abs(sum(tt.debit - tt.credit)) revenue_amount',
'from transaction_tables tt, accounts acc, categories cat',
'where tt.acc_id=acc.acc_id and acc.c_id = cat.c_id',
'and cat.c_id IN (900,1000,1400)',
'group by date_of_transaction, to_char(tt.date_of_transaction,''DD-Mon-YY'')',
'order by 1 desc;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(30508810317583487922)
,p_region_id=>wwv_flow_imp.id(30508810230636487921)
,p_chart_type=>'lineWithArea'
,p_height=>'200'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_no_data_found_message=>'Please Input Data'
,p_automatic_refresh_interval=>10
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(30508810404774487923)
,p_chart_id=>wwv_flow_imp.id(30508810317583487922)
,p_seq=>10
,p_name=>'Revenue'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'REVENUE_AMOUNT'
,p_items_label_column_name=>'Date'
,p_color=>'#71db63'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(30508810579026487924)
,p_chart_id=>wwv_flow_imp.id(30508810317583487922)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(30508810646151487925)
,p_chart_id=>wwv_flow_imp.id(30508810317583487922)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30508810792242487926)
,p_plug_name=>'Chart_Gather1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>60
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2094857188392281309)
,p_plug_name=>'Comparison Between Current Asset & Fixed Asset'
,p_region_name=>'vs'
,p_parent_plug_id=>wwv_flow_imp.id(30508810792242487926)
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--accent14:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(55594718533205176547)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(2094857214844281310)
,p_region_id=>wwv_flow_imp.id(2094857188392281309)
,p_chart_type=>'bar'
,p_height=>'250'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_no_data_found_message=>'Please Input Asset Data'
,p_automatic_refresh_interval=>10
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(2094857346049281311)
,p_chart_id=>wwv_flow_imp.id(2094857214844281310)
,p_seq=>10
,p_name=>'Asset'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NVL(NULL,''CURRENT ASSET'') PARTICULARS, SUM(BALANCED) AMOUNT',
'FROM CURRENT_ASSET_PRO',
'UNION',
'SELECT NVL(NULL,''FIXED ASSET''), SUM(BALANCED) AS FIXED_ASSET ',
'FROM FIXED_ASSET_PRO;'))
,p_items_value_column_name=>'AMOUNT'
,p_items_label_column_name=>'PARTICULARS'
,p_color=>'#0ba277'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(2094857400527281312)
,p_chart_id=>wwv_flow_imp.id(2094857214844281310)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(2094857596380281313)
,p_chart_id=>wwv_flow_imp.id(2094857214844281310)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21700411766119080203)
,p_plug_name=>'Accounts States'
,p_region_name=>'as'
,p_parent_plug_id=>wwv_flow_imp.id(30508810792242487926)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(date_of_transaction, ''YYYY'') Yearly, abs(sum(debit-credit)) amount',
'from transaction_tables',
'where (particulars = :P1_ACCOUNTS or :P1_ACCOUNTS is null)',
'group by to_char(date_of_transaction, ''YYYY'')',
'order by 2 desc;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P1_ACCOUNTS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(21700411887893080204)
,p_region_id=>wwv_flow_imp.id(21700411766119080203)
,p_chart_type=>'donut'
,p_height=>'300'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_no_data_found_message=>'Please Input data'
,p_automatic_refresh_interval=>10
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(21700411930834080205)
,p_chart_id=>wwv_flow_imp.id(21700411887893080204)
,p_seq=>10
,p_name=>'Account State'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'AMOUNT'
,p_items_label_column_name=>'YEARLY'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30508811066995487929)
,p_plug_name=>'first_line'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30508810986313487928)
,p_plug_name=>'Badges'
,p_parent_plug_id=>wwv_flow_imp.id(30508811066995487929)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(29869174562632427144)
,p_name=>'Bank Balance'
,p_region_name=>'bb'
,p_parent_plug_id=>wwv_flow_imp.id(30508810986313487928)
,p_template=>wwv_flow_imp.id(55594664177883176527)
,p_display_sequence=>10
,p_icon_css_classes=>'fa-university'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--stacked'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('SELECT ''\D83C\DFDB ''||''BDT ''||TO_CHAR(SUM(DEBIT-CREDIT),''999G99G99G990D99PR'') as Bank_Balance '),
'FROM TRANSACTION_TABLES ',
'WHERE DEBIT IS NOT NULL ',
'AND UPPER(PARTICULARS) LIKE UPPER(''%BANK%'');',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(55594738178605176554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(29869175132918427150)
,p_query_column_id=>1
,p_column_alias=>'BANK_BALANCE'
,p_column_display_sequence=>10
,p_column_heading=>'Bank Balance'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(29887359602102177701)
,p_name=>'Account Receivable'
,p_region_name=>'ar'
,p_parent_plug_id=>wwv_flow_imp.id(30508810986313487928)
,p_template=>wwv_flow_imp.id(55594664177883176527)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--fixed'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''BDT ''||TO_CHAR(SUM(DEBIT-CREDIT),''999G99G99G990D99PR'') as "Accounts Receivable" ',
'FROM TRANSACTION_TABLES ',
'WHERE DEBIT IS NOT NULL ',
'AND UPPER(PARTICULARS) LIKE UPPER(''%RECEIVA%'')',
'AND UPPER(PARTICULARS) LIKE UPPER(''%ACC%'');'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(55594738178605176554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30222407942040254215)
,p_query_column_id=>1
,p_column_alias=>'Accounts Receivable'
,p_column_display_sequence=>10
,p_column_heading=>'Accounts Receivable'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(29887359906300177704)
,p_name=>'Account Payable'
,p_region_name=>'ap'
,p_parent_plug_id=>wwv_flow_imp.id(30508810986313487928)
,p_template=>wwv_flow_imp.id(55594664177883176527)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--fixed'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''BDT ''||TO_CHAR(SUM(DEBIT-CREDIT),''999G99G99G990D99PR'') FROM TRANSACTION_TABLES WHERE DEBIT IS NOT NULL AND UPPER(PARTICULARS) LIKE UPPER(''%PAYABL%'') AND ',
'UPPER(PARTICULARS) LIKE UPPER(''%ACC%'')'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(55594738178605176554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30222407872905254214)
,p_query_column_id=>1
,p_column_alias=>'''BDT''||TO_CHAR(SUM(DEBIT-CREDIT),''999G99G99G990D99PR'')'
,p_column_display_sequence=>10
,p_column_heading=>'Accounts Payable'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(29887360140562177706)
,p_name=>'Expense'
,p_region_name=>'e'
,p_parent_plug_id=>wwv_flow_imp.id(30508810986313487928)
,p_template=>wwv_flow_imp.id(55594664177883176527)
,p_display_sequence=>30
,p_region_css_classes=>'b_sheet2'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--fixed'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'SELECT accounts_head, ''BDT ''||to_char(abs(amount),''999g99g99g990d99'') as expense FROM CHART_OF_ACC WHERE ACCOUNTS_HEAD IN (''Expense'');'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(55594738178605176554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(29887360218652177707)
,p_query_column_id=>1
,p_column_alias=>'ACCOUNTS_HEAD'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(29887360456928177709)
,p_query_column_id=>2
,p_column_alias=>'EXPENSE'
,p_column_display_sequence=>20
,p_column_heading=>'Expense'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31::'
,p_column_linktext=>'#EXPENSE#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(29887360579071177710)
,p_name=>'Revenue'
,p_region_name=>'r'
,p_parent_plug_id=>wwv_flow_imp.id(30508810986313487928)
,p_template=>wwv_flow_imp.id(55594664177883176527)
,p_display_sequence=>20
,p_region_css_classes=>'b_sheet'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--fixed'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'SELECT accounts_head, ''BDT ''||to_char(abs(amount),''999g99g99g990d99'') as INCOME FROM CHART_OF_ACC WHERE ACCOUNTS_HEAD IN (''Revenue'');'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(55594738178605176554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(29887360657735177711)
,p_query_column_id=>1
,p_column_alias=>'ACCOUNTS_HEAD'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(29887360822469177713)
,p_query_column_id=>2
,p_column_alias=>'INCOME'
,p_column_display_sequence=>20
,p_column_heading=>'Income'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31::'
,p_column_linktext=>'#INCOME#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30508811106080487930)
,p_plug_name=>'Company_details'
,p_parent_plug_id=>wwv_flow_imp.id(30508811066995487929)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<html>',
'    <body>',
unistr('<h4 style="color:blue;"><b>Samsung Bangladesh Ltd.<sup>\2122</sup></b></h4>'),
'<h5>Taltola, Mirpur Dhaka 1207 </h5>',
'<h5>samsungbd@yahoo.com, 01755001235</h5>',
'<hr>',
'    </body>',
'</html>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(30508811299641487931)
,p_name=>'Time'
,p_region_name=>'seco'
,p_parent_plug_id=>wwv_flow_imp.id(30508811106080487930)
,p_template=>wwv_flow_imp.id(55594664177883176527)
,p_display_sequence=>10
,p_region_template_options=>'margin-top-none:margin-left-none:margin-right-lg'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'select to_char(current_timestamp,''fmDay, Month DD, YYYY hh:mi:ss AM'') from dual;'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(55594756141401176562)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(37790270432016738545)
,p_query_column_id=>1
,p_column_alias=>'TO_CHAR(CURRENT_TIMESTAMP,''FMDAY,MONTHDD,YYYYHH:MI:SSAM'')'
,p_column_display_sequence=>10
,p_column_heading=>'To Char(current Timestamp,&#x27;fmday,monthdd,yyyyhh:mi:ssam&#x27;)'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38057088739667276606)
,p_plug_name=>'Daily Expense'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(55594718533205176547)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct date_of_transaction, to_char(tt.date_of_transaction,''DD-Mon-YY'') as "Date", abs(sum(tt.debit - tt.credit)) revenue_amount',
'from transaction_tables tt, accounts acc, categories cat',
'where tt.acc_id=acc.acc_id and acc.c_id = cat.c_id',
'and cat.c_id IN (1200,1300,1100)',
'group by date_of_transaction, to_char(tt.date_of_transaction,''DD-Mon-YY'')',
'order by 1 desc;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(38057088855658276607)
,p_region_id=>wwv_flow_imp.id(38057088739667276606)
,p_chart_type=>'lineWithArea'
,p_height=>'200'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_no_data_found_message=>'Please Input Data'
,p_automatic_refresh_interval=>10
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(38057088950179276608)
,p_chart_id=>wwv_flow_imp.id(38057088855658276607)
,p_seq=>10
,p_name=>'Expense'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'REVENUE_AMOUNT'
,p_items_label_column_name=>'Date'
,p_color=>'#dc7354'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(38057089055881276609)
,p_chart_id=>wwv_flow_imp.id(38057088855658276607)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(38057089112463276610)
,p_chart_id=>wwv_flow_imp.id(38057088855658276607)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21700412258493080208)
,p_name=>'P1_ACCOUNTS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(21700411766119080203)
,p_prompt=>'<b>Accounts State by Year</b>'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct tt.particulars d, tt.particulars r from accounts ac, transaction_tables tt',
'where ac.acc_id = tt.acc_id',
'and tt.particulars IS NOT NULL;'))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21700414919937080235)
,p_name=>'P1_USER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(21700414831188080234)
,p_prompt=>'User'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30452045328611072335)
,p_name=>'P1_COMPANY_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(30452045185276072333)
,p_prompt=>'<b>Company Name</b>'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'COMPANY_LIST'
,p_lov=>'select company_id r, company_name d from company_details;'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Select Company --'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21700412394391080209)
,p_name=>'Refresh_Donut'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_ACCOUNTS'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21700412498504080210)
,p_event_id=>wwv_flow_imp.id(21700412394391080209)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(21700411766119080203)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21992359042729980901)
,p_name=>'Identify_User'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21992359181868980902)
,p_event_id=>wwv_flow_imp.id(21992359042729980901)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_USER'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT userid ',
'FROM user_roles ap, USER_IDENTITIES u',
'WHERE ap.idnt= u.idnt and',
'ap.idnt = :GLOBAL_USER_ID'))
,p_attribute_07=>'GLOBAL_USER_ID'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30452045426883072336)
,p_name=>'Refresh_ratio'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_COMPANY_ID'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30452045585363072337)
,p_event_id=>wwv_flow_imp.id(30452045426883072336)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(30452045268778072334)
);
wwv_flow_imp.component_end;
end;
/
