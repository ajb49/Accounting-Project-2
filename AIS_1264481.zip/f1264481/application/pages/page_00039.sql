prompt --application/pages/page_00039
begin
--   Manifest
--     PAGE: 00039
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_page.create_page(
 p_id=>39
,p_user_interface_id=>wwv_flow_imp.id(55594815867856176587)
,p_name=>'Data_Entry_Form'
,p_alias=>'DATA-ENTRY-FORM1'
,p_step_title=>'Outright Entries'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220807091321'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(68848898284519669053)
,p_plug_name=>'Today'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(68848898555628669055)
,p_plug_name=>'Data_Entry'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'acc_up'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(30457309721810143753)
,p_button_sequence=>220
,p_button_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_button_name=>'Create_new_account'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(55594790466687176576)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create New Account'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5::'
,p_icon_css_classes=>'fa-edit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(30457310100662143753)
,p_button_sequence=>230
,p_button_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_button_name=>'Create_new_account2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(55594790466687176576)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create New Account'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5::'
,p_icon_css_classes=>'fa-edit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(30457310516957143754)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_button_name=>'CREATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--warning:t-Button--iconRight:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_imp.id(55594791218143176576)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add'
,p_button_position=>'TOP'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-server-plus'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457309079434143753)
,p_name=>'DATES'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(68848898284519669053)
,p_item_default=>'CURRENT_TIMESTAMP'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Date'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457310954972143754)
,p_name=>'COMPANY_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Company'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'COMPANY_LIST1'
,p_lov=>'select company_id r, company_name d from company_details;'
,p_cHeight=>1
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457311341034143754)
,p_name=>'VOU_TYPE'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Voucher'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Debit;dr,Credit;cr,Journal;jr'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457311782769143754)
,p_name=>'BANK_NAMING'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Bank Name'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'BANK_LIST1'
,p_lov=>'select bank_name r, bank_name d from bank_information;'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-Bank-'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457312172647143754)
,p_name=>'THIRD_PARTY_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Client/Supplier Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457312558869143755)
,p_name=>'PAY_MODE'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Payment Mode'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Cash;Cash,Cheque;Cheque,Credit;Credit'
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457312950079143755)
,p_name=>'BANK_ACCOUNT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Bank Account No.'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457313371829143755)
,p_name=>'PHONE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Phone'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457313795219143755)
,p_name=>'CHEQUE_NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Cheque No.'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457314147916143755)
,p_name=>'ADDRESS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Address'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457314532570143755)
,p_name=>'DEBIT_ACCOUNT_NAME'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Debit Account'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT particulars FROM accounts;'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457314932618143756)
,p_name=>'EMAIL'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457315397576143756)
,p_name=>'CREDIT_ACCOUNT_NAME'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Credit Account'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT particulars FROM accounts;'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457315744718143756)
,p_name=>'CHEQUE_TIME'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Cheque Date'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'DATES'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457316192118143756)
,p_name=>'AMOUNT'
,p_is_required=>true
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_item_default=>'0'
,p_prompt=>'Amount'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457316545696143756)
,p_name=>'NARRATIONS'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Narration'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>50
,p_cHeight=>1
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457316991658143756)
,p_name=>'CR_CARD_NO'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Credit Card no'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457317326610143757)
,p_name=>'ACCOUNT_NUM'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457317752007143757)
,p_name=>'ACCOUNT_NUM2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457318148822143757)
,p_name=>'DR_CARD_NO'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Debit Card No'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30457318537633143757)
,p_name=>'CARDHOLER_NAMES'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(68848898555628669055)
,p_prompt=>'Cardholder Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_column=>7
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30457325868746143762)
,p_name=>'Transfer_accName_id_to_acc_id'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'CREDIT_ACCOUNT_NAME'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30457326351204143762)
,p_event_id=>wwv_flow_imp.id(30457325868746143762)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT acc_id INTO :ACCOUNT_NUM2 FROM accounts WHERE particulars = :CREDIT_ACCOUNT_NAME ;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN   ',
'NULL;'))
,p_attribute_02=>'CREDIT_ACCOUNT_NAME'
,p_attribute_03=>'ACCOUNT_NUM2'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30457326738483143762)
,p_name=>'Transfer_acc_name_id_to_acc_id'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'DEBIT_ACCOUNT_NAME'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30457327247210143763)
,p_event_id=>wwv_flow_imp.id(30457326738483143762)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT acc_id INTO :ACCOUNT_NUM FROM accounts WHERE particulars = :DEBIT_ACCOUNT_NAME ;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN   ',
'NULL;'))
,p_attribute_02=>'DEBIT_ACCOUNT_NAME'
,p_attribute_03=>'ACCOUNT_NUM'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30457327633260143763)
,p_name=>'addtodatabase'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(30457310516957143754)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30457328184481143763)
,p_event_id=>wwv_flow_imp.id(30457327633260143763)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :COMPANY_ID = 101 AND :ACCOUNT_NUM IS NOT NULL AND :ACCOUNT_NUM2 IS NOT NULL THEN',
'IF :DEBIT_ACCOUNT_NAME IS NOT NULL AND :CREDIT_ACCOUNT_NAME IS NOT NULL THEN DECLARE',
'								v_sequence NUMBER;',
'								v_dr_serial VARCHAR2(36);',
'								v_cr_serial VARCHAR2(36);',
'								v_jr_serial VARCHAR2(36);',
'							BEGIN',
'							v_sequence := acc_currval;',
'							v_dr_serial := dr_voucher_seq;',
'							v_cr_serial := cr_voucher_seq;',
'							v_jr_serial := jr_voucher_seq;',
'								IF :VOU_TYPE = ''cr'' THEN',
'									INSERT INTO credit_tables (cv_id,date_of_transaction,narration,voucher_type,voucher_no, user_id, payment_mode, bank_name, bank_acc_no, ',
'									cheque_no, cheque_date, credit_card_no, debit_card_no, cardholder_name,receive_from,phone,address,email,job_id)',
'									VALUES (v_sequence,:DATES,:NARRATIONS,:VOU_TYPE,v_cr_serial,USER,:PAY_MODE,:BANK_NAMING,:BANK_ACCOUNT,',
'									:CHEQUE_NUMBER,:CHEQUE_TIME,:CR_CARD_NO,:DR_CARD_NO,:CARDHOLER_NAMES,:THIRD_PARTY_NAME,:PHONE,',
'									:ADDRESS,:EMAIL,''FI_ACCOUNT'');',
'									',
'										INSERT INTO transaction_tables(date_of_transaction, particulars, debit, credit, cv_id, acc_id)',
'								VALUES (:DATES,:DEBIT_ACCOUNT_NAME,:AMOUNT,0,v_sequence,:ACCOUNT_NUM);',
'								INSERT INTO transaction_tables(date_of_transaction, particulars, debit, credit, cv_id, acc_id)',
'								VALUES (:DATES,:CREDIT_ACCOUNT_NAME,0,:AMOUNT,v_sequence,:ACCOUNT_NUM2);',
'							',
'								ELSIF :VOU_TYPE = ''dr'' THEN',
'									INSERT INTO debit_tables(dv_id, date_of_transaction, narration, voucher_type, voucher_no, user_id, payment_mode, bank_name, bank_acc_no, ',
'									cheque_no, cheque_date, credit_card_no, debit_card_no, cardholder_name,pay_to,phone,address,email,job_id)',
'									VALUES (v_sequence,:DATES,:NARRATIONS,:VOU_TYPE,v_dr_serial,USER,:PAY_MODE,:BANK_NAMING,:BANK_ACCOUNT,',
'									:CHEQUE_NUMBER,:CHEQUE_TIME,:CR_CARD_NO,:DR_CARD_NO,:CARDHOLER_NAMES,:THIRD_PARTY_NAME,:PHONE,',
'									:ADDRESS,:EMAIL,''FI_ACCOUNT'');',
'									',
'											INSERT INTO transaction_tables(date_of_transaction, particulars, debit, credit, dv_id, acc_id)',
'								VALUES (:DATES,:DEBIT_ACCOUNT_NAME,:AMOUNT,0,v_sequence,:ACCOUNT_NUM);',
'								INSERT INTO transaction_tables(date_of_transaction, particulars, debit, credit, dv_id, acc_id)',
'								VALUES (:DATES,:CREDIT_ACCOUNT_NAME,0,:AMOUNT,v_sequence,:ACCOUNT_NUM2);',
'							',
'								ELSIF :VOU_TYPE = ''jr'' THEN',
'									INSERT INTO journal_tables(jv_id,date_of_transaction,narration,voucher_type,voucher_no,user_id,payment_mode,supplier_name,phone,address,email,job_id)',
'									VALUES (v_sequence,:DATES,:NARRATIONS,:VOU_TYPE,v_jr_serial,USER,:PAY_MODE,:THIRD_PARTY_NAME,:PHONE,:ADDRESS,',
'									:EMAIL,''FI_ACCOUNT'');',
'INSERT INTO transaction_tables(date_of_transaction, particulars, debit, credit, jv_id, acc_id)',
'VALUES (:DATES,:DEBIT_ACCOUNT_NAME,:AMOUNT,0,v_sequence,:ACCOUNT_NUM);',
'INSERT INTO transaction_tables(date_of_transaction, particulars, debit, credit, jv_id, acc_id)',
'VALUES (:DATES,:CREDIT_ACCOUNT_NAME,0,:AMOUNT,v_sequence,:ACCOUNT_NUM2);',
'END IF;',
'END;',
'COMMIT;',
':DATES := NULL;',
':COMPANY_ID := NULL;',
':VOU_TYPE   := NULL;',
':PAY_MODE   := NULL;',
':DEBIT_ACCOUNT_NAME := NULL;',
':CREDIT_ACCOUNT_NAME    := NULL;',
':ACCOUNT_NUM    := NULL;',
'                            :ACCOUNT_NUM2   := NULL;',
'                            :AMOUNT := NULL;',
'                            :NARRATIONS := NULL;',
'                            :BANK_NAMING    := NULL;',
'                            :BANK_ACCOUNT   := NULL;',
'                            :CHEQUE_NUMBER  := NULL;',
'                            :CHEQUE_TIME    := NULL;',
'                            :CR_CARD_NO := NULL;',
'                            :DR_CARD_NO := NULL;',
'                            :CARDHOLER_NAMES    := NULL;',
'                            :THIRD_PARTY_NAME   := NULL;',
'                            :PHONE  := NULL;',
'                            :ADDRESS    := NULL;',
'                            :EMAIL  := NULL;',
'							--CLEAR;',
'							ELSE',
'								NULL;',
'	END IF;',
'ELSE',
'NULL;',
'END IF;',
'END;'))
,p_attribute_02=>'DATES,COMPANY_ID,VOU_TYPE,PAY_MODE,DEBIT_ACCOUNT_NAME,CREDIT_ACCOUNT_NAME,ACCOUNT_NUM,ACCOUNT_NUM2,AMOUNT,NARRATIONS,BANK_NAMING,BANK_ACCOUNT,CHEQUE_NUMBER,CHEQUE_TIME,CR_CARD_NO,DR_CARD_NO,CARDHOLER_NAMES,THIRD_PARTY_NAME,PHONE,ADDRESS,EMAIL'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30457329108585143764)
,p_event_id=>wwv_flow_imp.id(30457327633260143763)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'COMPANY_ID,BANK_NAMING,VOU_TYPE,BANK_ACCOUNT,PAY_MODE,CHEQUE_NUMBER,DEBIT_ACCOUNT_NAME,CHEQUE_TIME,CREDIT_ACCOUNT_NAME,CR_CARD_NO,ACCOUNT_NUM,ACCOUNT_NUM2,AMOUNT,DR_CARD_NO,NARRATIONS,CARDHOLER_NAMES,THIRD_PARTY_NAME,PHONE,ADDRESS,EMAIL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30457329649301143764)
,p_event_id=>wwv_flow_imp.id(30457327633260143763)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'null'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'apex.message.showPageSuccess(''ROWS ARE ADDED SUCCESSFULLY'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30457330076738143764)
,p_name=>'button_adjustment_plugin'
,p_event_sequence=>60
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30457330595485143764)
,p_event_id=>wwv_flow_imp.id(30457330076738143764)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.ITEMS.WITH.BUTTONS'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(30457309721810143753)
,p_attribute_01=>'DEBIT_ACCOUNT_NAME'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30457331060745143764)
,p_event_id=>wwv_flow_imp.id(30457330076738143764)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.ITEMS.WITH.BUTTONS'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(30457310100662143753)
,p_attribute_01=>'CREDIT_ACCOUNT_NAME'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30457331420122143765)
,p_name=>'refreshing'
,p_event_sequence=>70
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30457331999379143765)
,p_event_id=>wwv_flow_imp.id(30457331420122143765)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(68848898555628669055)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30457332824721143765)
,p_name=>'after_buttno_refresh_dr'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(30457309721810143753)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30457333363763143765)
,p_event_id=>wwv_flow_imp.id(30457332824721143765)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'SELECT PARTICULARS INTO :DEBIT_ACCOUNT_NAME FROM ACCOUNTS ORDER BY ACC_ID DESC FETCH FIRST 1 ROW ONLY;',
'END;'))
,p_attribute_02=>'DEBIT_ACCOUNT_NAME'
,p_attribute_03=>'DEBIT_ACCOUNT_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30457333797020143765)
,p_name=>'after_buttno_refresh_cr'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(30457310100662143753)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30457334241691143766)
,p_event_id=>wwv_flow_imp.id(30457333797020143765)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'SELECT PARTICULARS INTO :CREDIT_ACCOUNT_NAME FROM ACCOUNTS ORDER BY ACC_ID DESC FETCH FIRST 1 ROW ONLY;',
'END;'))
,p_attribute_02=>'CREDIT_ACCOUNT_NAME'
,p_attribute_03=>'CREDIT_ACCOUNT_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30457334672096143766)
,p_name=>'reloading_report'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P39_PARTICULAR,P39_TO_DATE,P39_FROM_DATE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(30457325490052143762)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clean_all'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
);
wwv_flow_imp.component_end;
end;
/
