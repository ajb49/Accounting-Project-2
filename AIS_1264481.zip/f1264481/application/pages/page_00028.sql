prompt --application/pages/page_00028
begin
--   Manifest
--     PAGE: 00028
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_page.create_page(
 p_id=>28
,p_user_interface_id=>wwv_flow_imp.id(55594815867856176587)
,p_name=>'Imbalance'
,p_alias=>'IMBALANCE'
,p_step_title=>'Imbalance'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220814173359'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(30315587970704816708)
,p_name=>'Imbalance'
,p_template=>wwv_flow_imp.id(55594718533205176547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''''edit,VOUCHER_NO,',
'       CV_ID, ',
'       DEBIT,',
'       CREDIT, DEBIT-CREDIT IMBALANCE_AMOUNT',
'  from CREDIT_BALANCE',
'  where debit <> credit;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(55594756141401176562)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Every Journal is Balanced'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30452044296783072324)
,p_query_column_id=>1
,p_column_alias=>'EDIT'
,p_column_display_sequence=>10
,p_column_heading=>'Edit'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_PARTICULAR:#CV_ID##CR_ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_disable_sort_column=>'N'
,p_report_column_width=>70
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30315588045223816709)
,p_query_column_id=>2
,p_column_alias=>'VOUCHER_NO'
,p_column_display_sequence=>20
,p_column_heading=>'Credit# Voucher No'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:40:P40_SEARCH_ID:#CV_ID#'
,p_column_linktext=>'#VOUCHER_NO#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30315588435452816713)
,p_query_column_id=>3
,p_column_alias=>'CV_ID'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30315588264266816711)
,p_query_column_id=>4
,p_column_alias=>'DEBIT'
,p_column_display_sequence=>40
,p_column_heading=>'Debit'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30315588309239816712)
,p_query_column_id=>5
,p_column_alias=>'CREDIT'
,p_column_display_sequence=>50
,p_column_heading=>'Credit'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30315589864262816727)
,p_query_column_id=>6
,p_column_alias=>'IMBALANCE_AMOUNT'
,p_column_display_sequence=>60
,p_column_heading=>'Imbalance Amount'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(30315589191245816720)
,p_name=>'Imbalance'
,p_template=>wwv_flow_imp.id(55594718533205176547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''''edit,VOUCHER_NO,',
'       JV_ID,',
'       DEBIT,',
'       CREDIT, DEBIT-CREDIT IMBALANCE_AMOUNT',
'  from JOURNAL_BALANCE',
'  where debit <> credit;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(55594756141401176562)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Every Journal is Balanced'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30452044389613072325)
,p_query_column_id=>1
,p_column_alias=>'EDIT'
,p_column_display_sequence=>10
,p_column_heading=>'Edit'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_PARTICULAR:#JV_ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_disable_sort_column=>'N'
,p_report_column_width=>70
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30315589276492816721)
,p_query_column_id=>2
,p_column_alias=>'VOUCHER_NO'
,p_column_display_sequence=>20
,p_column_heading=>'Journal# Voucher No'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:40:P40_SEARCH_ID:#JV_ID#'
,p_column_linktext=>'#VOUCHER_NO#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30315589612878816725)
,p_query_column_id=>3
,p_column_alias=>'JV_ID'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30315589330204816722)
,p_query_column_id=>4
,p_column_alias=>'DEBIT'
,p_column_display_sequence=>40
,p_column_heading=>'Debit'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30315589479777816723)
,p_query_column_id=>5
,p_column_alias=>'CREDIT'
,p_column_display_sequence=>50
,p_column_heading=>'Credit'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30315589936045816728)
,p_query_column_id=>6
,p_column_alias=>'IMBALANCE_AMOUNT'
,p_column_display_sequence=>60
,p_column_heading=>'Imbalance Amount'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(30361834351745867202)
,p_name=>'Imbalance'
,p_template=>wwv_flow_imp.id(55594718533205176547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''''edit,VOUCHER_NO,',
'       DV_ID,',
'       DEBIT,',
'       CREDIT, DEBIT-CREDIT IMBALANCE_AMOUNT',
'  from DEBIT_BALANCE',
'  where debit <> credit;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(55594756141401176562)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Every Journal is Balanced'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30452044119521072323)
,p_query_column_id=>1
,p_column_alias=>'EDIT'
,p_column_display_sequence=>10
,p_column_heading=>'Edit'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_PARTICULAR:#DV_ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_disable_sort_column=>'N'
,p_report_column_width=>70
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30361834611905867281)
,p_query_column_id=>2
,p_column_alias=>'VOUCHER_NO'
,p_column_display_sequence=>20
,p_column_heading=>'Debit# Voucher No'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:40:P40_SEARCH_ID:#DV_ID#'
,p_column_linktext=>'#VOUCHER_NO#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30361835085869867281)
,p_query_column_id=>3
,p_column_alias=>'DV_ID'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30361835441246867282)
,p_query_column_id=>4
,p_column_alias=>'DEBIT'
,p_column_display_sequence=>40
,p_column_heading=>'Debit'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30361835859699867282)
,p_query_column_id=>5
,p_column_alias=>'CREDIT'
,p_column_display_sequence=>50
,p_column_heading=>'Credit'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30315589717844816726)
,p_query_column_id=>6
,p_column_alias=>'IMBALANCE_AMOUNT'
,p_column_display_sequence=>60
,p_column_heading=>'Imbalance Amount'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp.component_end;
end;
/
