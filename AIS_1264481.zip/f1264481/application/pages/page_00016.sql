prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_page.create_page(
 p_id=>16
,p_user_interface_id=>wwv_flow_imp.id(55594815867856176587)
,p_name=>'Branch Information'
,p_alias=>'BRANCH-INFORMATION'
,p_page_mode=>'MODAL'
,p_step_title=>'Branch Information'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220609061813'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1503513921588687556)
,p_plug_name=>'Branch Information'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'BRANCH_INFORMATION'
,p_include_rowid_column=>true
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1503521347235687561)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594666903234176528)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1503521741499687561)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1503521347235687561)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(55594791148058176576)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1503523158014687561)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1503521347235687561)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(55594791148058176576)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P16_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1503523513603687562)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1503521347235687561)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(55594791148058176576)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P16_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1503523950636687562)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1503521347235687561)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(55594791148058176576)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P16_ROWID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1503514367702687556)
,p_name=>'P16_ROWID'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_item_source_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Rowid'
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(55594788608210176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1503514773533687557)
,p_name=>'P16_BRANCH_CODE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_item_source_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_source=>'BRANCH_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1503515101663687557)
,p_name=>'P16_BANK_CODE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_item_source_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_source=>'BANK_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1503515509388687557)
,p_name=>'P16_BRANCH_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_item_source_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Branch Name'
,p_source=>'BRANCH_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>100
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(55594788608210176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1503515990335687557)
,p_name=>'P16_DISTRICT_CODE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_item_source_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_use_cache_before_default=>'NO'
,p_prompt=>'District Code'
,p_source=>'DISTRICT_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(55594788608210176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1503516305533687558)
,p_name=>'P16_THANA_CODE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_item_source_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Thana Code'
,p_source=>'THANA_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(55594788608210176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1503516780283687558)
,p_name=>'P16_VILLAGE_CODE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_item_source_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Village Code'
,p_source=>'VILLAGE_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(55594788608210176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1503517149913687558)
,p_name=>'P16_BRANCH_ADDRESS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_item_source_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Branch Address'
,p_source=>'BRANCH_ADDRESS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>200
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(55594788608210176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1503517592883687558)
,p_name=>'P16_PHONE_NUMBER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_item_source_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Phone Number'
,p_source=>'PHONE_NUMBER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(55594788608210176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1503517996960687559)
,p_name=>'P16_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_item_source_plug_id=>wwv_flow_imp.id(1503513921588687556)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Email'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>100
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(55594788608210176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1503521845749687561)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1503521741499687561)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1503522658245687561)
,p_event_id=>wwv_flow_imp.id(1503521845749687561)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1492476262417641425)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Branch_pk'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    NEW_PK            VARCHAR2 (30) :=  NULL;',
'BEGIN',
'',
'    SELECT MAX (branch_code)',
'      INTO NEW_PK',
'      FROM branch_information;',
'    IF :P16_BANK_CODE = 100 THEN',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 1000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ELSIF :P16_BANK_CODE = 101 THEN',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 2000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ELSIF :P16_BANK_CODE = 102 THEN',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 3000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ELSIF :P16_BANK_CODE = 103 THEN',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 4000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ELSIF :P16_BANK_CODE = 104 THEN',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 5000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ELSIF :P16_BANK_CODE = 105 THEN',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 6000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ELSIF :P16_BANK_CODE = 106 THEN',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 7000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ELSIF :P16_BANK_CODE = 107 THEN',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 8000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ELSIF :P16_BANK_CODE = 108 THEN',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 9000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ELSIF :P16_BANK_CODE = 109 THEN',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 10000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ELSIF :P16_BANK_CODE = 110 THEN',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 11000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ELSIF :P16_BANK_CODE = 111 THEN',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 12000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ELSIF :P16_BANK_CODE = 112 THEN',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 13000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'',
'END IF;',
'    :P16_BRANCH_CODE := NEW_PK;',
'EXCEPTION',
' WHEN OTHERS THEN',
'   HTP.P(SQLERRM);',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1503523950636687562)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1503524758748687562)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(1503513921588687556)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Branch Information'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1503525158355687562)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_01=>'P16_ROWID,REQUEST'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1503524356548687562)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(1503513921588687556)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Branch Information'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
