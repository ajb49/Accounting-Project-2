prompt --application/pages/page_00025
begin
--   Manifest
--     PAGE: 00025
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_page.create_page(
 p_id=>25
,p_user_interface_id=>wwv_flow_imp.id(55594815867856176587)
,p_name=>'User_Verification_Place'
,p_alias=>'USER-VERIFICATION-PLACE'
,p_step_title=>'User Information'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220808115318'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(21700412705804080213)
,p_name=>'User Report'
,p_template=>wwv_flow_imp.id(55594664177883176527)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''''edit, IDNT,',
'       USERID,',
'       USER_PASSWORD,',
'       NICKNAME,',
'       EMAIL,',
'       PHONE,',
'       STATUS,',
'       PASSWORD_RECOVERY_CODE',
'  from USER_IDENTITIES'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(55594756141401176562)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(37790268554447738526)
,p_query_column_id=>1
,p_column_alias=>'EDIT'
,p_column_display_sequence=>20
,p_column_heading=>'Edit'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:P18_IDNT:#IDNT#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(21700412854467080214)
,p_query_column_id=>2
,p_column_alias=>'IDNT'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(21700412959608080215)
,p_query_column_id=>3
,p_column_alias=>'USERID'
,p_column_display_sequence=>30
,p_column_heading=>'Userid'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(21700413072778080216)
,p_query_column_id=>4
,p_column_alias=>'USER_PASSWORD'
,p_column_display_sequence=>40
,p_column_heading=>'User Password'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(21700413185100080217)
,p_query_column_id=>5
,p_column_alias=>'NICKNAME'
,p_column_display_sequence=>50
,p_column_heading=>'Nickname'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(21700413298838080218)
,p_query_column_id=>6
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>60
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(21700413336145080219)
,p_query_column_id=>7
,p_column_alias=>'PHONE'
,p_column_display_sequence=>70
,p_column_heading=>'Phone'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(21700413422452080220)
,p_query_column_id=>8
,p_column_alias=>'STATUS'
,p_column_display_sequence=>80
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Not Approved;N,Approved;Y,Not Define'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(37790268445214738525)
,p_query_column_id=>9
,p_column_alias=>'PASSWORD_RECOVERY_CODE'
,p_column_display_sequence=>90
,p_column_heading=>'Password Recovery Code'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37790270563624738546)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(21700412705804080213)
,p_button_name=>'Forgetting_Username_Password'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(55594791148058176576)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Forgetting Username Password'
,p_button_position=>'ABOVE_BOX'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(21730492637517004520)
,p_branch_action=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37790267851335738519)
,p_name=>'Refreshing_after_dialogueClose'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37790267985499738520)
,p_event_id=>wwv_flow_imp.id(37790267851335738519)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(21700412705804080213)
);
wwv_flow_imp.component_end;
end;
/
