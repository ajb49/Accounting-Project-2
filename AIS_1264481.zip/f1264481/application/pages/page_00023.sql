prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_page.create_page(
 p_id=>23
,p_user_interface_id=>wwv_flow_imp.id(55594815867856176587)
,p_name=>'Ledger_report_link'
,p_alias=>'LEDGER-REPORT-LINK'
,p_page_mode=>'MODAL'
,p_step_title=>'Ledger Report'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_protection_level=>'C'
,p_page_component_map=>'09'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220807091945'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15771801645828231039)
,p_plug_name=>'Ledger_Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source_type=>'NATIVE_URL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'f?p=&APP_ID.:0:&SESSION.:PRINT_REPORT=Ledger'
,p_attribute_02=>'IFRAME'
,p_attribute_03=>'width="950" height="1150" frameborder="0" dependent="yes" scrollbar="no" top="0" left="0" resizable="no" toolbar="no" <span id="title">BANK INFO</span>'
);
wwv_flow_imp.component_end;
end;
/
