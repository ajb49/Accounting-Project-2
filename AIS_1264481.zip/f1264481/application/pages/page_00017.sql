prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_page.create_page(
 p_id=>17
,p_user_interface_id=>wwv_flow_imp.id(55594815867856176587)
,p_name=>'Ratio'
,p_alias=>'RATIO'
,p_step_title=>'Ratio'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220709070343'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7209667788315485616)
,p_plug_name=>'New'
,p_region_name=>'history'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7293642305230825242)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594730675069176552)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(55594627743123176511)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(55594792763066176577)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7209667982143485618)
,p_name=>'P17_COMPANY_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7209667788315485616)
,p_prompt=>'Company Name'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'COMPANY_LIST'
,p_lov=>'select company_id r, company_name d from company_details;'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Select Company --'
,p_cHeight=>1
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7209668354482485622)
,p_name=>'P17_RECEIVABLE_TURNOVER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(7209667788315485616)
,p_prompt=>'Receivable Turnover'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7209668481267485623)
,p_name=>'P17_PAYABLE_TURNOVER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(7209667788315485616)
,p_prompt=>'Payable Turnover'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7209668661472485625)
,p_name=>'P17_FIXED_ASSET_TURNOVER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(7209667788315485616)
,p_prompt=>'Fixed Asset Turnover'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7209668812882485627)
,p_name=>'P17_TOTAL_ASSET_TURNOVER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(7209667788315485616)
,p_prompt=>'Total Asset Turnover'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7209669683353485635)
,p_name=>'P17_CURRENT_RATIO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(7209667788315485616)
,p_prompt=>'Current Ratio'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7209669961543485638)
,p_name=>'P17_QUICK_RATIO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(7209667788315485616)
,p_prompt=>'Quick Ratio'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7209670043291485639)
,p_name=>'P17_CASH_RATIO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(7209667788315485616)
,p_prompt=>'Cash Ratio'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7209670250378485641)
,p_name=>'P17_GROSS_PROFIT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(7209667788315485616)
,p_prompt=>'Gross Profit Margin'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7209670674471485645)
,p_name=>'P17_NET_PROFIT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(7209667788315485616)
,p_prompt=>'Net Profit Margin'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7209670879253485647)
,p_name=>'P17_DEPT_TO_CAPITAL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(7209667788315485616)
,p_prompt=>'Dept to Total Capital'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(23368297066396069345)
,p_name=>'data_reload'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P17_COMPANY_ID'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23368297141375069346)
,p_event_id=>wwv_flow_imp.id(23368297066396069345)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'---------------------------------receivable turnover',
'DECLARE',
'v_sales VARCHAR2(100);',
's_amount NUMBER;',
'v_rece VARCHAR2(100);',
'r_amount NUMBER;',
'v_rece_turn NUMBER;',
'BEGIN',
'SELECT ab.particulars, ab.balanced',
'INTO v_sales, s_amount',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND ab.particulars = ''Sales'' AND comp.company_id = :P17_COMPANY_ID;',
'--DBMS_OUTPUT.PUT_LINE(v_sales||'' ''||s_amount);',
'SELECT ab.particulars, ab.balanced',
'INTO v_rece, r_amount',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND ab.particulars = ''Account receivable'' AND comp.company_id = :P17_COMPANY_ID;',
'--DBMS_OUTPUT.PUT_LINE(v_rece||'' ''||r_amount);',
'v_rece_turn := NVL(ABS( ROUND(s_amount / r_amount,2)),0);',
':P17_RECEIVABLE_TURNOVER := NVL(ABS( ROUND(s_amount / r_amount,2)),0);',
'--DBMS_OUTPUT.PUT_LINE(v_rece_turn);',
'EXCEPTION',
'	WHEN NO_DATA_FOUND THEN',
':P17_RECEIVABLE_TURNOVER := 0;',
'--	MESSAGE(''NO DATA FOR THIS COMPANY'');',
'END;'))
,p_attribute_02=>'P17_COMPANY_ID'
,p_attribute_03=>'P17_RECEIVABLE_TURNOVER'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23368297318464069348)
,p_event_id=>wwv_flow_imp.id(23368297066396069345)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-------------------------------------------------------------payable turnover',
'',
'DECLARE',
'v_purchase VARCHAR2(100);',
'p_amount NUMBER;',
'v_payable VARCHAR2(100);',
'ap_amount NUMBER;',
'v_payable_turnover NUMBER;',
'BEGIN',
'SELECT ab.particulars, balanced',
'INTO v_purchase, p_amount',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND  ab.particulars = ''Purchase'';',
'--DBMS_OUTPUT.PUT_LINE(v_purchase||'' ''||p_amount);',
'',
'SELECT ab.particulars, balanced',
'INTO v_payable, ap_amount',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND ab.particulars = ''Accounts payable'';',
'--DBMS_OUTPUT.PUT_LINE(v_payable||'' ''||ap_amount);',
'',
':P17_PAYABLE_TURNOVER :=  NVL(ABS(ROUND(p_amount / ap_amount,2)),0);',
'--DBMS_OUTPUT.PUT_LINE(v_payable_turnover);',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
':P17_PAYABLE_TURNOVER := 0;',
'--MESSAGE(''NO DATA FOR THIS COMPANY'');',
'END;'))
,p_attribute_02=>'P17_COMPANY_ID'
,p_attribute_03=>'P17_PAYABLE_TURNOVER'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23368297407040069349)
,p_event_id=>wwv_flow_imp.id(23368297066396069345)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'---------------------------------------------------------------------fixed asset turnover',
'DECLARE',
'v_acc_type VARCHAR2(100);',
'v_fixed_amount NUMBER;',
'v_sale VARCHAR2(100);',
's_money NUMBER;',
'v_fat NUMBER;',
'BEGIN',
'SELECT account_type, SUM(debit)-SUM(credit) amount',
'INTO v_acc_type, v_fixed_amount',
'FROM transaction_tables tr , accounts ac , categories cat, chart_of_accounts coa, company_details comp ',
'WHERE tr.acc_id = ac.acc_id AND ac.c_id  = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND comp.company_id = :P17_COMPANY_ID',
'GROUP BY account_type',
'HAVING account_type = ''Fixed Asset'';',
'',
'',
'SELECT ab.particulars, balanced',
'INTO v_sale, s_money',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND  ab.particulars = ''Sales'';',
'',
':P17_FIXED_ASSET_TURNOVER := NVL( ABS(ROUND(s_money / v_fixed_amount,2)),0);',
'--DBMS_OUTPUT.PUT_LINE(v_fat);',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
':P17_FIXED_ASSET_TURNOVER := 0;',
'--MESSAGE(''NO DATA FOR THIS COMPANY'');',
'END;'))
,p_attribute_02=>'P17_COMPANY_ID'
,p_attribute_03=>'P17_FIXED_ASSET_TURNOVER'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26607051507739893801)
,p_event_id=>wwv_flow_imp.id(23368297066396069345)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--------------------------------------------------------total asset turnover',
'DECLARE',
'v_acc_head VARCHAR2(100);',
'v_acc_head_amount NUMBER;',
'v_sale VARCHAR2(100); --',
'ss_money NUMBER;  --',
'v_tst NUMBER;',
'BEGIN',
'SELECT accounts_head, SUM(debit)-SUM(credit) amount',
'INTO v_acc_head, v_acc_head_amount',
'FROM transaction_tables tr , accounts ac , categories cat, chart_of_accounts coa , company_details comp ',
'WHERE tr.acc_id = ac.acc_id AND ac.c_id  = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND comp.company_id = :P17_COMPANY_ID',
'GROUP BY accounts_head',
'HAVING accounts_head = ''Asset'';',
'',
'',
'SELECT ab.particulars, balanced',
'INTO v_sale, ss_money',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND  ab.particulars = ''Sales'';',
'',
'v_tst :=NVL( ABS(ROUND(ss_money / v_acc_head_amount,2)),0);',
':P17_TOTAL_ASSET_TURNOVER := v_tst;',
'--DBMS_OUTPUT.PUT_LINE(v_tst);',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
':P17_TOTAL_ASSET_TURNOVER := 0;',
'--MESSAGE(''NO DATA FOR THIS COMPANY'');',
'END;'))
,p_attribute_02=>'P17_COMPANY_ID'
,p_attribute_03=>'P17_TOTAL_ASSET_TURNOVER'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26607051652167893802)
,p_event_id=>wwv_flow_imp.id(23368297066396069345)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--------------------------------------------current ratio',
'DECLARE',
'v_acc_type2 VARCHAR2(100);',
'v_curras_amount NUMBER;',
'v_acc_type3 VARCHAR2(100);',
'v_currli_amount NUMBER;',
'v_cur_ratio NUMBER;',
'BEGIN',
'SELECT account_type, SUM(debit)-SUM(credit) amount',
'INTO v_acc_type2, v_curras_amount',
'FROM transaction_tables tr , accounts ac , categories cat, chart_of_accounts coa, company_details comp  ',
'WHERE tr.acc_id = ac.acc_id AND ac.c_id  = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND comp.company_id = :P17_COMPANY_ID',
'GROUP BY account_type',
'HAVING account_type = ''Current Asset'';',
'',
'SELECT account_type, SUM(debit)-SUM(credit) amount',
'INTO v_acc_type3, v_currli_amount',
'FROM transaction_tables tr , accounts ac , categories cat , chart_of_accounts coa, company_details comp ',
'WHERE tr.acc_id = ac.acc_id AND ac.c_id  = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND comp.company_id = :P17_COMPANY_ID',
'GROUP BY account_type',
'HAVING account_type = ''Current Liabilities'';',
'v_cur_ratio := NVL( ABS(ROUND(v_curras_amount / v_currli_amount,2)),0);',
':P17_CURRENT_RATIO := v_cur_ratio;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
':P17_CURRENT_RATIO := 0;',
'--MESSAGE(''NO_DATA FOR THIS COMPANY'');',
'--DBMS_OUTPUT.PUT_LINE(v_cur_ratio);',
'END;'))
,p_attribute_02=>'P17_COMPANY_ID'
,p_attribute_03=>'P17_CURRENT_RATIO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26607051749228893803)
,p_event_id=>wwv_flow_imp.id(23368297066396069345)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-----------------------------------------------------Quick ratio',
'DECLARE',
'v_cash_p VARCHAR2(100);',
'v_cash NUMBER;',
'v_cash_hand_p VARCHAR2(100);',
'v_cash_hand NUMBER;',
'v_cash_bank_p VARCHAR2(100);',
'v_cash_bank NUMBER;',
'v_ar_p VARCHAR2(100);',
'v_ar NUMBER;',
'v_curr_p VARCHAR2(100);',
'v_curr NUMBER;',
'v_quick NUMBER;',
'BEGIN',
'SELECT ab.particulars, NVL(balanced,0)',
'INTO v_cash_p, v_cash',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND  ab.particulars = ''Cash'';',
'',
'',
'SELECT NVL(ab.particulars,''N/A''), NVL(balanced,0)',
'INTO v_cash_hand_p, v_cash_hand',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND  ab.particulars = ''Cash in hand'';',
'',
'SELECT ab.particulars, NVL(balanced,0)',
'INTO v_cash_bank_p, v_cash_bank',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND  ab.particulars = ''Cash at bank'';',
'',
'SELECT ab.particulars, NVL(balanced,0)',
'INTO v_ar_p, v_ar',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND  ab.particulars = ''Account receivable'';',
'',
'SELECT account_type, NVL((SUM(debit)-SUM(credit)),0) amount',
'INTO v_curr_p, v_curr',
'FROM transaction_tables tr , accounts ac , categories cat , chart_of_accounts coa, company_details comp ',
'WHERE tr.acc_id = ac.acc_id AND ac.c_id  = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND comp.company_id = :P17_COMPANY_ID',
'GROUP BY account_type',
'HAVING account_type = ''Current Liabilities'';',
'v_quick := NVL(ABS(ROUND(((v_cash + v_cash_hand + v_cash_bank + v_ar) / v_curr),2)),0);',
'--DBMS_OUTPUT.PUT_LINE(v_quick);',
':P17_QUICK_RATIO := v_quick;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
':P17_QUICK_RATIO := 0;',
'--DBMS_OUTPUT.PUT_LINE(''Please enter initial value for Cash, Cash in hand, Cash at bank, Account Receivable and Current Liabilities'');',
'--MESSAGE(''Please enter initial value for Cash, Cash in hand, Cash at bank, Account Receivable and Current Liabilities'');',
'END;'))
,p_attribute_02=>'P17_COMPANY_ID'
,p_attribute_03=>'P17_QUICK_RATIO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26607051878617893804)
,p_event_id=>wwv_flow_imp.id(23368297066396069345)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'------------------------------------------------------------------------ Cash ratio',
'DECLARE',
'v_cash_pc VARCHAR2(100);',
'v_cash_c NUMBER;',
'v_cash_hand_pc VARCHAR2(100);',
'v_cash_handc NUMBER;',
'v_curr_pc VARCHAR2(100);',
'v_currc NUMBER;',
'v_cash NUMBER;',
'BEGIN',
'SELECT ab.particulars, NVL(balanced,0)',
'INTO v_cash_pc, v_cash_c',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE  ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND  ab.particulars = ''Cash'';',
'',
'SELECT NVL(ab.particulars,''N/A''), NVL(balanced,0)',
'INTO v_cash_hand_pc, v_cash_handc',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE  ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND  ab.particulars = ''Cash in hand'';   ',
'',
'',
'SELECT account_type, NVL((SUM(debit)-SUM(credit)),0) amount',
'INTO v_curr_pc, v_currc',
'FROM transaction_tables tr , accounts ac , categories cat , chart_of_accounts coa, company_details comp ',
'WHERE tr.acc_id = ac.acc_id AND ac.c_id  = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND comp.company_id = :P17_COMPANY_ID',
'GROUP BY account_type',
'HAVING account_type = ''Current Liabilities'';',
'',
'v_cash :=  NVL(ABS(ROUND((v_cash_c + v_cash_handc)  / v_currc,2)),0);',
':P17_CASH_RATIO := v_cash;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
':P17_CASH_RATIO := 0;',
'--DBMS_OUTPUT.PUT_LINE(''Please enter initial value for Cash, Cash in hand, Current Liabilities'');',
'--MESSAGE(''Please enter initial value for Cash, Cash in hand, Current Liabilities'');',
'END;'))
,p_attribute_02=>'P17_COMPANY_ID'
,p_attribute_03=>'P17_CASH_RATIO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26607051926132893805)
,p_event_id=>wwv_flow_imp.id(23368297066396069345)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'------------------------------------------------------------------- GROSS profit mergin',
'DECLARE',
'v_sales number;',
'v_purchase number;',
'v_gross NUMBER;',
'v_sales_p VARCHAR2(100);',
's_amount NUMBER;',
'v_gross_mergin NUMBER;',
'BEGIN',
'SELECT balanced  INTO v_sales ',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp ',
'WHERE   ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND  ab.particulars = ''Sales'';',
'SELECT balanced INTO v_purchase ',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE   ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND  ab.particulars = ''Purchase'';',
'--:CTRL_BLOCK.GROSS_PROFIT := TO_CHAR(v_sales + v_purchase,''999G99G99G990D99PR'');',
'v_gross := v_sales + v_purchase;',
'--DBMS_OUTPUT.PUT_LINE(v_gross);',
'',
'SELECT ab.particulars, balanced',
'INTO v_sales_p, s_amount',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE   ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND  ab.particulars = ''Sales'';',
'',
'v_gross_mergin := ROUND(v_gross / s_amount,2);',
'--DBMS_OUTPUT.PUT_LINE(v_gross_mergin);',
':P17_GROSS_PROFIT := v_gross_mergin;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
':P17_GROSS_PROFIT := 0;',
'--MESSAGE(''NO DATA FOR THIS COMPANY'');',
'',
'END;'))
,p_attribute_02=>'P17_COMPANY_ID'
,p_attribute_03=>'P17_GROSS_PROFIT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26607052033631893806)
,p_event_id=>wwv_flow_imp.id(23368297066396069345)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-----------------------------------------------------------net profit margin',
'DECLARE',
'v_net NUMBER;',
'v_sales_ps VARCHAR2(100);',
's_amounts NUMBER;',
'v_net_p_margin NUMBER;',
'BEGIN',
'SELECT SUM(debit) - SUM(credit)',
'--INTO :CTRL_BLOCK.NET_INCOME',
'INTO v_net',
'FROM transaction_tables tr,accounts ac, categories cat,income_statements inc, chart_of_accounts coa, company_details comp ',
'WHERE tr.acc_id = ac.acc_id',
'AND ac.c_id = cat.c_id',
'AND cat.isid = inc.isid AND inc.coa_id = coa.coa_id AND comp.company_id = coa.company_id',
'AND inc.isid = 1111 AND comp.company_id = :P17_COMPANY_ID;',
'--DBMS_OUTPUT.PUT_LINE(v_net);',
'',
'SELECT ab.particulars, balanced',
'INTO v_sales_ps, s_amounts',
'FROM account_balanced ab, accounts acc, categories cat, chart_of_accounts coa, company_details comp',
'WHERE   ab.acc_id = acc.acc_id AND acc.c_id = cat.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND  comp.company_id = :P17_COMPANY_ID AND  ab.particulars = ''Sales'';',
'v_net_p_margin := ROUND(v_net/ s_amounts,2);',
'--DBMS_OUTPUT.PUT_LINE(v_net_p_margin);',
':P17_NET_PROFIT := v_net_p_margin;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
':P17_NET_PROFIT := 0;',
'--MESSAGE(''NO DATA FOR THIS COMPANY'');',
'END;'))
,p_attribute_02=>'P17_COMPANY_ID'
,p_attribute_03=>'P17_NET_PROFIT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26607052103936893807)
,p_event_id=>wwv_flow_imp.id(23368297066396069345)
,p_event_result=>'TRUE'
,p_action_sequence=>100
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'----------------------------------------------',
'DECLARE',
'v_current_liabilities_p VARCHAR2(100);',
'v_current_liabilities NUMBER;',
'v_fixed_liabilities_p VARCHAR2(100);',
'v_fixed_liabilities NUMBER;',
'v_contra_liabilities_p VARCHAR2(100);',
'v_contra_liabilities NUMBER;',
'v_owner_equity_p VARCHAR2(100);',
'v_owner_equity NUMBER;',
'v_contra_equity_p VARCHAR2(100);',
'v_contra_equity NUMBER;',
'v_income_desc_p VARCHAR2(100);',
'v_net_income NUMBER;',
'total_dept NUMBER;',
'dept_to_capital NUMBER;',
'BEGIN',
'SELECT account_type, SUM(balanced) ',
'INTO v_current_liabilities_p, v_current_liabilities',
'FROM account_balanced ab, accounts ac, categories cat , chart_of_accounts coa, company_details comp ',
'WHERE ac.acc_id = ab.acc_id',
'AND cat.c_id = ac.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND comp.company_id = :P17_COMPANY_ID',
'AND account_type = ''Current Liabilities''',
'GROUP BY account_type;',
'',
'SELECT account_type, SUM(balanced) ',
'INTO v_fixed_liabilities_p, v_fixed_liabilities',
'FROM account_balanced ab, accounts ac, categories cat , chart_of_accounts coa, company_details comp ',
'WHERE ac.acc_id = ab.acc_id',
'AND cat.c_id = ac.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND comp.company_id = :P17_COMPANY_ID',
'AND account_type = ''Non-Current Liabilities''',
'GROUP BY account_type;                                                                ',
'',
'SELECT account_type, SUM(balanced) ',
'INTO v_contra_liabilities_p, v_contra_liabilities',
'FROM account_balanced ab, accounts ac, categories cat , chart_of_accounts coa, company_details comp ',
'WHERE ac.acc_id = ab.acc_id',
'AND cat.c_id = ac.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND comp.company_id = :P17_COMPANY_ID',
'AND account_type = ''Contra Liabilities''',
'GROUP BY account_type;                                                              ',
'',
'SELECT account_type, SUM(balanced) ',
'INTO v_owner_equity_p, v_owner_equity',
'FROM account_balanced ab, accounts ac, categories cat , chart_of_accounts coa, company_details comp ',
'WHERE ac.acc_id = ab.acc_id',
'AND cat.c_id = ac.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND comp.company_id = :P17_COMPANY_ID',
'AND account_type = ''Owner Equity''',
'GROUP BY account_type;',
'',
'SELECT account_type,SUM(balanced) ',
'INTO v_contra_equity_p, v_contra_equity',
'FROM account_balanced ab, accounts ac, categories cat , chart_of_accounts coa, company_details comp ',
'WHERE ac.acc_id = ab.acc_id',
'AND cat.c_id = ac.c_id AND cat.coa_id = coa.coa_id AND coa.company_id = comp.company_id AND comp.company_id = :P17_COMPANY_ID',
'AND account_type = ''Contra Equity''',
'GROUP BY account_type;',
'',
'',
'SELECT description, SUM(debit) - SUM(credit)',
'INTO v_income_desc_p, v_net_income',
'FROM transaction_tables tr, accounts ac, categories cat, income_statements inc , chart_of_accounts coa, company_details comp ',
'WHERE tr.acc_id = ac.acc_id',
'AND ac.c_id = cat.c_id',
'AND cat.isid = inc.isid AND inc.coa_id = coa.coa_id AND comp.company_id = coa.company_id AND comp.company_id = :P17_COMPANY_ID',
'GROUP BY description;',
'total_dept := v_current_liabilities + v_fixed_liabilities + v_contra_liabilities + v_owner_equity + v_contra_equity + v_net_income;',
'--DBMS_OUTPUT.PUT_LINE(total_dept);',
'dept_to_capital := ROUND(total_dept / v_owner_equity,2);',
'--DBMS_OUTPUT.PUT_LINE(dept_to_capital);',
':P17_DEPT_TO_CAPITAL := dept_to_capital;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
':P17_DEPT_TO_CAPITAL := 0;',
'--MESSAGE(''NO DATA FOR THIS COMPANY'');',
'END;'))
,p_attribute_02=>'P17_COMPANY_ID'
,p_attribute_03=>'P17_DEPT_TO_CAPITAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
