prompt --application/pages/page_00037
begin
--   Manifest
--     PAGE: 00037
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_page.create_page(
 p_id=>37
,p_user_interface_id=>wwv_flow_imp.id(55594815867856176587)
,p_name=>'Trial_Balanced'
,p_alias=>'TRIAL-BALANCED'
,p_step_title=>'Trial_Balanced'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220810085741'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38057090296174276621)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38057091158690276630)
,p_plug_name=>'Trial Balance'
,p_icon_css_classes=>'fa-bars'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594696400981176539)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_menu_id=>wwv_flow_imp.id(55594627743123176511)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(55594792763066176577)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(45768577650417650027)
,p_name=>'Trial_balance'
,p_template=>wwv_flow_imp.id(55594718533205176547)
,p_display_sequence=>30
,p_region_css_classes=>'b_sheet'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT date_of_transaction, acc_id, particulars, SUM(debit)-SUM(credit) DEBIT,NVL(NULL,0) CREDIT ',
'FROM transaction_tables ',
'WHERE (particulars = :P37_PARTICULARS OR :P37_PARTICULARS IS NULL)',
'AND date_of_transaction BETWEEN :P37_FROMDATE AND :P37_TODATE',
'GROUP BY date_of_transaction,  acc_id, particulars',
'HAVING acc_id IN(SELECT acc_id  ',
'FROM accounts ',
'JOIN categories ',
'USING (c_id) ',
'WHERE c_id IN (100,200,600,800,1100,1200,1300))',
'UNION ',
'SELECT date_of_transaction, acc_id, particulars,NVL(NULL,0),SUM(debit)-SUM(credit) CREDIT ',
'FROM transaction_tables ',
'WHERE (particulars = :P37_PARTICULARS OR :P37_PARTICULARS IS NULL)',
'AND date_of_transaction BETWEEN :P37_FROMDATE AND :P37_TODATE',
'GROUP BY date_of_transaction,  acc_id, particulars ',
'HAVING acc_id IN(SELECT acc_id  ',
'FROM accounts ',
'JOIN categories ',
'USING (c_id) ',
'WHERE c_id IN(300,400,500,700,900,1000,1400));'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P37_PARTICULARS,P37_FROMDATE,P37_TODATE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(55594756141401176562)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38057090126392276620)
,p_query_column_id=>1
,p_column_alias=>'DATE_OF_TRANSACTION'
,p_column_display_sequence=>12
,p_column_heading=>'Date Of Transaction'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38563608143396260862)
,p_query_column_id=>2
,p_column_alias=>'ACC_ID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38563608556415260862)
,p_query_column_id=>3
,p_column_alias=>'PARTICULARS'
,p_column_display_sequence=>22
,p_column_heading=>'Particulars'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38563608972302260862)
,p_query_column_id=>4
,p_column_alias=>'DEBIT'
,p_column_display_sequence=>32
,p_column_heading=>'Debit'
,p_use_as_row_header=>'N'
,p_column_format=>'99G99G99G999PR'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38563609344231260863)
,p_query_column_id=>5
,p_column_alias=>'CREDIT'
,p_column_display_sequence=>42
,p_column_heading=>'Credit'
,p_use_as_row_header=>'N'
,p_column_format=>'99G99G99G999PR'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38563607008868260860)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38057091158690276630)
,p_button_name=>'Print'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(55594791218143176576)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Print'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-print'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38057090399093276622)
,p_name=>'P37_PARTICULARS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38057090296174276621)
,p_prompt=>'Particulars'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct tt.particulars d, tt.particulars r from accounts ac, transaction_tables tt',
'where ac.acc_id = tt.acc_id',
'and tt.particulars IS NOT NULL;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38057090543612276624)
,p_name=>'P37_FROMDATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(38057090296174276621)
,p_prompt=>'From'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38057090687651276625)
,p_name=>'P37_TODATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(38057090296174276621)
,p_item_default=>'CURRENT_TIMESTAMP'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'To'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38057090724677276626)
,p_name=>'Refreshing_Query'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P37_PARTICULARS,P37_FROMDATE,P37_TODATE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38057090848324276627)
,p_event_id=>wwv_flow_imp.id(38057090724677276626)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(45768577650417650027)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38057091056889276629)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clean_Field'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
);
wwv_flow_imp.component_end;
end;
/
