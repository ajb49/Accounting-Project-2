prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_user_interface_id=>wwv_flow_imp.id(55594815867856176587)
,p_name=>'Company'
,p_alias=>'COMPANY'
,p_step_title=>'Company Information'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>'img {width: 50%;}'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220807091257'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(55722928218178603561)
,p_name=>'Company Info'
,p_template=>wwv_flow_imp.id(55594718533205176547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select COMPANY_ID,',
'       COMPANY_NAME,',
'       ADDRESS,',
'       PHONE,',
'       FAX,',
'       EMAIL,',
'       dbms_lob.getlength(LOGO) as Image,',
'       MIMETYPE,',
'       FILENAME,',
'       CREATED_DATE',
'  from COMPANY_DETAILS'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(55594756141401176562)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55722928552450603562)
,p_query_column_id=>1
,p_column_alias=>'COMPANY_ID'
,p_column_display_sequence=>10
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55722928959390603562)
,p_query_column_id=>2
,p_column_alias=>'COMPANY_NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Company Name'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:11:P11_COMPANY_ID:#COMPANY_ID#'
,p_column_linktext=>'#COMPANY_NAME#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55722929346325603562)
,p_query_column_id=>3
,p_column_alias=>'ADDRESS'
,p_column_display_sequence=>30
,p_column_heading=>'Address'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55722929726548603562)
,p_query_column_id=>4
,p_column_alias=>'PHONE'
,p_column_display_sequence=>40
,p_column_heading=>'Phone'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55722930164695603563)
,p_query_column_id=>5
,p_column_alias=>'FAX'
,p_column_display_sequence=>50
,p_column_heading=>'Fax'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55722930547244603563)
,p_query_column_id=>6
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>60
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55541631077503781523)
,p_query_column_id=>7
,p_column_alias=>'IMAGE'
,p_column_display_sequence=>110
,p_column_heading=>'Image'
,p_use_as_row_header=>'N'
,p_column_format=>'IMAGE:COMPANY_DETAILS:LOGO:COMPANY_ID::::::::'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_width=>200
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55722931335876603563)
,p_query_column_id=>8
,p_column_alias=>'MIMETYPE'
,p_column_display_sequence=>80
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55722931745748603563)
,p_query_column_id=>9
,p_column_alias=>'FILENAME'
,p_column_display_sequence=>90
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55722932136377603563)
,p_query_column_id=>10
,p_column_alias=>'CREATED_DATE'
,p_column_display_sequence=>100
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1268632722976815530)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(55722928218178603561)
,p_button_name=>'print'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(55594790466687176576)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Print'
,p_button_redirect_url=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-print'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(55541631276944781525)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(55722928218178603561)
,p_button_name=>'add_company'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(55594791218143176576)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Company'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:11::'
,p_icon_css_classes=>'fa-plus-square-o'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(55541631377952781526)
,p_name=>'RELOAD'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55541631406245781527)
,p_event_id=>wwv_flow_imp.id(55541631377952781526)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(55722928218178603561)
);
wwv_flow_imp.component_end;
end;
/
