prompt --application/pages/page_00033
begin
--   Manifest
--     PAGE: 00033
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_page.create_page(
 p_id=>33
,p_user_interface_id=>wwv_flow_imp.id(55594815867856176587)
,p_name=>'User Registration Backup'
,p_alias=>'USER-REGISTRATION-BACKUP'
,p_page_mode=>'MODAL'
,p_step_title=>'Registration'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.linear-gradient1 {',
'  background-color: #B59228;',
'  background-image: linear-gradient(to  right, #B59228, #043A56);',
'}'))
,p_step_template=>wwv_flow_imp.id(55594628520473176512)
,p_page_css_classes=>'linear-gradient1'
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_width=>'400'
,p_dialog_css_classes=>'linear-gradient1'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220814085912'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(59503723497808925259)
,p_plug_name=>'User_Registration'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'USER_IDENTITIES'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(59503728633068925264)
,p_plug_name=>'Buttons'
,p_region_css_classes=>'linear-gradient1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594666903234176528)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37803080034881836089)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(59503728633068925264)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(55594791148058176576)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37803080431805836090)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(59503728633068925264)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(55594791148058176576)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P33_IDNT'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37803080817772836090)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(59503728633068925264)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(55594791148058176576)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P33_IDNT'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37803081218760836090)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(59503728633068925264)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(55594791148058176576)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Register'
,p_button_position=>'NEXT'
,p_button_condition=>'P33_IDNT'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
,p_button_comment=>'hello world'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37803073327381836084)
,p_name=>'P33_IDNT'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_item_source_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_source=>'IDNT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37803073763982836085)
,p_name=>'P33_USERID'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_item_source_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_prompt=>'<b>New Username</b>'
,p_placeholder=>'Enter New Username'
,p_source=>'USERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37803074193079836085)
,p_name=>'P33_USER_PASSWORD'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_item_source_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_prompt=>'<b>New Password</b>'
,p_placeholder=>'6-10 Characters'
,p_source=>'USER_PASSWORD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>32
,p_cMaxlength=>10
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37803074544535836085)
,p_name=>'P33_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_item_source_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_prompt=>'<b>Email</b>'
,p_placeholder=>'email@address.com'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>250
,p_tag_attributes=>'style="text-transform: lowercase";'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(55594788754005176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37803074987250836085)
,p_name=>'P33_NICKNAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_item_source_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_source=>'NICKNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37803075382810836086)
,p_name=>'P33_PHONE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_item_source_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_source=>'PHONE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37803075735096836086)
,p_name=>'P33_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_item_source_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_item_default=>'N'
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_display_when=>'P33_IDNT'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37803076152313836086)
,p_name=>'P33_PASSWORD_RECOVERY_CODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_item_source_plug_id=>wwv_flow_imp.id(59503723497808925259)
,p_item_default=>'12'
,p_source=>'PASSWORD_RECOVERY_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(37803081768904836091)
,p_validation_name=>'mail_validation'
,p_validation_sequence=>10
,p_validation=>'P33_EMAIL'
,p_validation2=>'^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Please Enter valid Email ID'
,p_associated_item=>wwv_flow_imp.id(37803074544535836085)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37803083257945836092)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(37803080034881836089)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37803083775443836092)
,p_event_id=>wwv_flow_imp.id(37803083257945836092)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37803082086350836091)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'pk_and_mail'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    NEW_PK            VARCHAR2 (100) :=  NULL;',
'BEGIN',
'',
'    SELECT MAX (IDNT)',
'      INTO NEW_PK',
'      FROM USER_IDENTITIES;',
'    ',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 1;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ',
'    :P33_IDNT := NEW_PK;',
'',
'EXCEPTION',
' WHEN OTHERS THEN',
'   HTP.P(SQLERRM);',
'END;',
'',
'',
'',
'DECLARE',
'Vcust_email user_identities.email%type; --conflicting same username and email',
'Vbody CLOB;',
'Vbody_html CLOB;',
'v_username user_identities.userid%type;',
'BEGIN',
'Vcust_email := :P33_EMAIL;',
'if Vcust_email is not null then',
'Vbody := ''To view the content of this message, please use an HTML enabled mail client.''||utl_tcp.crlf;',
'Vbody_html := ''Thank you for Registering AIS Management System''||utl_tcp.crlf;',
'apex_mail.send(',
'p_to => Vcust_email,',
'p_from => ''abc@abc.com'',',
'p_body_html => Vbody_html,',
'p_subj => ''Accounting Information System Login'',',
'p_body => Vbody',
');',
'else null;',
'end if;',
'END;',
'',
'',
'',
'DECLARE',
'Vcust_email user_identities.email%type; --conflicting same username and email',
'Vbody CLOB;',
'Vbody_html CLOB;',
'v_username user_identities.userid%type;',
'v_recieving Vcust_email%TYPE := ''md.asifjamil5@gmail.com'';',
'v_time VARCHAR2(100);',
'BEGIN',
'Vcust_email := :P33_EMAIL;',
'SELECT TO_CHAR(CURRENT_TIMESTAMP,''DD/MM/YYYY "at" HH:MI:SS AM'') INTO v_time FROM DUAL;',
'if Vcust_email is not null then',
'Vbody := ''To view the content of this message, please use an HTML enabled mail client.''||utl_tcp.crlf;',
'Vbody_html := Vcust_email||'' visited AIS Management System in ''||v_time||utl_tcp.crlf;',
'apex_mail.send(',
'p_to => v_recieving,',
'p_from => ''abc@abc.com'',',
'p_body_html => Vbody_html,',
'p_subj => ''Accounting Information System Login information'',',
'p_body => Vbody',
');',
'else null;',
'end if;',
'END;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37803081218760836090)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37803082842583836092)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'sending_mail'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-------------------------------------sending email verification',
'declare',
'l_body_html CLOB;',
'v_name nvarchar2 (50);',
'v_code  nvarchar2 (50);',
'v_email nvarchar2(50);',
'begin',
'select EMAIL, PASSWORD_RECOVERY_CODE into v_email,v_code from USER_IDENTITIES',
'where idnt= :P33_IDNT;',
'l_body_html := ''',
'<html lang="en-US">',
'         <head>',
'  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">',
'         </head>',
'                <body>',
'<div style="height:300px; width: 800px;border: 1px solid rgb(167, 162, 162);box-shadow: 2px 2px 5px 2px rgb(216, 204, 203);">',
'          <div style="background:#244283; height: 40px; width: 800px;color:#fff; ">',
'      <h2 style="margin-left:20px; margin-top: 0px; padding-top: 10px;">Account Verification Email</h2>',
'     </div>',
'     <div style="height: 45px;margin: 20px;" >',
'     <p>',
'                    Thank you for registration.',
'                    <br>',
'     To verify your account please click the link below.</p>',
'     <p><a href="https://apex.oracle.com/pls/apex/r/project_ac/ais1/email-verification?P27_EMAIL=''||v_email||''">Verify Your account</a></p><br>',
'  </div>',
'</div> ',
'</body>',
'</html>',
''';',
'APEX_MAIL.SEND(:P33_EMAIL,''no-reply@oraclelearner.com'',l_body_html,l_body_html,''Account Verification Email'',null,null,null);',
'exception when others then null;',
'end;',
'',
'-----------------------------',
'',
'',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37803081218760836090)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37803079376949836089)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(59503723497808925259)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form User_Registration'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37803082493785836092)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37803078932195836089)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(59503723497808925259)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form User_Registration'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
