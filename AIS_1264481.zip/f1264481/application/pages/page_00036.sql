prompt --application/pages/page_00036
begin
--   Manifest
--     PAGE: 00036
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>55585209708868472827
,p_default_application_id=>1264481
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECTAC'
);
wwv_flow_imp_page.create_page(
 p_id=>36
,p_user_interface_id=>wwv_flow_imp.id(55594815867856176587)
,p_name=>'Fix Forgetting User Details'
,p_alias=>'FIX-FORGETTING-USER-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Retrieve User Details'
,p_autocomplete_on_off=>'OFF'
,p_page_css_classes=>'linear-gradient1'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'500'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220903134328'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37790270636694738547)
,p_plug_name=>'Choosing_Fixing_Site'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55594664177883176527)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38057089722260276616)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(37790270636694738547)
,p_button_name=>'Mail_inserting'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconRight:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_imp.id(55594791218143176576)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'BELOW_BOX'
,p_icon_css_classes=>'fa-mail-forward'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38057088359845276602)
,p_name=>'P36_EMAIL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(37790270636694738547)
,p_prompt=>'<b style= "color: red;">Email</b>'
,p_placeholder=>'Please Enter Your Registered Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(55594788492068176575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(38057088615612276605)
,p_validation_name=>'email_format'
,p_validation_sequence=>10
,p_validation=>'P36_EMAIL'
,p_validation2=>'^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Please Enter valid Email ID'
,p_associated_item=>wwv_flow_imp.id(38057088359845276602)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38057088563671276604)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Sending_email'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'Vcust_email user_identities.email%type; --conflicting same username and email',
'Vbody CLOB;',
'Vbody_html CLOB;',
'Vbody_html2 CLOB;',
'v_username user_identities.userid%type;',
'v_pass user_identities.user_password%type;',
'v_time varchar2(100);',
'v_hostemail varchar2(50) := ''md.asifjamil5@gmail.com'';',
'Vbody2 CLOB;',
'BEGIN',
'Vcust_email := :P36_EMAIL;',
'SELECT userid, user_password INTO v_username, v_pass FROM user_identities WHERE lower(email) = lower(:P36_EMAIL);',
'if Vcust_email is not null then',
'Vbody := ''To view the content of this message, please use an HTML enabled mail client.''||utl_tcp.crlf;',
'Vbody_html := ''Your Username: ''||v_username||'' & Password: ''||v_pass||utl_tcp.crlf;',
'apex_mail.send(',
'p_to => lower(Vcust_email),',
'p_from => ''abc@abc.com'',',
'p_body_html => Vbody_html,',
'p_subj => ''Login Detail Information of AIS'',',
'p_body => Vbody',
');',
':P36_EMAIL := null;',
'',
'---------------',
'select to_char(current_timestamp,''fmDD/MM/YYYY HH12:MI:SS am'') into v_time from dual;',
'Vbody2 := ''To view the content of this message, please use an HTML enabled mail client.''||utl_tcp.crlf;',
'Vbody_html2 := v_username||'' checked his/her login data in ''||v_time||utl_tcp.crlf;',
'apex_mail.send(',
'p_to => v_hostemail,',
'p_from => ''abc@abc.com'',',
'p_body_html => Vbody_html2,',
'p_subj => ''Reset Password Information of AIS'',',
'p_body => Vbody2',
');',
'',
'---------------',
'else ',
'htp.p(''Please, Insert valid registered email'');',
'end if;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No match for email.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(38057089722260276616)
,p_process_success_message=>'Username & Password have been sent successfully.'
);
wwv_flow_imp.component_end;
end;
/
